#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Viraj Watermark — production-ready Telegram watermark bot (single file).

Run with:      python bot.py
Environment:   copy .env.example -> .env and fill in BOT_TOKEN + ADMIN_IDS
Self-check:    python bot.py --check
Offline tests: python bot.py --selftest
Scaffold:      python bot.py --scaffold   (regenerates every other file:
                requirements.txt, .env.example, Docker, systemd, README, tests/)

Features
--------
* Watermark images (JPG/JPEG/PNG/WEBP), PDFs and videos (FFmpeg overlay).
* Text and logo watermarks: size, color, opacity, rotation, 9 positions + custom
  coordinates, margins, bold/italic, outline stroke, drop shadow, badge box,
  tiled mode with custom spacing.
* 26 video animation presets with adjustable speed.
* Per-user persistent settings (SQLite), independent per media category
  (Video / Image / PDF) plus per-user Global Defaults inheritance.
* Batch processing with per-file failure isolation and ZIP delivery.
* Admin panel: stats, system monitoring, broadcast, block/unblock, temp
  cleanup, configurable limits, recent error log.
* Security: no hardcoded secrets, env-only config, size limits, format
  validation, filename sanitization, path-traversal protection, per-user temp
  isolation, rate limiting, per-user + global concurrency limits, safe
  subprocess argument lists (never shell), timeouts, automatic cleanup.
* Automatic Python dependency installation on first run (AUTO_INSTALL_DEPS=1,
  the default) and optional Local Telegram Bot API support when present.

Configuration (all environment variables, see .env.example):
  Required : BOT_TOKEN
  Core     : ADMIN_IDS, DATABASE_PATH, MAX_FILE_SIZE, TEMP_DIRECTORY, LOG_FILE
  Optional : FONT_PATH, FFMPEG_PATH, ADMIN_CONTACT_URL, VIDEO_TIMEOUT,
             PROCESS_TIMEOUT, MAX_UPLOAD_SIZE, MAX_PDF_PAGES, MAX_IMAGE_PIXELS,
             RATE_PER_MIN, MAX_BATCH, MAX_CONCURRENT_JOBS, AUTO_INSTALL_DEPS,
             USE_LOCAL_BOT_API, TELEGRAM_API_BASE_URL, TELEGRAM_API_FILE_URL,
             AUTO_START_LOCAL_BOT_API, TELEGRAM_LOCAL_API_PORT,
             TELEGRAM_API_ID, TELEGRAM_API_HASH
"""

from __future__ import annotations

# ==========================================================================
# 0. Standard library only — the dependency bootstrap below must be able to
#    run before any third-party package is imported.
# ==========================================================================
import argparse
import asyncio
import html
import importlib.util
import io
import json
import logging
import os
import re
import shutil
import subprocess
import sqlite3
import sys
import threading
import time
import unicodedata
import uuid
import zipfile
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Sequence, Tuple

APP_NAME = "viraj-watermark"
APP_VERSION = "2.0.0"
MIN_PYTHON = (3, 10)

# --------------------------------------------------------------------------
# Automatic dependency installation
# --------------------------------------------------------------------------
# (import name, pip requirement, human description).  `pymupdf` also ships the
# legacy `fitz` shim, so it is considered installed when either is importable.
REQUIREMENTS: List[Tuple[str, str, str]] = [
    ("telegram", "python-telegram-bot[job-queue]>=21.0", "Telegram Bot API framework"),
    ("PIL", "Pillow>=10.0", "image processing"),
    ("pymupdf", "PyMuPDF>=1.24", "PDF support"),
    ("psutil", "psutil>=5.9", "system monitoring for the admin panel"),
    ("dotenv", "python-dotenv>=1.0", ".env file support"),
    ("imageio_ffmpeg", "imageio-ffmpeg>=0.4.9", "bundled FFmpeg fallback for videos"),
]

_IMPORT_ALIASES: Dict[str, Tuple[str, ...]] = {"pymupdf": ("fitz",)}


def _module_available(import_name: str) -> bool:
    """True when `import_name` (or one of its legacy aliases) is importable."""
    for name in (import_name,) + _IMPORT_ALIASES.get(import_name, ()):
        try:
            if importlib.util.find_spec(name) is not None:
                return True
        except (ImportError, ValueError):
            continue
    return False


def _missing_requirements() -> List[Tuple[str, str, str]]:
    return [r for r in REQUIREMENTS if not _module_available(r[0])]


def _pip_install(specs: Sequence[str]) -> Tuple[int, str]:
    """Install `specs` with pip. Never uses a shell; args are passed as a list."""
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
           "--no-input", "--no-compile"]
    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    if not in_venv:
        try:  # system Python without write access -> install into the user site
            import site

            targets = site.getsitepackages() or [site.getusersitepackages()]
            if targets and not os.access(targets[0], os.W_OK):
                cmd.append("--user")
        except Exception:  # noqa: BLE001 - best effort only
            pass
    cmd.extend(specs)
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    except (OSError, subprocess.SubprocessError) as exc:
        return 1, str(exc)
    output = (proc.stdout or "") + (proc.stderr or "")
    if proc.returncode != 0 and "externally-managed-environment" in output:
        # PEP 668 (Debian/Ubuntu): retry with the explicit opt-out flag.
        cmd.insert(len(cmd) - len(specs), "--break-system-packages")
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        except (OSError, subprocess.SubprocessError) as exc:
            return 1, str(exc)
        output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode, output


def ensure_dependencies(auto_install: Optional[bool] = None) -> None:
    """Verify (and optionally install) the Python dependencies.

    Controlled by AUTO_INSTALL_DEPS (default: 1).  When installation is
    disabled and packages are missing, the process exits with instructions.
    """
    if sys.version_info < MIN_PYTHON:
        sys.exit(f"❌ Python {'.'.join(map(str, MIN_PYTHON))}+ is required "
                 f"(found {sys.version.split()[0]}).")

    if auto_install is None:
        auto_install = os.getenv("AUTO_INSTALL_DEPS", "1").strip().lower() in {
            "1", "true", "yes", "on"}

    missing = _missing_requirements()
    if not missing:
        return

    print("=" * 68)
    print("  Viraj Watermark — first-run dependency setup")
    print("=" * 68)
    for _mod, spec, desc in missing:
        print(f"  • missing: {spec:<38} ({desc})")
    if not auto_install:
        print("\nAUTO_INSTALL_DEPS is disabled. Install them manually:")
        print("  " + sys.executable + " -m pip install -r requirements.txt")
        sys.exit(1)

    print(f"\n📦 Installing {len(missing)} package(s) with pip… (this happens once)")
    code, output = _pip_install([spec for _m, spec, _d in missing])
    still_missing = _missing_requirements()
    if code != 0 and still_missing:
        print("❌ Automatic installation failed. pip output (tail):\n")
        print("\n".join(output.strip().splitlines()[-25:]))
        print("\nInstall them manually, then start the bot again:")
        print("  " + sys.executable + " -m pip install " +
              " ".join(repr(spec) for _m, spec, _d in still_missing))
        sys.exit(1)
    if still_missing:
        print("❌ Some packages are still unavailable: " +
              ", ".join(spec for _m, spec, _d in still_missing))
        sys.exit(1)
    print(f"✅ Dependencies installed.\n")


ensure_dependencies()

# ==========================================================================
# 1. Third-party imports (safe now that dependencies are guaranteed present)
# ==========================================================================
try:  # optional convenience: load .env automatically when present
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover
    pass

import psutil  # noqa: E402
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont  # noqa: E402

try:  # PyMuPDF >= 1.24.3 exposes the modern `pymupdf` name
    import pymupdf as fitz  # noqa: E402
except ImportError:  # pragma: no cover - older releases
    try:
        import fitz  # type: ignore[no-redef]  # noqa: E402
    except ImportError:
        fitz = None  # type: ignore[assignment]

from telegram import (  # noqa: E402
    BotCommand,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    Update,
)
from telegram.constants import ParseMode  # noqa: E402
from telegram.error import (  # noqa: E402
    BadRequest,
    InvalidToken,
    NetworkError,
    RetryAfter,
    TelegramError,
    TimedOut,
)
from telegram.ext import (  # noqa: E402
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

# ==========================================================================
# 2. Logging — never emits tokens, api hashes or file contents
# ==========================================================================
LOG = logging.getLogger(APP_NAME)

_TOKEN_RE = re.compile(r"\b\d{5,12}:[A-Za-z0-9_-]{20,}\b")
_HASH_RE = re.compile(r"\b[0-9a-f]{32}\b", re.IGNORECASE)


class RedactingFilter(logging.Filter):
    """Scrubs bot tokens / api hashes out of every log record."""

    def __init__(self) -> None:
        super().__init__()
        self._secrets: set = set()

    def add_secret(self, secret: Optional[str]) -> None:
        if secret and len(secret) >= 8:
            self._secrets.add(secret)

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # noqa: BLE001
            return True
        cleaned = msg
        for secret in self._secrets:
            cleaned = cleaned.replace(secret, "***REDACTED***")
        cleaned = _TOKEN_RE.sub("***TOKEN***", cleaned)
        cleaned = _HASH_RE.sub("***HASH***", cleaned)
        if cleaned != msg:
            record.msg = cleaned
            record.args = ()
        return True


REDACTOR = RedactingFilter()


def _setup_logging() -> None:
    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s")
    LOG.handlers.clear()
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(fmt)
    stream.addFilter(REDACTOR)
    LOG.addHandler(stream)
    log_file = os.getenv("LOG_FILE", "").strip()
    if log_file:
        try:
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setFormatter(fmt)
            fh.addFilter(REDACTOR)
            LOG.addHandler(fh)
        except OSError as exc:
            LOG.warning("Could not open LOG_FILE=%s: %s", log_file, exc)
    LOG.setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)


# ==========================================================================
# 3. Configuration — environment variables only, no hardcoded secrets
# ==========================================================================
TOKEN_RE = re.compile(r"^\d{5,16}:[A-Za-z0-9_-]{30,}$")


def _env_int(name: str, default: int, minimum: int = 0, maximum: int = 2 ** 62) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        LOG.warning("%s=%r is not an integer; using default %s", name, raw, default)
        return default
    return max(minimum, min(maximum, value))


def _env_float(name: str, default: float, minimum: float, maximum: float) -> float:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = float(raw)
    except ValueError:
        LOG.warning("%s=%r is not a number; using default %s", name, raw, default)
        return default
    return max(minimum, min(maximum, value))


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name, "").strip().lower()
    if not raw:
        return default
    return raw in {"1", "true", "yes", "on", "y"}


@dataclass
class Config:
    bot_token: str
    admin_ids: List[int]
    database_path: str
    max_file_size: int
    temp_directory: str
    font_path: str
    ffmpeg_path: str
    admin_contact_url: str
    video_timeout: int
    process_timeout: int
    local_api_base_url: str
    local_api_file_url: str
    telegram_api_id: int
    telegram_api_hash: str
    upload_limit: int
    max_pdf_pages: int
    max_image_pixels: int
    rate_per_min: int
    max_batch: int
    max_concurrent_jobs: int
    state_ttl: int
    use_local_bot_api: bool
    auto_start_local_bot_api: bool
    local_api_port: int
    log_file: str

    @staticmethod
    def from_env() -> "Config":
        token = os.getenv("BOT_TOKEN", "").strip()
        if not token:
            raise SystemExit(
                "❌ BOT_TOKEN is not set.\n"
                "   1) Create a bot with @BotFather and copy the token.\n"
                "   2) Copy .env.example to .env and set:  BOT_TOKEN=123456:ABC...\n"
                "   (A token is never read from the source code.)"
            )
        if not TOKEN_RE.match(token):
            raise SystemExit(
                "❌ BOT_TOKEN does not look like a Telegram bot token "
                "(expected '<numeric_id>:<35-char secret>').\n"
                "   Re-copy it from @BotFather, with no spaces or quotes."
            )

        admins: List[int] = []
        for part in re.split(r"[,\s;]+", os.getenv("ADMIN_IDS", "").strip()):
            if re.fullmatch(r"\d{3,15}", part):
                admins.append(int(part))
        if not admins:
            LOG.warning("ADMIN_IDS is empty — the admin panel will be unreachable. "
                        "Set ADMIN_IDS=<your numeric Telegram id> in .env.")

        cwd = Path.cwd()
        tmp = os.getenv("TEMP_DIRECTORY", "").strip() or str(cwd / "wm_temp")
        db_path = os.getenv("DATABASE_PATH", "").strip() or str(cwd / "watermark_bot.db")

        use_local = _env_bool("USE_LOCAL_BOT_API", False)
        default_base = "http://127.0.0.1:8081/bot" if use_local else ""
        default_file = "http://127.0.0.1:8081/file/bot" if use_local else ""
        base_url = os.getenv("TELEGRAM_API_BASE_URL", default_base).strip().rstrip("/")
        file_url = os.getenv("TELEGRAM_API_FILE_URL", default_file).strip().rstrip("/")

        cfg = Config(
            bot_token=token,
            admin_ids=admins,
            database_path=db_path,
            max_file_size=_env_int("MAX_FILE_SIZE", 2 * 1024 * 1024 * 1024,
                                   minimum=1024 * 1024),
            temp_directory=tmp,
            font_path=os.getenv("FONT_PATH", "").strip(),
            ffmpeg_path=os.getenv("FFMPEG_PATH", "").strip(),
            admin_contact_url=os.getenv("ADMIN_CONTACT_URL", "").strip(),
            video_timeout=_env_int("VIDEO_TIMEOUT", 900, minimum=30, maximum=6 * 3600),
            process_timeout=_env_int("PROCESS_TIMEOUT", 240, minimum=15, maximum=3600),
            local_api_base_url=base_url,
            local_api_file_url=file_url,
            telegram_api_id=_env_int("TELEGRAM_API_ID", 0),
            telegram_api_hash=os.getenv("TELEGRAM_API_HASH", "").strip(),
            upload_limit=_env_int("MAX_UPLOAD_SIZE", 2 * 1024 * 1024 * 1024,
                                  minimum=1024 * 1024),
            max_pdf_pages=_env_int("MAX_PDF_PAGES", 400, minimum=1, maximum=5000),
            max_image_pixels=_env_int("MAX_IMAGE_PIXELS", 178_956_970,
                                      minimum=1_000_000, maximum=1_000_000_000),
            rate_per_min=_env_int("RATE_PER_MIN", 60, minimum=5, maximum=600),
            max_batch=_env_int("MAX_BATCH", 10, minimum=2, maximum=50),
            max_concurrent_jobs=_env_int("MAX_CONCURRENT_JOBS", 4, minimum=1, maximum=64),
            state_ttl=_env_int("STATE_TTL", 3600, minimum=60, maximum=24 * 3600),
            use_local_bot_api=use_local,
            auto_start_local_bot_api=_env_bool("AUTO_START_LOCAL_BOT_API", False),
            local_api_port=_env_int("TELEGRAM_LOCAL_API_PORT", 8081, minimum=1,
                                    maximum=65535),
            log_file=os.getenv("LOG_FILE", "").strip(),
        )
        REDACTOR.add_secret(cfg.bot_token)
        REDACTOR.add_secret(cfg.telegram_api_hash)
        return cfg


CFG: Config = None  # type: ignore[assignment]  # set in main()/selftest
START_TIME = time.time()

# Telegram transport realities (documented, not guessed):
STANDARD_API_DOWNLOAD_LIMIT = 20 * 1024 * 1024   # getFile download cap
STANDARD_API_UPLOAD_LIMIT = 50 * 1024 * 1024     # sendDocument/sendVideo cap

# ==========================================================================
# 4. Constants & defaults
# ==========================================================================
POSITIONS: Dict[str, Tuple[str, str]] = {
    "top_left": ("Top Left", "↖️"),
    "top_center": ("Top Center", "⬆️"),
    "top_right": ("Top Right", "↗️"),
    "center_left": ("Center Left", "⬅️"),
    "center": ("Center", "🎯"),
    "center_right": ("Center Right", "➡️"),
    "bottom_left": ("Bottom Left", "↙️"),
    "bottom_center": ("Bottom Center", "⬇️"),
    "bottom_right": ("Bottom Right", "↘️"),
    "custom": ("Custom Coords", "🎯"),
}
POSITION_KEYS = tuple(POSITIONS)

FONT_FAMILIES = ["Roboto", "Arial", "Serif", "Mono", "Comic"]
BADGES = {"plain": "✨ Plain Text", "box": "🧊 Badge Box", "tile": "🔁 Tiled Pattern"}
MODES = ("text", "logo", "both")
MEDIA_KEYS = ("global", "image", "pdf", "video")

DEFAULT_SETTINGS: Dict[str, Any] = {
    "enabled": True,
    "mode": "text",            # text | logo | both
    "text": "@VirajWatermark",
    "font": "Roboto",
    "bold": True,
    "italic": False,
    "font_size": 36,
    "color": "#FFFFFF",
    "opacity": 75,
    "position": "bottom_right",
    "custom_x": 20,
    "custom_y": 20,
    "margin": 20,
    "rotation": 0,
    "tiled": False,
    "tile_spacing": 60,
    "stroke": True,
    "stroke_width": 2,
    "stroke_color": "#000000",
    "shadow": True,
    "badge": "plain",
    "logo_scale": 30,          # % of the shortest side
    "logo_opacity": 75,
    "logo_rotation": 0,
    "logo_tiled": False,
    "pdf_pages": "all",
    "animation": "none",
    "animation_speed": 1.0,
}

VIDEO_ANIMATIONS = {
    "none": "⏸️ None", "dvd_bounce": "📀 DVD Bounce", "left_right": "↔️ Left ↔ Right",
    "up_down": "↕️ Up ↕ Down", "diagonal": "↗️ Diagonal", "circle": "⭕ Circle",
    "figure8": "♾️ Figure 8", "shake": "📳 Shake", "pulse": "💓 Pulse",
    "zoom": "🔍 Zoom", "spin": "🌀 Spin", "swing": "🎵 Swing",
    "wave": "🌊 Wave", "zigzag": "⚡ Zigzag", "random": "🎲 Random",
    "bounce": "🏀 Bounce", "corner": "🔲 Corners", "spiral": "🌀 Spiral",
    "horizontal_scan": "📡 Horizontal Scan", "vertical_scan": "📡 Vertical Scan",
    "pendulum": "⏳ Pendulum", "orbit": "🪐 Orbit", "drift": "☁️ Drift",
    "strobe": "✨ Strobe", "elastic": "🪀 Elastic", "float": "🎈 Float",
}

MEDIA_LABELS = {
    "global": ("🌐", "Global Default Settings", "Global Defaults"),
    "image": ("🖼️", "Image Watermark Settings", "Image"),
    "pdf": ("📄", "PDF Watermark Settings", "PDF"),
    "video": ("🎥", "Video Watermark Settings", "Video"),
}

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
PDF_EXTS = {".pdf"}
VIDEO_EXTS = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v"}
SUPPORTED_EXTS = IMAGE_EXTS | PDF_EXTS | VIDEO_EXTS
MAX_LOGO_BYTES = 8 * 1024 * 1024
MAX_TEXT_LEN = 100


class WatermarkError(Exception):
    """User-facing, safe-to-display processing error."""


# ==========================================================================
# 5. Small utilities & input validation
# ==========================================================================
def serif_bold(text: str) -> str:
    """Convert ASCII to Mathematical Bold Serif unicode (matches the design)."""
    out = []
    for ch in text:
        o = ord(ch)
        if 65 <= o <= 90:
            out.append(chr(0x1D400 + o - 65))
        elif 97 <= o <= 122:
            out.append(chr(0x1D41A + o - 97))
        elif 48 <= o <= 57:
            out.append(chr(0x1D7CE + o - 48))
        else:
            out.append(ch)
    return "".join(out)


def _dw(s: str) -> int:
    return sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in s)


def _pad(s: str, w: int) -> str:
    return s + " " * max(0, w - _dw(s))


def _trunc(s: str, w: int) -> str:
    return s if _dw(s) <= w else s[: max(0, w - 1)] + "…"


def box_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    """Plain-text table with box-drawing grid lines (rendered inside <pre>)."""
    rows = [[str(c) for c in r] for r in rows]
    widths = [_dw(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            if i < len(widths):
                widths[i] = max(widths[i], _dw(c))
            else:
                widths.append(_dw(c))
    bar = lambda l, m, r: l + m.join("─" * (w + 2) for w in widths) + r  # noqa: E731
    lines = [bar("┌", "┬", "┐")]
    lines.append("│" + "│".join(f" {_pad(h, w)} " for h, w in zip(headers, widths)) + "│")
    lines.append(bar("├", "┼", "┤"))
    for r in rows:
        cells = [f" {_pad(c, w)} " for c, w in zip(r, widths)]
        cells += ["  "] * (len(widths) - len(cells))
        lines.append("│" + "│".join(cells) + "│")
    lines.append(bar("└", "┴", "┘"))
    return "\n".join(lines)


def esc(value: Any) -> str:
    return html.escape(str(value))


_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def sanitize_filename(name: Optional[str]) -> str:
    """Prevent path traversal / weird names; returns a unique safe basename."""
    name = (name or "").replace("\\", "/").split("/")[-1]
    name = _CONTROL_RE.sub("", name)
    name = re.sub(r"[^A-Za-z0-9._-]", "_", name).strip("._")
    if not name:
        name = "file"
    return f"{uuid.uuid4().hex[:8]}_{name[:80]}"


def sanitize_watermark_text(text: Optional[str]) -> str:
    """Strip control characters and zero-width junk, enforce the length limit."""
    text = _CONTROL_RE.sub("", (text or "").replace("\u200b", "")).strip()
    text = "".join(ch for ch in text if ch == "\n" or unicodedata.category(ch)[0] != "C")
    return text[:MAX_TEXT_LEN]


def human_size(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} TB"


def human_duration(sec: float) -> str:
    sec = int(max(0, sec))
    d, rem = divmod(sec, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    if d:
        return f"{d}d {h}h {m}m"
    return f"{h}h {m}m {s}s" if h else f"{m}m {s}s"


def hex_to_rgb(color: Any) -> Tuple[int, int, int]:
    c = str(color or "").strip().lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    if len(c) != 6 or any(ch not in "0123456789abcdefABCDEF" for ch in c):
        raise WatermarkError("Invalid color code. Use hex like #FFFFFF.")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def normalize_hex(color: Any, default: str = "#FFFFFF") -> str:
    """Return '#RRGGBB' (uppercase) or fall back to `default`."""
    try:
        r, g, b = hex_to_rgb(color)
    except WatermarkError:
        r, g, b = hex_to_rgb(default)
    return f"#{r:02X}{g:02X}{b:02X}"


def parse_page_spec(spec: str, total: int) -> List[int]:
    """'all' or '1,3-5' -> zero based page indices."""
    spec = (spec or "").strip().lower()
    if spec in ("", "all"):
        return list(range(total))
    if len(spec) > 100:
        raise WatermarkError("Page selection is too long.")
    pages: List[int] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, _, b = part.partition("-")
            if not a.isdigit() or not b.isdigit():
                raise WatermarkError("Invalid page range. Example: 1,3-5")
            lo, hi = int(a), int(b)
            if lo > hi:
                lo, hi = hi, lo
            if hi - lo > 5000:
                raise WatermarkError("Page range is too large.")
            pages.extend(range(lo, hi + 1))
        elif part.isdigit():
            pages.append(int(part))
        else:
            raise WatermarkError("Invalid page list. Example: 1,3-5 or 'all'.")
    pages = sorted({p for p in pages if 1 <= p <= total})
    if not pages:
        raise WatermarkError("No valid pages selected.")
    return [p - 1 for p in pages]


def _clamp_int(value: Any, low: int, high: int, default: int) -> int:
    try:
        return max(low, min(high, int(value)))
    except (TypeError, ValueError):
        return default


def _clamp_float(value: Any, low: float, high: float, default: float) -> float:
    try:
        return max(low, min(high, float(value)))
    except (TypeError, ValueError):
        return default


def _as_bool(value: Any, default: bool = False) -> bool:
    return bool(value) if isinstance(value, (bool, int, str)) else default


def sanitize_settings(data: Any) -> Dict[str, Any]:
    """Coerce persisted/JSON settings into a fully valid settings dict.

    Protects against corrupted database rows and hand-edited JSON by clamping
    every value into a safe range and validating every enum-like field.
    """
    raw = data if isinstance(data, dict) else {}
    d = dict(DEFAULT_SETTINGS)
    d["enabled"] = _as_bool(raw.get("enabled", True), True)

    mode = str(raw.get("mode", "text"))
    d["mode"] = mode if mode in MODES else "text"

    d["text"] = sanitize_watermark_text(raw.get("text")) or DEFAULT_SETTINGS["text"]

    font = str(raw.get("font", "Roboto"))
    d["font"] = font if font in FONT_FAMILIES else "Roboto"
    d["bold"] = _as_bool(raw.get("bold", True), True)
    d["italic"] = _as_bool(raw.get("italic", False), False)

    d["font_size"] = _clamp_int(raw.get("font_size"), 8, 400, DEFAULT_SETTINGS["font_size"])
    d["color"] = normalize_hex(raw.get("color"), DEFAULT_SETTINGS["color"])
    d["opacity"] = _clamp_int(raw.get("opacity"), 0, 100, DEFAULT_SETTINGS["opacity"])

    position = str(raw.get("position", "bottom_right"))
    d["position"] = position if position in POSITIONS else "bottom_right"
    d["custom_x"] = _clamp_int(raw.get("custom_x"), -100000, 100000, 20)
    d["custom_y"] = _clamp_int(raw.get("custom_y"), -100000, 100000, 20)
    d["margin"] = _clamp_int(raw.get("margin"), 0, 10000, 20)
    d["rotation"] = _clamp_int(raw.get("rotation"), -360, 360, 0)

    d["tiled"] = _as_bool(raw.get("tiled", False), False)
    d["tile_spacing"] = _clamp_int(raw.get("tile_spacing"), 0, 5000, 60)

    d["stroke"] = _as_bool(raw.get("stroke", True), True)
    d["stroke_width"] = _clamp_int(raw.get("stroke_width"), 0, 40, 2)
    d["stroke_color"] = normalize_hex(raw.get("stroke_color"), "#000000")
    d["shadow"] = _as_bool(raw.get("shadow", True), True)

    badge = str(raw.get("badge", "plain"))
    d["badge"] = badge if badge in BADGES else "plain"

    d["logo_scale"] = _clamp_int(raw.get("logo_scale"), 1, 200, 30)
    d["logo_opacity"] = _clamp_int(raw.get("logo_opacity"), 0, 100, 75)
    d["logo_rotation"] = _clamp_int(raw.get("logo_rotation"), -360, 360, 0)
    d["logo_tiled"] = _as_bool(raw.get("logo_tiled", False), False)

    pages = str(raw.get("pdf_pages", "all")).strip()[:100] or "all"
    d["pdf_pages"] = pages

    animation = str(raw.get("animation", "none"))
    d["animation"] = animation if animation in VIDEO_ANIMATIONS else "none"
    d["animation_speed"] = round(_clamp_float(raw.get("animation_speed"), 0.1, 8.0, 1.0), 2)
    return d


# ==========================================================================
# 6. Font discovery
# ==========================================================================
_FONT_CACHE: Dict[str, str] = {}
_FONT_LOCK = threading.Lock()
_FONT_DIRS = [
    "/usr/share/fonts",
    "/usr/local/share/fonts",
    "/System/Library/Fonts",
    os.path.expanduser("~/.fonts"),
    os.path.expanduser("~/.local/share/fonts"),
    "C:/Windows/Fonts",
]

_FAMILY_CANDIDATES = {
    "Roboto": ["Roboto-Bold.ttf", "Roboto-Regular.ttf", "DejaVuSans-Bold.ttf", "DejaVuSans.ttf"],
    "Arial": ["Arial Bold.ttf", "Arial-Bold.ttf", "Arial.ttf", "DejaVuSans-Bold.ttf", "DejaVuSans.ttf"],
    "Serif": ["DejaVuSerif-Bold.ttf", "DejaVuSerif.ttf", "FreeSerif.ttf", "Georgia.ttf", "Times New Roman.ttf"],
    "Mono": ["DejaVuSansMono-Bold.ttf", "DejaVuSansMono.ttf", "FreeMono.ttf", "Consolas.ttf"],
    "Comic": ["Comic Sans MS.ttf", "ComicSansMS.ttf", "DejaVuSans.ttf"],
}


def _scan_fonts() -> None:
    with _FONT_LOCK:
        if _FONT_CACHE:
            return
        count = 0
        for root in _FONT_DIRS:
            if not os.path.isdir(root):
                continue
            for base, _dirs, files in os.walk(root):
                for fn in files:
                    if fn.lower().endswith((".ttf", ".otf")):
                        _FONT_CACHE.setdefault(fn, os.path.join(base, fn))
                        count += 1
                if count > 4000:
                    return


def get_font(family: str, bold: bool, size: int) -> ImageFont.FreeTypeFont:
    size = max(8, int(size))
    _scan_fonts()
    if CFG and CFG.font_path and os.path.isfile(CFG.font_path):
        try:
            return ImageFont.truetype(CFG.font_path, size)
        except Exception:  # noqa: BLE001
            LOG.debug("Configured FONT_PATH could not be loaded; falling back.")
    cands = list(_FAMILY_CANDIDATES.get(family, _FAMILY_CANDIDATES["Roboto"]))
    cands.sort(key=lambda f: (0 if "bold" in f.lower() else 1) if bold
               else (1 if "bold" in f.lower() else 0))
    with _FONT_LOCK:
        snapshot = dict(_FONT_CACHE)
    for fn in cands:
        path = snapshot.get(fn)
        if path:
            try:
                return ImageFont.truetype(path, size)
            except Exception:  # noqa: BLE001
                continue
    for path in list(snapshot.values())[:50]:
        try:
            return ImageFont.truetype(path, size)
        except Exception:  # noqa: BLE001
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:  # very old Pillow
        return ImageFont.load_default()


# ==========================================================================
# 7. SQLite persistence
# ==========================================================================
class Database:
    def __init__(self, path: str) -> None:
        self.path = path
        self._lock = threading.Lock()
        parent = os.path.dirname(os.path.abspath(path))
        os.makedirs(parent, exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False, timeout=30)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA busy_timeout=10000")
            self._conn.execute("PRAGMA foreign_keys=ON")
        self._init_schema()

    def _init_schema(self) -> None:
        with self._lock, self._conn:
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    is_blocked INTEGER DEFAULT 0,
                    created_at TEXT,
                    last_activity TEXT
                );
                CREATE TABLE IF NOT EXISTS settings (
                    user_id INTEGER,
                    media TEXT,
                    data TEXT,
                    updated_at TEXT,
                    PRIMARY KEY (user_id, media)
                );
                CREATE TABLE IF NOT EXISTS stats (
                    user_id INTEGER PRIMARY KEY,
                    images INTEGER DEFAULT 0,
                    pdfs INTEGER DEFAULT 0,
                    videos INTEGER DEFAULT 0,
                    batches INTEGER DEFAULT 0,
                    errors INTEGER DEFAULT 0,
                    last_processed TEXT
                );
                CREATE TABLE IF NOT EXISTS kv (
                    key TEXT PRIMARY KEY,
                    value TEXT
                );
                CREATE TABLE IF NOT EXISTS error_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT,
                    user_id INTEGER,
                    context TEXT,
                    message TEXT
                );
                """
            )

    # -- low level ---------------------------------------------------------
    def q(self, sql: str, params: Tuple = ()) -> List[sqlite3.Row]:
        with self._lock, self._conn:
            return self._conn.execute(sql, params).fetchall()

    def execute(self, sql: str, params: Tuple = ()) -> None:
        with self._lock, self._conn:
            self._conn.execute(sql, params)

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except sqlite3.Error:  # pragma: no cover
                pass

    # -- users -------------------------------------------------------------
    def touch_user(self, uid: int, username: str, first_name: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO users(id, username, first_name, created_at, last_activity) "
                "VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET username=excluded.username, "
                "first_name=excluded.first_name, last_activity=excluded.last_activity",
                (uid, (username or "")[:64], (first_name or "")[:64], now, now),
            )
            self._conn.execute("INSERT OR IGNORE INTO stats(user_id) VALUES(?)", (uid,))
            self._conn.execute(
                "INSERT OR IGNORE INTO settings(user_id, media, data, updated_at) VALUES(?,?,?,?)",
                (uid, "global", json.dumps(DEFAULT_SETTINGS), now),
            )

    def is_blocked(self, uid: int) -> bool:
        row = self.q("SELECT is_blocked FROM users WHERE id=?", (uid,))
        return bool(row and row[0]["is_blocked"])

    def set_blocked(self, uid: int, blocked: bool) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.execute(
            "INSERT INTO users(id, is_blocked, created_at, last_activity) VALUES(?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET is_blocked=excluded.is_blocked",
            (uid, int(bool(blocked)), now, now),
        )

    def all_user_ids(self) -> List[int]:
        return [r["id"] for r in self.q("SELECT id FROM users WHERE is_blocked=0")]

    def user_stats(self, uid: int) -> sqlite3.Row:
        rows = self.q("SELECT * FROM stats WHERE user_id=?", (uid,))
        return rows[0] if rows else None  # type: ignore[return-value]

    # -- settings ----------------------------------------------------------
    def get_settings(self, uid: int, media: str) -> Dict[str, Any]:
        if media not in MEDIA_KEYS:
            media = "global"
        row = self.q("SELECT data FROM settings WHERE user_id=? AND media=?", (uid, media))
        data: Dict[str, Any] = {}
        if row:
            try:
                loaded = json.loads(row[0]["data"] or "{}")
                if isinstance(loaded, dict):
                    data = loaded
                else:
                    LOG.warning("Discarding non-dict settings for user=%s media=%s", uid, media)
            except (json.JSONDecodeError, TypeError):
                LOG.warning("Discarding corrupt settings JSON for user=%s media=%s", uid, media)
        if not data:
            if media == "global":
                data = dict(DEFAULT_SETTINGS)
            else:
                data = self.get_settings(uid, "global")  # inherit global defaults
            self.save_settings(uid, media, data)
        return sanitize_settings(data)

    def save_settings(self, uid: int, media: str, data: Dict[str, Any]) -> None:
        if media not in MEDIA_KEYS:
            raise ValueError(f"unknown media category: {media}")
        clean = sanitize_settings(data)
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO settings(user_id, media, data, updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(user_id, media) DO UPDATE SET data=excluded.data, "
                "updated_at=excluded.updated_at",
                (uid, media, json.dumps(clean), now),
            )

    def reset_settings(self, uid: int, media: str) -> None:
        self.save_settings(uid, media, dict(DEFAULT_SETTINGS))

    # -- stats -------------------------------------------------------------
    def bump_stat(self, uid: int, kind: str) -> None:
        col = {"image": "images", "pdf": "pdfs", "video": "videos", "batch": "batches",
               "error": "errors"}.get(kind)
        if not col:
            return
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._conn:
            self._conn.execute("INSERT OR IGNORE INTO stats(user_id) VALUES(?)", (uid,))
            # `col` comes from a fixed whitelist above — never user input.
            self._conn.execute(
                f"UPDATE stats SET {col}={col}+1, last_processed=? WHERE user_id=?", (now, uid))

    def totals(self) -> Dict[str, int]:
        row = self.q(
            "SELECT COALESCE(SUM(images),0) i, COALESCE(SUM(pdfs),0) p, "
            "COALESCE(SUM(videos),0) v, COALESCE(SUM(batches),0) b, "
            "COALESCE(SUM(errors),0) e FROM stats")[0]
        return {"images": row["i"], "pdfs": row["p"], "videos": row["v"],
                "batches": row["b"], "errors": row["e"]}

    def user_counts(self) -> Tuple[int, int]:
        total = self.q("SELECT COUNT(*) c FROM users")[0]["c"]
        cutoff = datetime.fromtimestamp(time.time() - 7 * 86400, timezone.utc).isoformat()
        week = self.q("SELECT COUNT(*) c FROM users WHERE last_activity > ?", (cutoff,))[0]["c"]
        return total, week

    # -- kv ----------------------------------------------------------------
    def kv_get(self, key: str, default: str) -> str:
        row = self.q("SELECT value FROM kv WHERE key=?", (key,))
        return row[0]["value"] if row else default

    def kv_set(self, key: str, value: str) -> None:
        self.execute(
            "INSERT INTO kv(key, value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    # -- errors ------------------------------------------------------------
    def log_error(self, uid: Optional[int], context: str, message: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO error_log(ts, user_id, context, message) VALUES(?,?,?,?)",
                (datetime.now(timezone.utc).isoformat(), uid, str(context)[:40],
                 str(message)[:500]),
            )
            self._conn.execute(
                "DELETE FROM error_log WHERE id NOT IN "
                "(SELECT id FROM error_log ORDER BY id DESC LIMIT 200)")

    def recent_errors(self, limit: int = 8) -> List[sqlite3.Row]:
        return self.q("SELECT * FROM error_log ORDER BY id DESC LIMIT ?", (int(limit),))


DB: Database = None  # type: ignore[assignment]


# ==========================================================================
# 8. Runtime limits (kv-backed, admin configurable)
# ==========================================================================
def limit_max_batch() -> int:
    try:
        return max(2, min(50, int(DB.kv_get("max_batch", str(CFG.max_batch)))))
    except (TypeError, ValueError):
        return CFG.max_batch


def limit_rate_per_min() -> int:
    try:
        return max(5, min(600, int(DB.kv_get("rate_per_min", str(CFG.rate_per_min)))))
    except (TypeError, ValueError):
        return CFG.rate_per_min


def is_admin(uid: int) -> bool:
    if uid in CFG.admin_ids:
        return True
    extra = DB.kv_get("extra_admins", "")
    return any(x.strip().isdigit() and int(x.strip()) == uid for x in extra.split(","))


def extra_admin_ids() -> List[int]:
    extra = DB.kv_get("extra_admins", "")
    return [int(x) for x in extra.split(",") if x.strip().isdigit()]


# ==========================================================================
# 9. Watermark layer rendering (shared by image / pdf / video engines)
# ==========================================================================
def _apply_opacity(img: Image.Image, opacity: int) -> Image.Image:
    opacity = max(0, min(100, int(opacity)))
    if opacity >= 100:
        return img
    alpha = img.split()[3].point(lambda a: int(a * opacity / 100))
    img.putalpha(alpha)
    return img


def _render_text_tile(s: Dict[str, Any], px_scale: float) -> Image.Image:
    """Render the text watermark (stroke/shadow/badge/italic) on a tight RGBA tile."""
    text = sanitize_watermark_text(s.get("text")) or DEFAULT_SETTINGS["text"]
    px_scale = max(0.05, float(px_scale))
    size = max(8, int(s["font_size"] * px_scale))
    font = get_font(s["font"], s["bold"], size)
    stroke_w = max(0, int(round(s["stroke_width"] * px_scale))) if s["stroke"] else 0
    rgb = hex_to_rgb(s["color"])
    srgb = hex_to_rgb(s["stroke_color"])

    pad = stroke_w + int(6 * px_scale) + (int(10 * px_scale) if s["shadow"] else 0)
    dummy = Image.new("RGBA", (8, 8))
    d = ImageDraw.Draw(dummy)
    bbox = d.textbbox((0, 0), text, font=font, stroke_width=stroke_w)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]

    badge = s.get("badge") == "box"
    extra = int(14 * px_scale) if badge else 0
    w, h = tw + pad * 2 + extra, th + pad * 2 + extra
    tile = Image.new("RGBA", (max(2, int(w)), max(2, int(h))), (0, 0, 0, 0))
    draw = ImageDraw.Draw(tile)

    if s["shadow"]:
        off = max(1, int(3 * px_scale))
        draw.text((pad - bbox[0] + off, pad - bbox[1] + off), text, font=font,
                  fill=(0, 0, 0, 200), stroke_width=stroke_w, stroke_fill=(0, 0, 0, 200))
        tile = tile.filter(ImageFilter.GaussianBlur(max(1.0, 1.5 * px_scale)))
        draw = ImageDraw.Draw(tile)

    if badge:
        inset = int(4 * px_scale)
        draw.rounded_rectangle(
            [inset, inset, w - inset, h - inset],
            radius=int(10 * px_scale), fill=(20, 20, 25, 170),
            outline=(255, 255, 255, 160), width=max(1, int(round(1.5 * px_scale))),
        )
    draw.text((pad - bbox[0], pad - bbox[1]), text, font=font, fill=(*rgb, 255),
              stroke_width=stroke_w, stroke_fill=(*srgb, 255))

    if s.get("italic"):  # synthetic oblique when no true italic face exists
        slant = 0.22
        new_w = int(tile.width + slant * tile.height) + 2
        tile = tile.transform(
            (new_w, tile.height), Image.AFFINE,
            (1, -slant, slant * tile.height, 0, 1, 0), resample=Image.BICUBIC)
    return tile


def _render_logo_tile(s: Dict[str, Any], logo_path: str, px_scale: float,
                      base_side: int) -> Image.Image:
    with Image.open(logo_path) as logo:
        logo = logo.convert("RGBA")
        target = max(16, int(base_side * s["logo_scale"] / 100))
        if logo.width and logo.height:
            ratio = target / max(1, min(logo.width, logo.height))
            logo = logo.resize((max(1, int(logo.width * ratio)),
                                max(1, int(logo.height * ratio))), Image.LANCZOS)
        logo = _apply_opacity(logo, s["logo_opacity"])
        if s["logo_rotation"]:
            logo = logo.rotate(s["logo_rotation"], expand=True, resample=Image.BICUBIC)
        return logo


def _paste_tile(layer: Image.Image, tile: Image.Image, s: Dict[str, Any],
                px_scale: float, rotation: int, tiled: bool, spacing: int) -> None:
    if rotation:
        tile = tile.rotate(rotation, expand=True, resample=Image.BICUBIC)
    W, H = layer.size
    tw, th = tile.size
    margin = int(s["margin"] * px_scale)

    if tiled:
        step_x = max(1, tw + int(spacing * px_scale))
        step_y = max(1, th + int(spacing * px_scale))
        if tw > W or th > H:  # single oversized tile -> still draw once
            layer.alpha_composite(tile, (max(0, margin), max(0, margin)))
            return
        y = margin
        guard = 0
        while y < H and guard < 10000:
            x = margin
            while x < W and guard < 100000:
                layer.alpha_composite(tile, (int(x), int(y)))
                x += step_x
                guard += 1
            y += step_y
        return

    pos = s["position"]
    if pos == "custom":
        x = int(s["custom_x"] * px_scale)
        y = int(s["custom_y"] * px_scale)
    else:
        vy, vx = ("center", "center") if pos == "center" else pos.split("_", 1)
        x = {"left": margin, "center": (W - tw) // 2, "right": W - tw - margin}[vx]
        y = {"top": margin, "center": (H - th) // 2, "bottom": H - th - margin}[vy]
    layer.alpha_composite(tile, (max(0, int(x)), max(0, int(y))))


def build_watermark_layer(size: Tuple[int, int], s: Dict[str, Any],
                          logo_path: Optional[str], px_scale: float) -> Image.Image:
    """Full-frame transparent RGBA layer containing the configured watermark."""
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    mode = s.get("mode", "text")
    base_side = min(size) if min(size) > 0 else 1

    if mode in ("text", "both") and s.get("enabled", True):
        tile = _render_text_tile(s, px_scale)
        tile = _apply_opacity(tile, s["opacity"])
        _paste_tile(layer, tile, s, px_scale, s["rotation"], s["tiled"], s["tile_spacing"])

    if mode in ("logo", "both") and logo_path and os.path.isfile(logo_path):
        try:
            ltile = _render_logo_tile(s, logo_path, px_scale, base_side)
            _paste_tile(layer, ltile, s, px_scale, 0, s["logo_tiled"], s["tile_spacing"])
        except (OSError, ValueError) as exc:
            LOG.warning("Logo could not be rendered for user=%s: %s", s.get("_uid"), exc)
    return layer


def logos_dir() -> str:
    base = os.path.dirname(os.path.abspath(DB.path))
    d = os.path.join(base, "logos")
    os.makedirs(d, exist_ok=True)
    return d


def logo_file_for(uid: int, media: str) -> str:
    if media not in MEDIA_KEYS:
        media = "global"
    # uid is an int from Telegram; the name is sanitized defensively anyway.
    return os.path.join(logos_dir(), f"logo_{int(uid)}_{media}.png")


# ==========================================================================
# 10. IMAGE engine
# ==========================================================================
Image.MAX_IMAGE_PIXELS = None  # enforced explicitly via CFG.max_image_pixels


def _check_pixel_budget(im: Image.Image) -> None:
    limit = CFG.max_image_pixels if CFG else 178_956_970
    pixels = (im.width or 0) * (im.height or 0)
    if pixels > limit:
        raise WatermarkError(
            f"⚠️ This image is too large to process ({im.width}×{im.height}). "
            f"Pixel limit: {limit:,}.")


def _diff_pixels(a: Image.Image, b: Image.Image, threshold: int = 12) -> int:
    """Count visibly different pixels between two same-sized RGB images."""
    if a.size != b.size:
        return max(a.size[0] * a.size[1], b.size[0] * b.size[1])
    diff = ImageChops.difference(a, b).convert("L")
    mask = diff.point(lambda v: 255 if v > threshold else 0)
    hist = mask.histogram()
    return hist[255]


def process_image_file(src: str, dst: str, s: Dict[str, Any], uid: int) -> None:
    try:
        with Image.open(src) as im:
            im.load()
            _check_pixel_budget(im)
            original_format = (im.format or "PNG").upper()
            original_mode = im.mode
            exif = im.info.get("exif")
            base = im.convert("RGBA")
    except WatermarkError:
        raise
    except Image.DecompressionBombError:
        raise WatermarkError("⚠️ This image is too large or suspiciously compressed. "
                             "Please send a smaller file.")
    except Exception as exc:  # corrupted / unsupported / truncated
        raise WatermarkError(f"Could not read this image ({type(exc).__name__}). "
                             "The file may be corrupted or unsupported.") from exc

    px_scale = max(base.width, base.height) / 720.0
    layer = build_watermark_layer(
        base.size, s, logo_file_for(uid, "image") if s["mode"] != "text" else None, px_scale)
    base.alpha_composite(layer)

    out = base
    save_kwargs: Dict[str, Any] = {}
    fmt = original_format
    if fmt in ("JPEG", "JPG", "MPO"):
        fmt = "JPEG"
        out = base.convert("RGB")
        save_kwargs = {"quality": 95, "optimize": True}
        if exif and isinstance(exif, bytes) and len(exif) < 200_000:
            save_kwargs["exif"] = exif
    elif fmt == "PNG":
        save_kwargs = {"optimize": True}
        if original_mode == "P":
            out = out.convert("RGBA")
    elif fmt == "WEBP":
        save_kwargs = {"quality": 95, "method": 4}
        if original_mode not in ("RGBA", "LA"):
            out = base.convert("RGB")
    else:
        fmt = "PNG"
    try:
        out.save(dst, format=fmt, **save_kwargs)
    except Exception:  # noqa: BLE001 - safest fallback: lossless PNG
        LOG.warning("Could not save as %s; falling back to PNG", fmt)
        base.convert("RGBA").save(dst, format="PNG")


# ==========================================================================
# 11. PDF engine
# ==========================================================================
def process_pdf_file(src: str, dst: str, s: Dict[str, Any], uid: int,
                     progress: Optional[Callable[[int, int], None]] = None) -> int:
    if fitz is None:
        raise WatermarkError("PDF support is unavailable on this server (PyMuPDF missing).")
    try:
        doc = fitz.open(src)
    except Exception as exc:  # noqa: BLE001
        raise WatermarkError("This PDF could not be opened. It may be corrupted or "
                             "unsupported.") from exc
    try:
        if doc.is_encrypted and not doc.authenticate(""):
            raise WatermarkError("This PDF is password-protected. Please remove the "
                                 "password and try again.")
        total_pages = doc.page_count
        if total_pages <= 0:
            raise WatermarkError("This PDF contains no pages.")
        max_pages = CFG.max_pdf_pages if CFG else 400
        if total_pages > max_pages:
            raise WatermarkError(
                f"⚠️ This PDF has {total_pages} pages; the configured limit is {max_pages}.")
        pages = parse_page_spec(s.get("pdf_pages", "all"), total_pages)
        logo = logo_file_for(uid, "pdf") if s["mode"] != "text" else None
        for n, pno in enumerate(pages):
            page = doc[pno]
            rect = page.rect
            scale = (max(rect.width, rect.height) / 720.0) * 2.0
            layer = build_watermark_layer(
                (max(2, int(rect.width * 2)), max(2, int(rect.height * 2))), s, logo, scale)
            buf = io.BytesIO()
            layer.save(buf, format="PNG")
            layer.close()
            buf.seek(0)
            page.insert_image(rect, stream=buf.read(), overlay=True)
            if progress and (n + 1) % 5 == 0 or (progress and n + 1 == len(pages)):
                progress(n + 1, len(pages))
        doc.save(dst, garbage=3, deflate=True)
        return total_pages
    except WatermarkError:
        raise
    except RuntimeError as exc:  # MuPDF raises RuntimeError for broken documents
        raise WatermarkError("This PDF could not be processed (it may be damaged).") from exc
    except Exception as exc:  # noqa: BLE001
        raise WatermarkError("This PDF could not be processed. It may be damaged or "
                             "use an unsupported feature.") from exc
    finally:
        try:
            doc.close()
        except Exception:  # noqa: BLE001
            pass


# ==========================================================================
# 12. VIDEO engine (FFmpeg overlay of a pre-rendered transparent PNG layer)
# ==========================================================================
def _is_executable(path: Optional[str]) -> bool:
    return bool(path) and os.path.isfile(path) and os.access(path, os.X_OK)


def find_ffmpeg() -> Optional[str]:
    """Locate an ffmpeg binary: configured path -> PATH -> imageio-ffmpeg."""
    if CFG and CFG.ffmpeg_path and _is_executable(CFG.ffmpeg_path):
        return CFG.ffmpeg_path
    path = shutil.which("ffmpeg")
    if path:
        return path
    try:  # pip-bundled static binary fallback (great for Windows/VPS without apt)
        import imageio_ffmpeg

        candidate = imageio_ffmpeg.get_ffmpeg_exe()
        if _is_executable(candidate):
            return candidate
    except Exception:  # noqa: BLE001
        pass
    return None


def find_ffprobe(ffmpeg: str) -> Optional[str]:
    """Locate ffprobe next to ffmpeg, on PATH, or not at all."""
    candidate = shutil.which("ffprobe")
    if candidate:
        return candidate
    directory = os.path.dirname(ffmpeg)
    for name in ("ffprobe", "ffprobe.exe"):
        side = os.path.join(directory, name)
        if _is_executable(side):
            return side
    return None


FFMPEG_SETUP_MSG = (
    "⚠️ <b>FFmpeg is not installed on this server.</b>\n"
    "Video watermarking needs FFmpeg.\n\n"
    "<b>Ubuntu/Debian:</b> <code>sudo apt install ffmpeg</code>\n"
    "<b>Windows:</b> download from ffmpeg.org or <code>pip install imageio-ffmpeg</code>\n"
    "<b>macOS:</b> <code>brew install ffmpeg</code>\n"
    "Or set <code>FFMPEG_PATH</code> in .env to an existing binary."
)


async def _ffprobe_dims(ffmpeg: str, src: str) -> Tuple[int, int, float]:
    """Return (width, height, duration_seconds) for the first video stream."""
    ffprobe = find_ffprobe(ffmpeg)
    if ffprobe:
        args = [ffprobe, "-v", "error", "-select_streams", "v:0",
                "-show_entries", "stream=width,height:format=duration",
                "-of", "default=noprint_wrappers=1", src]
    else:  # ffmpeg -i also prints stream info on stderr
        args = [ffmpeg, "-hide_banner", "-i", src]
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, err = await asyncio.wait_for(proc.communicate(), timeout=60)
    except (OSError, asyncio.TimeoutError, subprocess.SubprocessError) as exc:
        raise WatermarkError("Could not inspect this video (FFmpeg unavailable or the "
                             "file is unreadable).") from exc

    text = (out or b"").decode("utf-8", errors="replace") + \
           (err or b"").decode("utf-8", errors="replace")
    w = h = 0
    dur = 0.0
    m = re.search(r"Stream #\d+:\d+.*?Video:.*?,\s*(\d{2,5})x(\d{2,5})", text, re.S)
    if not m:
        m = re.search(r"(\d{2,5})x(\d{2,5})", text)
    if m:
        w, h = int(m.group(1)), int(m.group(2))
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    if m:
        dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    m2 = re.search(r"duration=([\d.]+)", text)
    if m2:
        dur = max(dur, float(m2.group(1)))
    if w <= 0 or h <= 0:
        raise WatermarkError("Could not read this video (unsupported or corrupted).")
    return w, h, max(0.0, dur)


def animation_overlay_xy(name: str) -> Tuple[str, str]:
    """FFmpeg overlay x/y expressions (main_w/main_h, w/h, t available)."""
    table = {
        "none": ("(main_w-w)/2", "(main_h-h)/2"),
        "dvd_bounce": ("abs(mod(120*t,2*(main_w-w))-(main_w-w))",
                       "abs(mod(90*t,2*(main_h-h))-(main_h-h))"),
        "left_right": ("(main_w-w)*(0.5+0.5*sin(1.2*t))", "(main_h-h)/2"),
        "up_down": ("(main_w-w)/2", "(main_h-h)*(0.5+0.5*sin(1.2*t))"),
        "diagonal": ("(main_w-w)*(0.5+0.5*sin(0.8*t))",
                     "(main_h-h)*(0.5+0.5*sin(0.8*t+PI/2))"),
        "circle": ("(main_w-w)/2+(main_w-w)*0.4*cos(t)", "(main_h-h)/2+(main_h-h)*0.4*sin(t)"),
        "figure8": ("(main_w-w)/2+(main_w-w)*0.4*sin(t)",
                    "(main_h-h)/2+(main_h-h)*0.25*sin(2*t)"),
        "shake": ("(main_w-w)/2+12*sin(35*t)", "(main_h-h)/2+8*cos(41*t)"),
        "pulse": ("(main_w-w)/2", "(main_h-h)/2"),
        "zoom": ("(main_w-w)/2", "(main_h-h)/2"),
        "spin": ("(main_w-w)/2", "(main_h-h)/2"),
        "swing": ("(main_w-w)/2+80*sin(1.5*t)", "(main_h-h)/2"),
        "wave": ("(main_w-w)/2+100*sin(1.4*t)", "(main_h-h)/2+35*sin(2.8*t)"),
        "zigzag": ("(main_w-w)*(0.5+0.5*sin(2*t))", "(main_h-h)*(0.5+0.5*sin(4*t))"),
        "random": ("(main_w-w)*(0.5+0.45*sin(7.1*t))", "(main_h-h)*(0.5+0.45*sin(9.3*t))"),
        "bounce": ("(main_w-w)/2+abs(sin(1.8*t))*(main_w-w)*0.35",
                   "(main_h-h)-abs(sin(2.2*t))*(main_h-h)*0.8"),
        "corner": ("if(lt(mod(t,8),2),0,if(lt(mod(t,8),4),main_w-w,if(lt(mod(t,8),6),main_w-w,0)))",
                   "if(lt(mod(t,8),2),0,if(lt(mod(t,8),4),0,if(lt(mod(t,8),6),main_h-h,main_h-h)))"),
        "spiral": ("(main_w-w)/2+(main_w-w)*0.4*sin(t)*sin(0.25*t)",
                   "(main_h-h)/2+(main_h-h)*0.4*cos(t)*sin(0.25*t)"),
        "horizontal_scan": ("(main_w-w)*(0.5+0.5*sin(0.7*t))", "10"),
        "vertical_scan": ("10", "(main_h-h)*(0.5+0.5*sin(0.7*t))"),
        "pendulum": ("(main_w-w)/2+120*sin(0.9*t)", "(main_h-h)/2+35*abs(cos(0.9*t))"),
        "orbit": ("(main_w-w)/2+(main_w-w)*0.35*cos(0.8*t)",
                  "(main_h-h)/2+(main_h-h)*0.35*sin(0.8*t)"),
        "drift": ("(main_w-w)/2+80*sin(0.25*t)", "(main_h-h)/2+40*cos(0.35*t)"),
        "strobe": ("(main_w-w)/2", "(main_h-h)/2"),
        "elastic": ("(main_w-w)/2+100*sin(2*t)*abs(sin(t))", "(main_h-h)/2"),
        "float": ("(main_w-w)/2+40*sin(0.5*t)", "(main_h-h)/2+40*sin(0.8*t)"),
    }
    return table.get(name, table["none"])


def _ffexpr(expr: str) -> str:
    """Quote an expression for FFmpeg when it contains option-separating commas."""
    return f"'{expr}'" if "," in expr else expr


def animation_filter(name: str, speed: float = 1.0) -> str:
    """Build the FFmpeg filter chain that overlays (and animates) the layer."""
    if name not in VIDEO_ANIMATIONS:
        name = "none"
    x, y = (_ffexpr(v) for v in animation_overlay_xy(name))
    speed = max(0.1, min(8.0, float(speed or 1.0)))
    # Normalize the base video: even dimensions + square pixels (x264 needs both).
    pre = "[0:v]scale=trunc(iw/2)*2:trunc(ih/2)*2,setsar=1[base];"
    if name in ("pulse", "zoom"):
        factor = (f"(1+0.12*sin({1.6 * speed:.3f}*t))" if name == "pulse"
                  else f"(1+0.20*sin({1.1 * speed:.3f}*t))")
        return (pre + f"[1:v]scale=iw*{factor}:ih*{factor}:eval=frame[wm];"
                      f"[base][wm]overlay=x={x}:y={y}:eval=frame:format=auto[vout]")
    if name == "spin":
        # NOTE: the option separator is '=', not '(' — `rotate(a:…)` is a syntax error.
        # `c=none` keeps the padded area transparent on RGBA input.
        return (pre + f"[1:v]format=rgba,rotate=a={0.8 * speed:.3f}*t:c=none:"
                      f"ow=rotw(iw):oh=roth(ih)[wm];"
                      f"[base][wm]overlay=x={x}:y={y}:eval=frame:format=auto[vout]")
    if name == "strobe":
        # colorchannelmixer cannot evaluate `t`, so the flicker is produced by a
        # permanently dimmed copy plus a full-opacity copy gated by an enable
        # expression (comma-free, so nothing needs escaping).
        return (pre + "[1:v]format=rgba,split=2[wmDim][wmFull];"
                      "[wmDim]colorchannelmixer=aa=0.35[wmDim2];"
                      f"[base][wmDim2]overlay=x={x}:y={y}:eval=frame:format=auto[b1];"
                      f"[b1][wmFull]overlay=x={x}:y={y}:eval=frame:format=auto:"
                      f"enable='sin(2*PI*t*{speed:.3f})'[vout]")
    return pre + f"[base][1:v]overlay=x={x}:y={y}:eval=frame:format=auto[vout]"


def _ffmpeg_command(ffmpeg: str, src: str, layer_path: str, dst: str,
                    filter_chain: str, audio_mode: str) -> List[str]:
    """Build the ffmpeg argv (a list — never a shell string)."""
    args = [ffmpeg, "-nostdin", "-y", "-v", "warning", "-stats",
            "-progress", "pipe:1", "-i", src, "-i", layer_path,
            "-filter_complex", filter_chain,
            "-map", "[vout]", "-map", "0:a?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
    if audio_mode == "aac":
        args += ["-c:a", "aac", "-b:a", "160k"]
    else:
        args += ["-c:a", "copy"]
    args += [dst]
    return args


async def _run_ffmpeg(args: List[str], timeout: int, duration: float,
                      progress: Optional[Callable[[float], Awaitable[None]]]
                      ) -> Tuple[int, List[str]]:
    """Run ffmpeg, stream progress, enforce a hard timeout. Returns (rc, stderr)."""
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    stderr_lines: List[str] = []
    last_pct = -10.0

    async def read_progress() -> None:
        nonlocal last_pct
        assert proc.stdout is not None
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            text = line.decode("utf-8", errors="replace").strip()
            if not text.startswith("out_time_us="):
                continue
            value = text.split("=", 1)[1].strip()
            if not value.isdigit():
                continue
            seconds = int(value) / 1_000_000
            if duration > 0 and progress:
                pct = min(99.0, seconds / duration * 100)
                if pct - last_pct >= 10:
                    last_pct = pct
                    await progress(pct)

    async def read_stderr() -> None:
        assert proc.stderr is not None
        while True:
            line = await proc.stderr.readline()
            if not line:
                break
            stderr_lines.append(line.decode("utf-8", errors="replace").rstrip())
            if len(stderr_lines) > 40:
                del stderr_lines[0]

    try:
        await asyncio.wait_for(asyncio.gather(read_progress(), read_stderr()),
                               timeout=timeout)
        returncode = await asyncio.wait_for(proc.wait(), timeout=60)
    except asyncio.TimeoutError:
        with _suppress_os_error():
            proc.kill()
        with _suppress_os_error():
            await proc.wait()
        raise WatermarkError("⏱️ Video processing timed out. Try a shorter or "
                             "smaller video.")
    return returncode, stderr_lines


async def process_video_file(src: str, dst: str, s: Dict[str, Any], uid: int,
                             ffmpeg: str,
                             progress: Optional[Callable[[float], Awaitable[None]]] = None,
                             ) -> None:
    if not _is_executable(ffmpeg):
        raise WatermarkError("FFmpeg binary is not available on this server.")
    w, h, dur = await _ffprobe_dims(ffmpeg, src)
    if w > 7680 or h > 4320:
        raise WatermarkError("⚠️ This video resolution is too high to process.")
    px_scale = max(w, h) / 720.0
    layer_path = dst + ".wm.png"
    try:
        layer = build_watermark_layer(
            (w, h), s, logo_file_for(uid, "video") if s["mode"] != "text" else None, px_scale)
        try:
            layer.save(layer_path, format="PNG")
        finally:
            layer.close()

        chain = animation_filter(s.get("animation", "none"), s.get("animation_speed", 1.0))
        timeout = CFG.video_timeout if CFG else 900
        rc, stderr = await _run_ffmpeg(
            _ffmpeg_command(ffmpeg, src, layer_path, dst, chain, "copy"),
            timeout, dur, progress)

        if rc != 0:
            combined = " ".join(stderr).lower()
            audio_problem = any(k in combined for k in (
                "automatic encoder selection failed", "codec not currently supported",
                "could not find tag for codec", "incorrect codec parameters",
                "error while opening encoder for output stream #0:1"))
            if audio_problem:  # retry once with re-encoded audio
                LOG.info("Audio stream could not be copied; retrying with AAC.")
                rc, stderr = await _run_ffmpeg(
                    _ffmpeg_command(ffmpeg, src, layer_path, dst, chain, "aac"),
                    timeout, dur, progress)
            if rc != 0:
                LOG.error("ffmpeg failed rc=%s: %s", rc, " | ".join(stderr[-5:]))
                raise WatermarkError(
                    "FFmpeg failed to process this video. The codec may be unsupported.\n"
                    f"<blockquote expandable>{esc(' | '.join(stderr[-3:])[:400])}</blockquote>")
        if not os.path.isfile(dst) or os.path.getsize(dst) == 0:
            raise WatermarkError("FFmpeg produced an empty file. The video may be "
                                 "corrupted or use an unsupported codec.")
    finally:
        with _suppress_os_error():
            os.remove(layer_path)


# ==========================================================================
# 13. UI keyboards & screens (compact, reference-style Telegram layout)
# ==========================================================================
def kb(rows: List[List[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(rows)


def btn(text: str, cb: Optional[str] = None, url: Optional[str] = None) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=cb, url=url)


CANCEL_BTN = btn("❌ Cancel", "nav:cancel")


def menu_reply_markup() -> Optional[ReplyKeyboardMarkup]:
    """Persistent, non-destructive menu button shown below the chat input."""
    try:
        return ReplyKeyboardMarkup([[KeyboardButton("☰ Menu")]],
                                   resize_keyboard=True, is_persistent=True)
    except Exception:  # noqa: BLE001
        return None


def main_menu_kb() -> InlineKeyboardMarkup:
    rows: List[List[InlineKeyboardButton]] = [
        [btn("➕ Add Watermark", "nav:add"), btn("⚙️ Settings", "nav:hub")],
        [btn("🖼️ Process Image", "proc:image"), btn("📄 Process PDF", "proc:pdf")],
        [btn("🎥 Process Video", "proc:video"), btn("⚡ Batch", "nav:batch")],
        [btn("📊 My Settings", "nav:myset"), btn("📡 Status", "nav:status")],
        [btn("❓ Help", "nav:help"), btn("ℹ️ About", "nav:about")],
        [btn("🏠 Back to Start", "nav:main")],
    ]
    if CFG and CFG.admin_contact_url:
        rows.insert(5, [btn("👨‍💻 Contact Admin for VIP Plan",
                            url=CFG.admin_contact_url)])
    return kb(rows)


def back_kb(back_to: str = "nav:main") -> InlineKeyboardMarkup:
    return kb([[btn("🏠 Back to Start", back_to)]])


def settings_hub_kb() -> InlineKeyboardMarkup:
    return kb([
        [btn("🎥 Video", "cat:video"), btn("🖼️ Image", "cat:image"),
         btn("📄 PDF", "cat:pdf")],
        [btn("🌐 Global Defaults", "cat:global")],
        [btn("🏠 Back to Start", "nav:main")],
    ])


def my_settings_kb() -> InlineKeyboardMarkup:
    return kb([
        [btn("🎥 Video", "cat:video"), btn("🖼️ Image", "cat:image"),
         btn("📄 PDF", "cat:pdf")],
        [btn("🏠 Back to Start", "nav:main")],
    ])


def animation_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    current = s.get("animation", "none")
    rows = []
    items = list(VIDEO_ANIMATIONS.items())
    for i in range(0, len(items), 2):
        rows.append([btn(("✅ " if k == current else "") + v, f"an:{media}:{k}")
                     for k, v in items[i:i + 2]])
    rows.append([btn("🐢 Slower", f"as:{media}:-"),
                 btn(f"⚡ Speed {s.get('animation_speed', 1.0):.1f}x", f"act:{media}:animation"),
                 btn("🐇 Faster", f"as:{media}:+")])
    rows.append([btn("⬅️ Back", f"cat:{media}")])
    return kb(rows)


def category_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    toggle = "🔴 Turn OFF" if s["enabled"] else "🟢 Turn ON"
    mode_label = {"text": "✍️ Mode: Text", "logo": "🖼️ Mode: Logo",
                  "both": "🎨 Mode: Both"}[s["mode"]]
    rows: List[List[InlineKeyboardButton]] = [
        [btn(toggle, f"act:{media}:toggle"), btn("✏️ Text", f"act:{media}:text")],
        [btn("🔤 Font", f"act:{media}:font"), btn("✨ Style", f"act:{media}:style")],
        [btn("📏 Size", f"act:{media}:size"), btn("🎨 Color", f"act:{media}:color")],
        [btn("💧 Opacity", f"act:{media}:opacity"),
         btn("📍 Position", f"act:{media}:position")],
        [btn("🧊 Badge & Effects", f"act:{media}:badge"),
         btn("⚙️ Stroke & Shadow", f"act:{media}:stroke")],
    ]
    if media == "video":
        rows.append([btn(f"🎬 Animation: {VIDEO_ANIMATIONS.get(s.get('animation', 'none'), 'None')}",
                         f"act:{media}:animation")])
    rows.append([btn(mode_label, f"act:{media}:mode"), btn("🖼️ Logo", f"act:{media}:logo")])
    if media == "pdf":
        rows.append([btn(f"📄 Pages: {s['pdf_pages']}", f"act:{media}:pdfpages")])
    rows.append([btn("🔄 Reset to Default", f"act:{media}:reset"),
                 btn("⬅️ Back", f"nav:catback:{media}")])
    rows.append([btn("🏠 Back to Start", "nav:main")])
    return kb(rows)


def font_kb(media: str, current: str) -> InlineKeyboardMarkup:
    rows = [[btn(("✅ " if f == current else "") + f, f"f:{media}:{f}")] for f in FONT_FAMILIES]
    rows.append([btn("⬅️ Back", f"cat:{media}")])
    return kb(rows)


def style_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    return kb([
        [btn("✅ Bold" if s["bold"] else "Bold", f"st:{media}:bold"),
         btn("✅ Italic" if s["italic"] else "Italic", f"st:{media}:italic")],
        [btn("🔄 0°", f"st:{media}:rot0"), btn("🔄 45°", f"st:{media}:rot45"),
         btn("🔄 90°", f"st:{media}:rot90"), btn("🔄 -45°", f"st:{media}:rotm45")],
        [btn("🎯 Custom Rotation", f"act:{media}:rotc")],
        [btn("⬅️ Back", f"cat:{media}")],
    ])


def size_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    return kb([
        [btn("➖ Decrease", f"sz:{media}:-"), btn(f"📏 {s['font_size']} px", f"cat:{media}"),
         btn("➕ Increase", f"sz:{media}:+")],
        [btn("24", f"sz:{media}:24"), btn("36", f"sz:{media}:36"), btn("48", f"sz:{media}:48"),
         btn("64", f"sz:{media}:64"), btn("96", f"sz:{media}:96")],
        [btn("⬅️ Back", f"cat:{media}")],
    ])


COLOR_PRESETS = ["#FFFFFF", "#000000", "#FF0000", "#00FF00", "#0000FF", "#FFFF00",
                 "#FF00FF", "#00FFFF"]


def color_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    return kb([
        [btn(c, f"c:{media}:{c[1:]}") for c in COLOR_PRESETS[:4]],
        [btn(c, f"c:{media}:{c[1:]}") for c in COLOR_PRESETS[4:]],
        [btn("✏️ Custom Hex", f"act:{media}:colorc")],
        [btn("⬅️ Back", f"cat:{media}")],
    ])


def opacity_kb(media: str, s: Dict[str, Any], key: str = "opacity") -> InlineKeyboardMarkup:
    val = s.get(key, 75)
    return kb([
        [btn("➖ -5%", f"o:{media}:{key}:-"), btn(f"💧 {val}%", f"cat:{media}"),
         btn("➕ +5%", f"o:{media}:{key}:+")],
        [btn("25%", f"o:{media}:{key}:25"), btn("50%", f"o:{media}:{key}:50"),
         btn("75%", f"o:{media}:{key}:75"), btn("100%", f"o:{media}:{key}:100")],
        [btn("⬅️ Back", f"cat:{media}")],
    ])


def position_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    keys = list(POSITIONS)[:9]
    rows = []
    for i in range(0, 9, 3):
        rows.append([btn(POSITIONS[k][1] + (" ✅" if s["position"] == k else ""),
                         f"p:{media}:{k}") for k in keys[i:i + 3]])
    rows.append([btn("🎯 Custom Coordinates", f"act:{media}:posc"),
                 btn(f"📐 Margin {s['margin']}", f"cat:{media}")])
    rows.append([btn("➖ Margin", f"p:{media}:m-"), btn("➕ Margin", f"p:{media}:m+")])
    rows.append([btn("⬅️ Back", f"cat:{media}")])
    return kb(rows)


def badge_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    return kb([
        [btn(("✅ " if s["badge"] == "plain" else "") + "✨ Plain Text", f"b:{media}:plain"),
         btn(("✅ " if s["badge"] == "box" else "") + "🧊 Badge Box", f"b:{media}:box")],
        [btn(("✅ " if s["tiled"] else "") + "🔁 Tiled Watermark", f"b:{media}:tile"),
         btn(f"📐 Spacing {s['tile_spacing']}", f"cat:{media}")],
        [btn("➖ Spacing", f"b:{media}:sp-"), btn("➕ Spacing", f"b:{media}:sp+")],
        [btn("⬅️ Back", f"cat:{media}")],
    ])


def stroke_kb(media: str, s: Dict[str, Any]) -> InlineKeyboardMarkup:
    return kb([
        [btn(("🟢" if s["stroke"] else "⚪") + " Outline Stroke", f"k:{media}:stroke"),
         btn(("🟢" if s["shadow"] else "⚪") + " Drop Shadow", f"k:{media}:shadow")],
        [btn("➖ Width", f"k:{media}:w-"), btn(f"✏️ Width {s['stroke_width']}", f"cat:{media}"),
         btn("➕ Width", f"k:{media}:w+")],
        [btn("⬅️ Back", f"cat:{media}")],
    ])


def logo_kb(media: str, s: Dict[str, Any], uid: int) -> InlineKeyboardMarkup:
    has = os.path.isfile(logo_file_for(uid, media))
    return kb([
        [btn("✅ Logo set" if has else "⬆️ Upload Logo", f"act:{media}:logoup")],
        [btn("➖ Scale", f"lg:{media}:s-"), btn(f"📏 Scale {s['logo_scale']}%", f"cat:{media}"),
         btn("➕ Scale", f"lg:{media}:s+")],
        [btn("➖ Opacity", f"lg:{media}:o-"),
         btn(f"💧 {s['logo_opacity']}%", f"cat:{media}"), btn("➕ Opacity", f"lg:{media}:o+")],
        [btn("🔄 0°", f"lg:{media}:r0"), btn("🔄 90°", f"lg:{media}:r90"),
         btn(("✅ " if s["logo_tiled"] else "") + "🔁 Tile", f"lg:{media}:tile")],
        [btn("🗑️ Remove Logo", f"lg:{media}:clear")],
        [btn("⬅️ Back", f"cat:{media}")],
    ])


def batch_kb() -> InlineKeyboardMarkup:
    return kb([[btn("✅ Done — Process Batch", "batch:done"),
                btn("❌ Cancel", "batch:cancel")]])


# ---------------------------------------------------------------- texts ----
# Decorative compass rule for the /start card only (other screens keep the plain
# rule). Deliberately narrower than the 20-bar plain rule — an emoji is ~1.2
# character widths, so 14 bars + 2 compasses ≈ the same on-screen width and
# still fits a 360 dp phone without wrapping.
COMPASS_RULE: str = "🧭<i> ━━━━━━━━━━━━━━ </i>🧭"


def main_menu_text() -> str:
    return (
        "<blockquote>"
        f"🎨 <b>{serif_bold('Viraj Watermark')}</b>\n"
        f"{COMPASS_RULE}\n\n"
        "Welcome! Add professional watermarks to your Images, PDFs and Videos.\n"
        "Choose an option below to get started.\n\n"
        f"{COMPASS_RULE}\n"
        "⚡ <b>Channel Batch Watermarking</b>\n"
        "<blockquote expandable>Channel Batch Watermarking is an automated tool "
        "reserved exclusively for VIP &amp; ranked channels. Contact the admin to upgrade."
        "</blockquote>"
        "</blockquote>"
    )


def settings_hub_text() -> str:
    return (
        "<blockquote>"
        f"🎨 <b>{serif_bold('Watermark Settings Hub')}</b>\n"
        "<i>━━━━━━━━━━━━━━━━━━━━</i>\n\n"
        "Select a media category below to configure watermarks for your files.\n"
        "Each media category maintains independent persistent settings.\n\n"
        "<i>━━━━━━━━━━━━━━━━━━━━</i>"
        "</blockquote>"
    )


MY_SETTINGS_NOTE: str = (
    "Video, Image, and PDF maintain isolated settings. "
    "To modify any setting, tap the buttons below."
)


def my_settings_text(uid: int) -> str:
    """Configuration dashboard: header, per-media table, info panel.

    Telegram renders <pre> as a monospace block and <blockquote> with a
    coloured bar down the left edge — that bar is the closest native
    equivalent of the reference panel's blue accent. Column widths are
    capped (text 14, font 8) so the widest realistic row still fits a
    360 dp phone without horizontal scrolling.
    """
    rows = []
    for media in ("video", "image", "pdf"):
        s = DB.get_settings(uid, media)
        emoji, _, label = MEDIA_LABELS[media]
        rows.append([
            f"{emoji} {label}",
            "🟢 ON" if s["enabled"] else "🔴 OFF",
            _trunc(s["text"], 14),
            _trunc(s["font"], 8),
        ])
    table = box_table(["Media", "Status", "Text", "Font"], rows)
    return (
        "<blockquote>"
        f"📊 <b>{serif_bold('My Watermark Configuration')}</b>\n"
        "<i>━━━━━━━━━━━━━━━━━━━━</i>\n"
        f"<pre>{esc(table)}</pre>\n\n"
        f"<blockquote>{esc(MY_SETTINGS_NOTE)} 🔽</blockquote>"
        "</blockquote>"
    )


def category_text(media: str, s: Dict[str, Any]) -> str:
    emoji, title, _ = MEDIA_LABELS[media]
    pos_label, pos_emoji = POSITIONS[s["position"]]
    rows = [
        ["Status", "🟢 ENABLED" if s["enabled"] else "🔴 DISABLED"],
        ["Watermark Text", _trunc(s["text"], 24)],
        ["Font Family", f"{s['font']} ({'Bold' if s['bold'] else 'Regular'}"
                        f"{', Italic' if s['italic'] else ''})"],
        ["Font Size", f"{s['font_size']} px"],
        ["Text Color", s["color"].upper()],
        ["Opacity", f"{s['opacity']}%"],
        ["Anchor Position", f"{pos_emoji} {pos_label}"],
        ["Outline Stroke", "ON" if s["stroke"] else "OFF"],
        ["Drop Shadow", "ON" if s["shadow"] else "OFF"],
        ["Badge & Effect", BADGES[s["badge"]]],
        ["Mode", s["mode"].capitalize()],
    ]
    if media == "video":
        rows.append(["Animation", f"{VIDEO_ANIMATIONS.get(s['animation'], 'None')} "
                                  f"({s['animation_speed']:.1f}x)"])
    if media == "pdf":
        rows.append(["Pages", _trunc(s["pdf_pages"], 24)])
    table = box_table(["Setting", "Value"], rows)
    return (
        "<blockquote>"
        f"{emoji} <b>{serif_bold(title)}</b>\n"
        "<i>━━━━━━━━━━━━━━━━━━━━</i>\n"
        f"<pre>{esc(table)}</pre>\n"
        "<i>━━━━━━━━━━━━━━━━━━━━</i>\n"
        "<blockquote expandable>Click any button below to customize specific "
        "attributes in real-time.</blockquote>"
        "</blockquote>"
    )


def help_text() -> str:
    local = bool(CFG and CFG.local_api_base_url)
    limit = human_size(CFG.max_file_size if local else min(
        CFG.max_file_size, STANDARD_API_DOWNLOAD_LIMIT))
    return (
        f"❓ <b>{serif_bold('Help & Guide')}</b>\n\n"
        "1️⃣ <b>Add Watermark</b> — send any image, PDF or video and it is returned "
        "with your watermark applied.\n"
        "2️⃣ <b>Watermark Settings</b> — configure text/logo, size, color, opacity, "
        "position, rotation, stroke, shadow, badge and tiling per media type.\n"
        "3️⃣ <b>Batch Processing</b> — send multiple files, tap ✅ Done, receive a ZIP.\n"
        "4️⃣ <b>My Settings</b> — view your saved configuration at any time.\n\n"
        "<blockquote expandable>Supported: JPG, JPEG, PNG, WEBP images • PDF "
        "(multi-page, page ranges) • MP4/MKV/MOV/AVI/WEBM videos.\n"
        f"Max incoming file size: {limit}."
        + ("" if local else "\nStandard Bot API mode: a self-hosted Bot API server "
                            "raises the 20 MB download / 50 MB upload caps.")
        + "</blockquote>"
    )


def about_text() -> str:
    return (
        f"ℹ️ <b>{serif_bold('About Viraj Watermark')}</b>\n\n"
        "Viraj Watermark adds customizable, permanent watermarks to images, PDFs "
        "and videos — perfect for channels, creators and brands.\n\n"
        "• Independent settings per media type\n"
        "• Text & logo watermarks, tiling, stroke, shadow, badges\n"
        "• Batch processing with ZIP delivery\n"
        "• Privacy-friendly: only your settings & usage stats are stored\n\n"
        f"<blockquote expandable>Version {APP_VERSION} • "
        "⚡ Channel Batch Watermarking is an automated tool reserved exclusively "
        "for VIP &amp; ranked channels.</blockquote>"
    )


def status_text(uid: int) -> str:
    """Watch/Status screen: bot health + the caller's own usage."""
    ffmpeg = find_ffmpeg()
    stats = DB.user_stats(uid) or {"images": 0, "pdfs": 0, "videos": 0, "batches": 0}
    mem = psutil.virtual_memory()
    total_users, active = DB.user_counts()
    rows = [
        ["Bot", "🟢 Online"],
        ["Version", APP_VERSION],
        ["Uptime", human_duration(time.time() - START_TIME)],
        ["Bot API", "Self-hosted (local)" if CFG.local_api_base_url else "Standard"],
        ["FFmpeg", "✅ available" if ffmpeg else "❌ not installed"],
        ["RAM", f"{mem.percent:.0f}% used"],
        ["Users (total / 7d)", f"{total_users} / {active}"],
        ["Your images", str(stats["images"])],
        ["Your PDFs", str(stats["pdfs"])],
        ["Your videos", str(stats["videos"])],
        ["Your batches", str(stats["batches"])],
        ["Rate limit", f"{limit_rate_per_min()}/min"],
        ["Batch limit", str(limit_max_batch())],
    ]
    return (
        f"📡 <b>{serif_bold('Bot Status')}</b>\n"
        f"<pre>{esc(box_table(['Metric', 'Value'], rows))}</pre>"
    )


# ==========================================================================
# 14. Session state, rate limiting, concurrency
# ==========================================================================
USER_STATE: Dict[int, Dict[str, Any]] = {}
USER_LOCK: Dict[int, asyncio.Lock] = {}
RATE: Dict[int, deque] = {}
JOB_SEMAPHORE: Optional[asyncio.Semaphore] = None
ACTIVE_JOBS: List[int] = [0]  # mutable counter, incremented around heavy jobs


def set_state(uid: int, kind: str, **kw: Any) -> None:
    USER_STATE[uid] = {"kind": kind, "ts": time.time(), **kw}


def get_state(uid: int) -> Optional[Dict[str, Any]]:
    st = USER_STATE.get(uid)
    if st and time.time() - st.get("ts", 0) > CFG.state_ttl:
        USER_STATE.pop(uid, None)
        return None
    return st


def clear_state(uid: int) -> None:
    USER_STATE.pop(uid, None)


def sweep_states() -> int:
    now = time.time()
    ttl = CFG.state_ttl
    expired = [uid for uid, st in USER_STATE.items() if now - st.get("ts", 0) > ttl]
    for uid in expired:
        USER_STATE.pop(uid, None)
    return len(expired)


def user_lock(uid: int) -> asyncio.Lock:
    lock = USER_LOCK.get(uid)
    if lock is None:
        lock = asyncio.Lock()
        USER_LOCK[uid] = lock
    return lock


def job_semaphore() -> asyncio.Semaphore:
    global JOB_SEMAPHORE
    if JOB_SEMAPHORE is None:
        JOB_SEMAPHORE = asyncio.Semaphore(max(1, CFG.max_concurrent_jobs))
    return JOB_SEMAPHORE


def rate_limited(uid: int) -> bool:
    """Sliding-window per-user rate limiter (admins get a 3x allowance)."""
    limit = limit_rate_per_min()
    if is_admin(uid):
        limit *= 3
    now = time.time()
    window = RATE.setdefault(uid, deque())
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= limit:
        return True
    window.append(now)
    if len(RATE) > 10000:  # bound memory
        for stale in [k for k, v in RATE.items() if not v or now - v[-1] > 300]:
            RATE.pop(stale, None)
    return False


# ==========================================================================
# 15. Temp directory helpers
# ==========================================================================
class _SuppressOSError:
    def __enter__(self) -> None:
        return None

    def __exit__(self, exc_type, exc, tb) -> bool:
        return exc_type is not None and issubclass(exc_type, OSError)


def _suppress_os_error() -> _SuppressOSError:
    return _SuppressOSError()


def user_temp(uid: int) -> str:
    d = os.path.join(CFG.temp_directory, str(int(uid)))
    os.makedirs(d, exist_ok=True)
    return d


def safe_join(base: str, name: str) -> str:
    """Join `name` under `base`, refusing anything that escapes the directory."""
    base = os.path.realpath(base)
    path = os.path.realpath(os.path.join(base, name))
    if path != base and not path.startswith(base + os.sep):
        raise WatermarkError("Invalid file name.")
    return path


def clean_temp_dir(max_age: float = 3600) -> int:
    removed = 0
    now = time.time()
    root = Path(CFG.temp_directory)
    if not root.exists():
        return 0
    for p in root.rglob("*"):
        try:
            if p.is_file() and now - p.stat().st_mtime > max_age:
                p.unlink()
                removed += 1
        except OSError:
            pass
    return removed


def effective_download_limit() -> int:
    if CFG.local_api_base_url:
        return CFG.max_file_size
    return min(CFG.max_file_size, STANDARD_API_DOWNLOAD_LIMIT)


def effective_upload_limit() -> int:
    if CFG.local_api_base_url:
        return CFG.upload_limit
    return min(CFG.upload_limit, STANDARD_API_UPLOAD_LIMIT)


# ==========================================================================
# 16. Core processing flow
# ==========================================================================
def media_kind_of(ext: str) -> Optional[str]:
    ext = (ext or "").lower()
    if ext in IMAGE_EXTS:
        return "image"
    if ext in PDF_EXTS:
        return "pdf"
    if ext in VIDEO_EXTS:
        return "video"
    return None


async def _tg_retry(fn: Callable[[], Awaitable[Any]], tries: int = 3) -> Any:
    """Retry transient Telegram network failures."""
    last: Optional[Exception] = None
    for attempt in range(tries):
        try:
            return await fn()
        except RetryAfter as exc:
            last = exc
            wait = float(getattr(exc, "retry_after", 1) or 1)
            if attempt + 1 >= tries:
                break
            await asyncio.sleep(min(wait + 0.5, 30))
        except (TimedOut, NetworkError) as exc:
            last = exc
            if attempt + 1 >= tries:
                break
            await asyncio.sleep(1.0 * (attempt + 1))
    raise WatermarkError("Telegram network problem while transferring the file. "
                         "Please try again.") from last


async def download_update_file(update: Update) -> Tuple[str, str, int, str]:
    """Return (path, extension, size, original_name). Raises WatermarkError."""
    msg = update.message
    assert msg is not None
    if msg.photo:
        file = await _tg_retry(msg.photo[-1].get_file)
        ext, original = ".jpg", "photo.jpg"
    elif msg.video:
        file = await _tg_retry(msg.video.get_file)
        name = msg.video.file_name or "video.mp4"
        ext = os.path.splitext(name)[1].lower() or ".mp4"
        original = name
    elif msg.document:
        file = await _tg_retry(msg.document.get_file)
        name = msg.document.file_name or ""
        ext = os.path.splitext(name)[1].lower()
        mime = (msg.document.mime_type or "").lower()
        if not ext:
            ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
                   "application/pdf": ".pdf", "video/mp4": ".mp4",
                   "video/x-matroska": ".mkv", "video/quicktime": ".mov",
                   "video/webm": ".webm"}.get(mime, "")
        original = name or f"file{ext or '.bin'}"
    else:
        raise WatermarkError("Please send a supported file (image, PDF or video).")

    size = int(file.file_size or 0)
    limit = effective_download_limit()
    if size > limit:
        raise WatermarkError(
            f"⚠️ File too large ({human_size(size)}).\n"
            f"Limit right now: {human_size(limit)}"
            + ("" if CFG.local_api_base_url else
               " — the standard Bot API caps downloads at 20 MB. A self-hosted "
               "Bot API server removes that limit."))
    if not ext or media_kind_of(ext) is None:
        raise WatermarkError("⚠️ Unsupported file type. Supported: JPG, JPEG, PNG, WEBP, "
                             "PDF, MP4, MKV, MOV, AVI, WEBM.")

    path = safe_join(user_temp(update.effective_user.id), sanitize_filename(original))
    try:
        await _tg_retry(lambda: file.download_to_drive(path))
    except TelegramError as exc:
        message = str(exc).lower()
        if "file is too big" in message or "too big" in message:
            raise WatermarkError(
                f"⚠️ Telegram rejected this {human_size(size)} file because the standard "
                "Bot API download limit is about 20 MB. To process larger files, "
                "configure a self-hosted Telegram Bot API server with "
                "TELEGRAM_API_BASE_URL and TELEGRAM_API_FILE_URL.") from exc
        raise WatermarkError("⚠️ Telegram could not download this file. Check the Bot API "
                             "connection or try sending the file as a document.") from exc
    if not os.path.isfile(path):
        raise WatermarkError("⚠️ The download did not complete. Please try again.")
    return path, ext, size, original


async def _send_result(bot, chat_id: int, out_path: str, kind: str,
                       caption: str) -> None:
    """Stream the result back without loading it fully into memory."""
    filename = "watermarked" + (os.path.splitext(out_path)[1] or ".bin")
    with open(out_path, "rb") as fh:
        if kind == "image":
            await bot.send_photo(chat_id=chat_id, photo=fh, caption=caption,
                                 read_timeout=300, write_timeout=600)
        elif kind == "pdf":
            await bot.send_document(chat_id=chat_id, document=fh, filename=filename,
                                    caption=caption, read_timeout=300, write_timeout=600)
        else:
            await bot.send_video(chat_id=chat_id, video=fh, caption=caption,
                                 supports_streaming=True, read_timeout=300,
                                 write_timeout=600)


async def process_and_send(update: Update, context: ContextTypes.DEFAULT_TYPE,
                           path: str, kind: str, status=None) -> None:
    uid = update.effective_user.id
    chat = update.effective_chat
    assert chat is not None
    msg = update.message
    s = DB.get_settings(uid, kind)
    if not s["enabled"]:
        await msg.reply_text(
            f"⚠️ Watermarking is <b>turned OFF</b> for {esc(MEDIA_LABELS[kind][2])}.\n"
            "Enable it in ⚙️ Settings.", parse_mode=ParseMode.HTML)
        return

    if status is None:
        status = await msg.reply_text(f"⏳ Processing your {kind}…")
    else:
        with _suppress_os_error():
            await status.edit_text(f"⏳ Processing your {kind}…")

    loop = asyncio.get_running_loop()
    out_path = safe_join(user_temp(uid), "out_" + os.path.basename(path))
    if kind == "video":
        out_path = os.path.splitext(out_path)[0] + ".mp4"
    try:
        async with job_semaphore():
            ACTIVE_JOBS[0] += 1
            try:
                if kind == "image":
                    await asyncio.wait_for(
                        loop.run_in_executor(None, process_image_file, path, out_path, s, uid),
                        timeout=CFG.process_timeout)
                elif kind == "pdf":
                    async def _edit_pdf(text: str) -> None:
                        try:
                            await status.edit_text(text)
                        except (BadRequest, TelegramError):
                            pass

                    def _pdf_progress(done: int, total: int) -> None:
                        asyncio.run_coroutine_threadsafe(
                            _edit_pdf(f"📄 PDF page {done}/{total}…"), loop)

                    await asyncio.wait_for(
                        loop.run_in_executor(None, process_pdf_file, path, out_path, s, uid,
                                             _pdf_progress),
                        timeout=CFG.process_timeout)
                elif kind == "video":
                    ffmpeg = find_ffmpeg()
                    if not ffmpeg:
                        await status.edit_text(FFMPEG_SETUP_MSG, parse_mode=ParseMode.HTML)
                        return

                    async def _vprog(pct: float) -> None:
                        try:
                            await status.edit_text(f"🎬 Watermarking video… {pct:.0f}%")
                        except (BadRequest, TelegramError):
                            pass

                    await process_video_file(path, out_path, s, uid, ffmpeg, _vprog)
                else:
                    raise WatermarkError("Unsupported media kind.")
            finally:
                ACTIVE_JOBS[0] -= 1

        DB.bump_stat(uid, kind)
        size = os.path.getsize(out_path)
        upload_limit = effective_upload_limit()
        if size > upload_limit:
            await status.edit_text(
                f"✅ Processed, but the result ({human_size(size)}) exceeds the current "
                f"upload limit ({human_size(upload_limit)}).\n"
                + ("" if CFG.local_api_base_url else
                   "Configure a self-hosted Bot API server for larger results."),
                parse_mode=ParseMode.HTML)
            return
        with _suppress_os_error():
            await context.bot.send_chat_action(chat.id, "upload_document")
        await _send_result(context.bot, chat.id, out_path, kind,
                           f"✅ Your watermarked {kind} is ready!")
        with _suppress_os_error():
            await status.delete()
    except WatermarkError as exc:
        DB.bump_stat(uid, "error")
        DB.log_error(uid, kind, str(exc))
        with _suppress_os_error():
            await status.edit_text(f"⚠️ {esc(str(exc))}", parse_mode=ParseMode.HTML)
    except asyncio.TimeoutError:
        DB.bump_stat(uid, "error")
        DB.log_error(uid, kind, f"timeout after {CFG.process_timeout}s")
        with _suppress_os_error():
            await status.edit_text("⚠️ Processing timed out. Please try a smaller file.")
    except (RetryAfter, TimedOut) as exc:
        LOG.warning("Telegram transient error: %s", exc)
        with _suppress_os_error():
            await status.edit_text("⚠️ Telegram is busy right now. Please try again "
                                   "in a moment.")
    except TelegramError as exc:
        DB.bump_stat(uid, "error")
        DB.log_error(uid, kind, f"{type(exc).__name__}: {exc}")
        detail = str(exc).lower()
        with _suppress_os_error():
            if "file is too big" in detail or "too big" in detail:
                await status.edit_text(
                    "⚠️ Telegram rejected the file because the current Bot API transport "
                    "limit was exceeded. Use a self-hosted Bot API server for large files.")
            else:
                await status.edit_text("⚠️ Telegram could not transfer the processed file. "
                                       "Check the Bot API configuration and try again.")
        LOG.exception("Telegram processing error")
    except Exception as exc:  # unexpected — log details, show a safe message
        DB.bump_stat(uid, "error")
        DB.log_error(uid, kind, f"{type(exc).__name__}: {exc}")
        LOG.exception("Processing failed")
        with _suppress_os_error():
            await status.edit_text("⚠️ Something went wrong while processing this file. "
                                   "The admins have been notified.")
    finally:
        for p in (path, out_path):
            with _suppress_os_error():
                os.remove(p)


# ==========================================================================
# 17. Guards & command handlers
# ==========================================================================
async def deny(update: Update, reason: str = "⛔ Access Denied: Admin only command.") -> None:
    if update.callback_query:
        try:
            await update.callback_query.answer(reason, show_alert=True)
        except (BadRequest, TelegramError):
            pass
    elif update.message:
        await update.message.reply_text(reason)


async def gate(update: Update) -> bool:
    """True when the update may proceed (not blocked, not rate-limited)."""
    user = update.effective_user
    if not user:
        return False
    if DB.is_blocked(user.id):
        if update.callback_query:
            try:
                await update.callback_query.answer("You are blocked.", show_alert=True)
            except (BadRequest, TelegramError):
                pass
        elif update.message:
            await update.message.reply_text("⛔ You are blocked from using this bot.")
        return False
    if rate_limited(user.id):
        if update.callback_query:
            try:
                await update.callback_query.answer("Slow down! Too many requests.",
                                                   show_alert=True)
            except (BadRequest, TelegramError):
                pass
        elif update.message:
            await update.message.reply_text("⏳ Slow down! Try again in a minute.")
        return False
    DB.touch_user(user.id, user.username or "", user.first_name or "")
    return True


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update):
        return
    await update.message.reply_text(main_menu_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=main_menu_kb())
    await update.message.reply_text("Use the inline buttons above, or tap ☰ Menu.",
                                    reply_markup=menu_reply_markup())


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update):
        return
    await update.message.reply_text(help_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=back_kb())


async def cmd_about(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update):
        return
    await update.message.reply_text(about_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=back_kb())


async def cmd_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update):
        return
    await update.message.reply_text(settings_hub_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=settings_hub_kb())


async def cmd_mysettings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update):
        return
    await update.message.reply_text(my_settings_text(update.effective_user.id),
                                    parse_mode=ParseMode.HTML, reply_markup=my_settings_kb())


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update):
        return
    await update.message.reply_text(status_text(update.effective_user.id),
                                    parse_mode=ParseMode.HTML, reply_markup=back_kb())


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    clear_state(update.effective_user.id)
    await update.message.reply_text("❌ Cancelled. Nothing is waiting for input.",
                                    reply_markup=back_kb())


async def cmd_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_text(
        f"🆔 Your Telegram user ID: <code>{user.id}</code>\n"
        f"Admin: {'yes' if is_admin(user.id) else 'no'}\n\n"
        "<blockquote expandable>Put this number in ADMIN_IDS in .env to unlock the "
        "admin panel.</blockquote>", parse_mode=ParseMode.HTML)


# ---- admin commands ------------------------------------------------------
async def admin_guard(update: Update) -> bool:
    user = update.effective_user
    if not user or not is_admin(user.id):
        await deny(update)
        return False
    return True


def _parse_user_id(args: Sequence[str]) -> Optional[int]:
    """Accept only positive numeric Telegram user IDs."""
    if not args:
        return None
    raw = str(args[0]).strip()
    if not re.fullmatch(r"\d{3,15}", raw):
        return None
    return int(raw)


async def cmd_allow(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_guard(update):
        return
    uid = _parse_user_id(context.args or [])
    if uid is None:
        await update.message.reply_text("Usage: /allow &lt;user_id&gt;",
                                        parse_mode=ParseMode.HTML)
        return
    extras = set(extra_admin_ids())
    extras.add(uid)
    DB.kv_set("extra_admins", ",".join(str(x) for x in sorted(extras)))
    await update.message.reply_text(f"✅ User {uid} granted admin rights.")
    LOG.info("Admin %s granted admin rights to %s", update.effective_user.id, uid)


async def cmd_block(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_guard(update):
        return
    uid = _parse_user_id(context.args or [])
    if uid is None:
        await update.message.reply_text("Usage: /block &lt;user_id&gt;",
                                        parse_mode=ParseMode.HTML)
        return
    DB.set_blocked(uid, True)
    await update.message.reply_text(f"🚫 User {uid} blocked.")


async def cmd_unblock(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_guard(update):
        return
    uid = _parse_user_id(context.args or [])
    if uid is None:
        await update.message.reply_text("Usage: /unblock &lt;user_id&gt;",
                                        parse_mode=ParseMode.HTML)
        return
    DB.set_blocked(uid, False)
    await update.message.reply_text(f"✅ User {uid} unblocked.")


def _admin_stats_text() -> str:
    total_users, active = DB.user_counts()
    tot = DB.totals()
    cpu = psutil.cpu_percent(interval=0.2)
    mem = psutil.virtual_memory()
    disk_dir = CFG.temp_directory if os.path.isdir(CFG.temp_directory) else "."
    disk = psutil.disk_usage(disk_dir)
    rows = [
        ["Total Users", str(total_users)],
        ["Active (7d)", str(active)],
        ["Images Processed", str(tot["images"])],
        ["PDFs Processed", str(tot["pdfs"])],
        ["Videos Processed", str(tot["videos"])],
        ["Batches", str(tot["batches"])],
        ["Errors", str(tot["errors"])],
        ["CPU Usage", f"{cpu:.1f}%"],
        ["RAM Usage", f"{mem.percent:.1f}% ({human_size(mem.used)})"],
        ["Disk Usage", f"{disk.percent:.1f}% ({human_size(disk.used)})"],
        ["Bot Uptime", human_duration(time.time() - START_TIME)],
        ["Active Jobs", f"{ACTIVE_JOBS[0]} / {CFG.max_concurrent_jobs}"],
        ["Sessions", f"{len(USER_STATE)} pending"],
        ["Max Batch", str(limit_max_batch())],
        ["Rate Limit", f"{limit_rate_per_min()}/min"],
        ["Bot API", "Local" if CFG.local_api_base_url else "Standard"],
    ]
    return ("🛡️ <b>" + serif_bold("Admin Panel") + "</b>\n"
            f"<pre>{esc(box_table(['Metric', 'Value'], rows))}</pre>")


def admin_kb() -> InlineKeyboardMarkup:
    return kb([
        [btn("📢 Broadcast", "adm:broadcast"), btn("🧹 Clean Temp", "adm:clean")],
        [btn("➖ Batch Limit", "lim:batch:-"), btn("➕ Batch Limit", "lim:batch:+")],
        [btn("➖ Rate Limit", "lim:rate:-"), btn("➕ Rate Limit", "lim:rate:+")],
        [btn("📜 Recent Errors", "adm:errors")],
        [btn("🔄 Refresh", "adm:stats"), btn("🏠 Back to Start", "nav:main")],
    ])


async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_guard(update):
        return
    await update.message.reply_text(_admin_stats_text(), parse_mode=ParseMode.HTML,
                                    reply_markup=admin_kb())


cmd_stats = cmd_admin


async def cmd_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_guard(update):
        return
    set_state(update.effective_user.id, "broadcast")
    await update.message.reply_text("📢 Send the message to broadcast to all users "
                                    "(text or media). /cancel to abort.",
                                    reply_markup=kb([[CANCEL_BTN]]))


async def cmd_cleanup(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await admin_guard(update):
        return
    removed = await asyncio.get_running_loop().run_in_executor(None, clean_temp_dir, 0)
    await update.message.reply_text(f"🧹 Removed {removed} temp file(s).")


# ==========================================================================
# 18. Callback query router
# ==========================================================================
class QueryCtx:
    """Guarantees the callback query is answered exactly once."""

    def __init__(self, query) -> None:
        self.q = query
        self.answered = False

    async def answer(self, text: Optional[str] = None, alert: bool = False) -> None:
        if self.answered:
            return
        self.answered = True
        try:
            await self.q.answer(text, show_alert=alert)
        except (BadRequest, TelegramError):
            pass

    async def screen(self, text: str, markup: InlineKeyboardMarkup) -> None:
        """Edit the current message (caption for photo messages)."""
        try:
            if self.q.message is not None and self.q.message.photo:
                await self.q.edit_message_caption(text, parse_mode=ParseMode.HTML,
                                                  reply_markup=markup)
            else:
                await self.q.edit_message_text(text, parse_mode=ParseMode.HTML,
                                               reply_markup=markup)
        except BadRequest as exc:
            if "message is not modified" not in str(exc).lower():
                raise
        except TelegramError:
            raise


async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if query is None:  # defensive: PTB always provides one, but never crash
        return
    user = update.effective_user
    data = (query.data or "")[:128]
    ctx = QueryCtx(query)
    if not user:
        return
    if not await gate(update):
        await ctx.answer()
        return
    uid = user.id
    try:
        await _route_callback(update, context, ctx, data, uid)
    except WatermarkError as exc:
        await ctx.answer(str(exc)[:180], alert=True)
    except BadRequest as exc:
        LOG.warning("Telegram rejected an edit (%s)", exc)
        await ctx.answer("Could not update this screen.", alert=True)
    except Exception as exc:  # noqa: BLE001
        LOG.exception("Callback error data=%s", data)
        DB.log_error(uid, "callback", f"{type(exc).__name__}: {exc}")
        await ctx.answer("Something went wrong.", alert=True)
    finally:
        await ctx.answer()


def _media_or_default(value: Optional[str]) -> str:
    return value if value in MEDIA_KEYS else "global"


async def _show_category(ctx: QueryCtx, uid: int, media: str) -> None:
    media = _media_or_default(media)
    s = DB.get_settings(uid, media)
    await ctx.screen(category_text(media, s), category_kb(media, s))


async def _route_callback(update: Update, context: ContextTypes.DEFAULT_TYPE,
                          ctx: QueryCtx, data: str, uid: int) -> None:
    parts = data.split(":")
    head = parts[0]
    tail = parts[1:]

    # ---------------- navigation ----------------
    if head == "nav":
        action = tail[0] if tail else ""
        if action == "main":
            await ctx.answer()
            await ctx.screen(main_menu_text(), main_menu_kb())
            return
        if action == "hub":
            await ctx.answer()
            await ctx.screen(settings_hub_text(), settings_hub_kb())
            return
        if action == "myset":
            await ctx.answer()
            await ctx.screen(my_settings_text(uid), my_settings_kb())
            return
        if action == "status":
            await ctx.answer()
            await ctx.screen(status_text(uid), back_kb())
            return
        if action == "help":
            await ctx.answer()
            await ctx.screen(help_text(), back_kb())
            return
        if action == "about":
            await ctx.answer()
            await ctx.screen(about_text(), back_kb())
            return
        if action == "add":
            set_state(uid, "auto")
            await ctx.answer()
            await ctx.screen(
                "➕ <b>Add Watermark</b>\n\nSend me an image, PDF or video and I will "
                "return it watermarked with your saved settings.",
                kb([[btn("🏠 Back to Start", "nav:main"), CANCEL_BTN]]))
            return
        if action == "batch":
            set_state(uid, "batch", files=[])
            await ctx.answer()
            await ctx.screen(
                f"⚡ <b>Batch Processing</b>\n\nSend up to <b>{limit_max_batch()}</b> files "
                "(images / PDFs / videos). Tap ✅ Done when finished.",
                batch_kb())
            return
        if action == "cancel":
            clear_state(uid)
            await ctx.answer("Cancelled.")
            await ctx.screen("❌ Cancelled.", back_kb())
            return
        if action == "catback" and len(tail) > 1:
            await ctx.answer()
            await _show_category(ctx, uid, tail[1])
            return
        await ctx.answer()
        return

    # ---------------- processing entry points ----------------
    if head == "proc" and tail:
        kind = tail[0]
        if kind not in ("image", "pdf", "video"):
            await ctx.answer("Unknown action.", alert=True)
            return
        set_state(uid, f"proc_{kind}")
        names = {"image": "an image (JPG/PNG/WEBP)", "pdf": "a PDF", "video": "a video"}
        await ctx.answer()
        await ctx.screen(f"📥 Send me {names[kind]} to watermark.",
                         kb([[btn("🏠 Back to Start", "nav:main"), CANCEL_BTN]]))
        return

    # ---------------- category screens ----------------
    if head == "cat" and tail:
        await ctx.answer()
        await _show_category(ctx, uid, tail[0])
        return

    # ---------------- batch ----------------
    if head == "batch":
        if len(tail) < 1:
            await ctx.answer()
            return
        act = tail[0]
        st = get_state(uid)
        if act == "cancel":
            clear_state(uid)
            await ctx.answer("Batch cancelled.")
            await ctx.screen("❌ Batch cancelled.", back_kb())
            return
        if act == "done":
            if not st or st.get("kind") != "batch" or not st.get("files"):
                await ctx.answer("No files collected.", alert=True)
                return
            files = list(st["files"])
            clear_state(uid)
            await ctx.answer()
            await ctx.screen(f"⚡ Processing {len(files)} file(s)…", back_kb())
            await run_batch(update, context, files)
            return
        await ctx.answer()
        return

    # ---------------- admin-only sections ----------------
    if head in ("adm", "lim"):
        if not is_admin(uid):
            await ctx.answer("⛔ Access Denied: Admin only command.", alert=True)
            return
        await _route_admin(update, context, ctx, head, tail, uid)
        return

    # ---------------- settings actions & value setters ----------------
    if len(tail) < 1:
        await ctx.answer()
        return
    media = _media_or_default(tail[0])
    await _route_settings(update, context, ctx, head, media, tail[1:], uid)


async def _route_settings(update: Update, context: ContextTypes.DEFAULT_TYPE,
                          ctx: QueryCtx, head: str, media: str,
                          tail: List[str], uid: int) -> None:
    s = DB.get_settings(uid, media)

    if head == "act":
        action = tail[0] if tail else ""
        if action == "toggle":
            s["enabled"] = not s["enabled"]
            DB.save_settings(uid, media, s)
            await ctx.answer("Toggled.")
            await _show_category(ctx, uid, media)
            return
        if action == "reset":
            DB.reset_settings(uid, media)
            await ctx.answer("Reset to defaults.")
            await _show_category(ctx, uid, media)
            return
        if action == "mode":
            order = ["text", "logo", "both"]
            s["mode"] = order[(order.index(s["mode"]) + 1) % 3]
            DB.save_settings(uid, media, s)
            await ctx.answer(f"Mode: {s['mode']}")
            await _show_category(ctx, uid, media)
            return
        prompts = {
            "text": ("text", "✏️ Send the new watermark text:"),
            "colorc": ("color", "🎨 Send a hex color like #FF00AA:"),
            "posc": ("posc", "🎯 Send custom coordinates as: x,y (pixels from top-left):"),
            "rotc": ("rotc", "🔄 Send a rotation angle in degrees (-360..360):"),
            "pdfpages": ("pdfpages", "📄 Pages to watermark: 'all' or e.g. 1,3-5"),
        }
        if action in prompts:
            kind, text = prompts[action]
            set_state(uid, f"set_{kind}", media=media)
            await ctx.answer()
            await ctx.screen(text, kb([[btn("⬅️ Back", f"cat:{media}"), CANCEL_BTN]]))
            return
        screens = {
            "font": ("🔤 Choose a font family:", lambda: font_kb(media, s["font"])),
            "style": ("✨ Style & rotation:", lambda: style_kb(media, s)),
            "size": ("📏 Font size:", lambda: size_kb(media, s)),
            "color": ("🎨 Choose a color:", lambda: color_kb(media, s)),
            "opacity": ("💧 Opacity:", lambda: opacity_kb(media, s)),
            "position": ("📍 Anchor position & margins:", lambda: position_kb(media, s)),
            "badge": ("🧊 Badge & effects:", lambda: badge_kb(media, s)),
            "stroke": ("⚙️ Stroke & shadow:", lambda: stroke_kb(media, s)),
            "logo": ("🖼️ Logo watermark settings:", lambda: logo_kb(media, s, uid)),
        }
        if action in screens:
            text, builder = screens[action]
            await ctx.answer()
            await ctx.screen(text, builder())
            return
        if action == "animation" and media == "video":
            await ctx.answer()
            await ctx.screen("🎬 Choose video animation:", animation_kb(media, s))
            return
        if action == "logoup":
            set_state(uid, "logo", media=media)
            await ctx.answer()
            await ctx.screen("🖼️ Send the logo image (PNG with transparency works best):",
                             kb([[btn("⬅️ Back", f"act:{media}:logo"), CANCEL_BTN]]))
            return
        await ctx.answer()
        return

    # ---- value setters (validated, clamped) ----
    if head == "an":  # animation preset (video only)
        if media != "video":
            await ctx.answer("Animation is available for videos only.", alert=True)
            return
        key = tail[0] if tail else "none"
        if key in VIDEO_ANIMATIONS:
            s["animation"] = key
            DB.save_settings(uid, media, s)
        await ctx.answer(VIDEO_ANIMATIONS.get(s["animation"], "None"))
        await ctx.screen("🎬 Choose video animation:", animation_kb(media, s))
        return

    if head == "as":  # animation speed
        if media != "video":
            await ctx.answer("Animation speed is available for videos only.", alert=True)
            return
        direction = tail[0] if tail else ""
        speed = float(s.get("animation_speed", 1.0))
        speed = min(8.0, speed + 0.1) if direction == "+" else max(0.1, speed - 0.1)
        s["animation_speed"] = round(speed, 1)
        DB.save_settings(uid, media, s)
        await ctx.answer(f"Speed {s['animation_speed']:.1f}x")
        await ctx.screen("🎬 Choose video animation:", animation_kb(media, s))
        return

    if head == "f":  # font family
        family = tail[0] if tail else ""
        if family in FONT_FAMILIES:
            s["font"] = family
            DB.save_settings(uid, media, s)
        await ctx.answer(s["font"])
        await ctx.screen("🔤 Choose a font family:", font_kb(media, s["font"]))
        return

    if head == "st":  # style / rotation
        act = tail[0] if tail else ""
        if act == "bold":
            s["bold"] = not s["bold"]
        elif act == "italic":
            s["italic"] = not s["italic"]
        elif act == "rot0":
            s["rotation"] = 0
        elif act == "rot45":
            s["rotation"] = 45
        elif act == "rot90":
            s["rotation"] = 90
        elif act == "rotm45":
            s["rotation"] = -45
        DB.save_settings(uid, media, s)
        await ctx.answer()
        await ctx.screen("✨ Style & rotation:", style_kb(media, s))
        return

    if head == "sz":  # font size
        val = tail[0] if tail else ""
        if val == "+":
            s["font_size"] = min(400, s["font_size"] + 4)
        elif val == "-":
            s["font_size"] = max(8, s["font_size"] - 4)
        else:
            try:
                s["font_size"] = max(8, min(400, int(val)))
            except (TypeError, ValueError):
                await ctx.answer("Invalid size.", alert=True)
                return
        DB.save_settings(uid, media, s)
        await ctx.answer(f"{s['font_size']} px")
        await ctx.screen("📏 Font size:", size_kb(media, s))
        return

    if head == "c":  # color preset
        raw = "#" + (tail[0] if tail else "")
        try:
            hex_to_rgb(raw)
        except WatermarkError:
            await ctx.answer("Bad color", alert=True)
            return
        s["color"] = raw.upper()
        DB.save_settings(uid, media, s)
        await ctx.answer(s["color"])
        await ctx.screen("🎨 Choose a color:", color_kb(media, s))
        return

    if head == "o":  # opacity (text or logo)
        if len(tail) < 2:
            await ctx.answer()
            return
        key, val = tail[0], tail[1]
        if key not in ("opacity", "logo_opacity"):
            await ctx.answer("Unknown setting.", alert=True)
            return
        cur = int(s.get(key, 75))
        if val == "+":
            cur = min(100, cur + 5)
        elif val == "-":
            cur = max(0, cur - 5)
        else:
            try:
                cur = max(0, min(100, int(val)))
            except (TypeError, ValueError):
                await ctx.answer("Invalid value.", alert=True)
                return
        s[key] = cur
        DB.save_settings(uid, media, s)
        await ctx.answer(f"{cur}%")
        await ctx.screen("💧 Opacity:", opacity_kb(media, s, key))
        return

    if head == "p":  # position & margin
        act = tail[0] if tail else ""
        if act == "m+":
            s["margin"] = min(1000, s["margin"] + 5)
        elif act == "m-":
            s["margin"] = max(0, s["margin"] - 5)
        elif act in POSITIONS:
            s["position"] = act
        else:
            await ctx.answer("Unknown position.", alert=True)
            return
        DB.save_settings(uid, media, s)
        await ctx.answer()
        await ctx.screen("📍 Anchor position & margins:", position_kb(media, s))
        return

    if head == "b":  # badge & tiling
        act = tail[0] if tail else ""
        if act in ("plain", "box"):
            s["badge"] = act
            s["tiled"] = False
        elif act == "tile":
            s["tiled"] = not s["tiled"]
        elif act == "sp+":
            s["tile_spacing"] = min(2000, s["tile_spacing"] + 10)
        elif act == "sp-":
            s["tile_spacing"] = max(0, s["tile_spacing"] - 10)
        else:
            await ctx.answer()
            return
        DB.save_settings(uid, media, s)
        await ctx.answer()
        await ctx.screen("🧊 Badge & effects:", badge_kb(media, s))
        return

    if head == "k":  # stroke & shadow
        act = tail[0] if tail else ""
        if act == "stroke":
            s["stroke"] = not s["stroke"]
        elif act == "shadow":
            s["shadow"] = not s["shadow"]
        elif act == "w+":
            s["stroke_width"] = min(40, s["stroke_width"] + 1)
        elif act == "w-":
            s["stroke_width"] = max(0, s["stroke_width"] - 1)
        else:
            await ctx.answer()
            return
        DB.save_settings(uid, media, s)
        await ctx.answer()
        await ctx.screen("⚙️ Stroke & shadow:", stroke_kb(media, s))
        return

    if head == "lg":  # logo controls
        act = tail[0] if tail else ""
        if act == "s+":
            s["logo_scale"] = min(200, s["logo_scale"] + 5)
        elif act == "s-":
            s["logo_scale"] = max(1, s["logo_scale"] - 5)
        elif act == "o+":
            s["logo_opacity"] = min(100, s["logo_opacity"] + 5)
        elif act == "o-":
            s["logo_opacity"] = max(0, s["logo_opacity"] - 5)
        elif act == "r0":
            s["logo_rotation"] = 0
        elif act == "r90":
            s["logo_rotation"] = 90
        elif act == "tile":
            s["logo_tiled"] = not s["logo_tiled"]
        elif act == "clear":
            with _suppress_os_error():
                os.remove(logo_file_for(uid, media))
            await ctx.answer("Logo removed.")
        DB.save_settings(uid, media, s)
        await ctx.answer()
        await ctx.screen("🖼️ Logo watermark settings:", logo_kb(media, s, uid))
        return

    await ctx.answer()


async def _route_admin(update: Update, context: ContextTypes.DEFAULT_TYPE,
                       ctx: QueryCtx, head: str, tail: List[str], uid: int) -> None:
    if head == "lim":
        if len(tail) < 2:
            await ctx.answer()
            return
        key, direction = tail[0], tail[1]
        if key == "batch":
            cur = limit_max_batch()
            cur = min(50, cur + 1) if direction == "+" else max(2, cur - 1)
            DB.kv_set("max_batch", str(cur))
            await ctx.answer(f"Batch limit: {cur}")
        else:
            cur = limit_rate_per_min()
            cur = min(600, cur + 5) if direction == "+" else max(5, cur - 5)
            DB.kv_set("rate_per_min", str(cur))
            await ctx.answer(f"Rate limit: {cur}/min")
        await ctx.screen(_admin_stats_text(), admin_kb())
        return

    # head == "adm"
    act = tail[0] if tail else ""
    if act == "stats":
        await ctx.answer()
        await ctx.screen(_admin_stats_text(), admin_kb())
        return
    if act == "clean":
        removed = await asyncio.get_running_loop().run_in_executor(None, clean_temp_dir, 0)
        await ctx.answer(f"Removed {removed} temp file(s).", alert=True)
        await ctx.screen(_admin_stats_text(), admin_kb())
        return
    if act == "errors":
        rows = [[r["ts"][11:19], str(r["user_id"]), _trunc(r["message"], 34)]
                for r in DB.recent_errors()]
        text = ("📜 <b>Recent Errors</b>\n<pre>" +
                esc(box_table(["Time", "User", "Message"], rows) if rows else "(no errors)") +
                "</pre>")
        await ctx.answer()
        await ctx.screen(text, kb([[btn("⬅️ Back", "adm:stats")]]))
        return
    if act == "broadcast":
        set_state(uid, "broadcast")
        await ctx.answer()
        await ctx.screen("📢 Send the message to broadcast to all users "
                         "(text or media).", kb([[CANCEL_BTN]]))
        return
    await ctx.answer()


# ==========================================================================
# 19. Batch runner
# ==========================================================================
async def run_batch(update: Update, context: ContextTypes.DEFAULT_TYPE,
                    files: List[Tuple[str, str, str]]) -> None:
    """files: list of (file_id, ext, original_name). One failure never kills the batch."""
    uid = update.effective_user.id
    chat = update.effective_chat
    assert chat is not None
    results: List[Tuple[str, str]] = []   # (output_path, archive_name)
    failed = 0
    status = await context.bot.send_message(chat.id, "⚡ Starting batch…")
    loop = asyncio.get_running_loop()

    async with user_lock(uid):
        for i, item in enumerate(files, 1):
            file_id, ext, original = (list(item) + [""])[:3]
            kind = media_kind_of(ext) or "image"
            s = DB.get_settings(uid, kind)
            path = None
            out_path = None
            try:
                with _suppress_os_error():
                    await status.edit_text(f"⚡ Batch {i}/{len(files)} — downloading…")
                file = await _tg_retry(lambda fid=file_id: context.bot.get_file(fid))
                if int(file.file_size or 0) > effective_download_limit():
                    raise WatermarkError("file too large for the current Bot API limits")
                name = sanitize_filename(original or f"file{ext}")
                path = safe_join(user_temp(uid), name)
                await _tg_retry(lambda p=path: file.download_to_drive(p))
                if not os.path.isfile(path):
                    raise WatermarkError("download incomplete")

                out_name = "out_" + os.path.splitext(name)[0] + (
                    ".mp4" if kind == "video" else os.path.splitext(name)[1] or ".bin")
                out_path = safe_join(user_temp(uid), out_name)

                with _suppress_os_error():
                    await status.edit_text(f"⚡ Batch {i}/{len(files)} — processing {kind}…")
                async with job_semaphore():
                    if kind == "video":
                        ffmpeg = find_ffmpeg()
                        if not ffmpeg:
                            raise WatermarkError("FFmpeg missing")
                        await process_video_file(path, out_path, s, uid, ffmpeg)
                    elif kind == "pdf":
                        await asyncio.wait_for(
                            loop.run_in_executor(None, process_pdf_file, path, out_path,
                                                 s, uid, None),
                            timeout=CFG.process_timeout)
                    else:
                        await asyncio.wait_for(
                            loop.run_in_executor(None, process_image_file, path, out_path,
                                                 s, uid),
                            timeout=CFG.process_timeout)
                results.append((out_path, os.path.basename(out_name)[4:]))
                DB.bump_stat(uid, kind)
            except Exception as exc:  # noqa: BLE001 - isolate per-file failures
                failed += 1
                DB.bump_stat(uid, "error")
                DB.log_error(uid, "batch", f"file {i}: {type(exc).__name__}: {exc}")
                LOG.warning("Batch file %s failed: %s", i, exc)
            finally:
                for p in (path,):
                    if p:
                        with _suppress_os_error():
                            os.remove(p)

        DB.bump_stat(uid, "batch")
        if not results:
            with _suppress_os_error():
                await status.edit_text("⚠️ Batch finished, but every file failed. "
                                       "Check that the files are supported and within "
                                       "the size limits.")
            return

        upload_limit = effective_upload_limit()
        zip_path = None
        try:
            if len(results) == 1:
                out_path, arcname = results[0]
                size = os.path.getsize(out_path)
                if size <= upload_limit:
                    caption = ("✅ Batch complete (1 file)." if not failed
                               else f"✅ Batch complete: 1 OK, {failed} failed.")
                    with open(out_path, "rb") as fh:
                        await context.bot.send_document(
                            chat.id, fh, filename=arcname or "watermarked",
                            caption=caption)
                else:
                    with _suppress_os_error():
                        await status.edit_text(
                            f"✅ Done, but the result ({human_size(size)}) cannot be "
                            "uploaded with the current Telegram transport. Configure a "
                            "self-hosted Bot API server for large files.")
                return
            zip_path = safe_join(user_temp(uid), f"batch_{uuid.uuid4().hex[:6]}.zip")
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
                for out_path, arcname in results:
                    zf.write(out_path, arcname or os.path.basename(out_path))
            size = os.path.getsize(zip_path)
            if size <= upload_limit:
                with open(zip_path, "rb") as fh:
                    await context.bot.send_document(
                        chat.id, fh, filename="watermarked_batch.zip",
                        caption=f"✅ Batch complete: {len(results)} OK, {failed} failed.")
            else:
                with _suppress_os_error():
                    await status.edit_text(
                        f"✅ {len(results)} files processed, but the ZIP "
                        f"({human_size(size)}) exceeds the current upload limit "
                        f"({human_size(upload_limit)}). Configure a self-hosted Bot API "
                        "server for large files.")
        finally:
            with _suppress_os_error():
                await status.delete()
            for out_path, _ in results:
                with _suppress_os_error():
                    os.remove(out_path)
            if zip_path:
                with _suppress_os_error():
                    os.remove(zip_path)


# ==========================================================================
# 20. Message router (states + menu + files)
# ==========================================================================
async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update):
        return
    msg = update.message
    assert msg is not None
    uid = update.effective_user.id
    text = (msg.text or "").strip()

    if text in ("☰ Menu", "/menu"):
        await msg.reply_text(main_menu_text(), parse_mode=ParseMode.HTML,
                             reply_markup=main_menu_kb())
        return

    st = get_state(uid)

    # ---------- state-driven inputs ----------
    if st:
        kind = st.get("kind", "")

        if kind == "broadcast":
            if not is_admin(uid):
                clear_state(uid)
                await deny(update)
                return
            users = DB.all_user_ids()
            sent = err = 0
            status = await msg.reply_text(f"📢 Broadcasting to {len(users)} users…")
            for index, target in enumerate(users, 1):
                try:
                    await context.bot.copy_message(target, msg.chat.id, msg.message_id)
                    sent += 1
                except RetryAfter as exc:  # must precede TelegramError (subclass)
                    wait = float(getattr(exc, "retry_after", 1) or 1)
                    await asyncio.sleep(min(wait + 0.5, 30))
                    try:
                        await context.bot.copy_message(target, msg.chat.id, msg.message_id)
                        sent += 1
                    except TelegramError:
                        err += 1
                except TelegramError:
                    err += 1
                if index % 25 == 0:  # stay well below Telegram's global flood limits
                    await asyncio.sleep(1.0)
                else:
                    await asyncio.sleep(0.05)
            clear_state(uid)
            with _suppress_os_error():
                await status.edit_text(f"📢 Broadcast done: {sent} sent, {err} failed.")
            LOG.info("Broadcast by admin %s: %s sent, %s failed", uid, sent, err)
            return

        if kind.startswith("set_"):
            media = _media_or_default(st.get("media"))
            s = DB.get_settings(uid, media)
            field = kind[4:]
            value = (msg.text or msg.caption or "").strip()
            ok = True
            if field == "text":
                cleaned = sanitize_watermark_text(value)
                if not cleaned:
                    ok = False
                else:
                    s["text"] = cleaned
            elif field == "color":
                try:
                    hex_to_rgb(value)
                    s["color"] = normalize_hex(value)
                except WatermarkError:
                    ok = False
            elif field == "posc":
                m = re.match(r"^\s*(-?\d{1,6})\s*,\s*(-?\d{1,6})\s*$", value)
                if not m:
                    ok = False
                else:
                    s["position"] = "custom"
                    s["custom_x"] = _clamp_int(m.group(1), -100000, 100000, 0)
                    s["custom_y"] = _clamp_int(m.group(2), -100000, 100000, 0)
            elif field == "rotc":
                if re.fullmatch(r"-?\d{1,3}", value) and -360 <= int(value) <= 360:
                    s["rotation"] = int(value)
                else:
                    ok = False
            elif field == "pdfpages":
                cleaned = value[:100].strip() or "all"
                try:
                    parse_page_spec(cleaned, max(1, CFG.max_pdf_pages))
                except WatermarkError:
                    ok = False
                else:
                    s["pdf_pages"] = cleaned
            else:
                ok = False
            if not ok:
                await msg.reply_text("⚠️ Invalid input, please try again.",
                                     reply_markup=kb([[btn("⬅️ Back", f"cat:{media}"),
                                                       CANCEL_BTN]]))
                return
            DB.save_settings(uid, media, s)
            clear_state(uid)
            await msg.reply_text(category_text(media, s), parse_mode=ParseMode.HTML,
                                 reply_markup=category_kb(media, s))
            return

        if kind == "logo":
            is_photo = bool(msg.photo)
            is_image_doc = bool(msg.document and (msg.document.mime_type or "")
                                .startswith("image/"))
            if not (is_photo or is_image_doc):
                await msg.reply_text("⚠️ Please send an image file as the logo.")
                return
            media = _media_or_default(st.get("media"))
            tmp = None
            try:
                file = await _tg_retry((msg.photo[-1].get_file if is_photo
                                        else msg.document.get_file))
                if int(file.file_size or 0) > MAX_LOGO_BYTES:
                    raise WatermarkError(f"Logo too large (max "
                                         f"{human_size(MAX_LOGO_BYTES)}).")
                tmp = safe_join(user_temp(uid), sanitize_filename("logo_upload.png"))
                await _tg_retry(lambda p=tmp: file.download_to_drive(p))
                with Image.open(tmp) as im:
                    im.load()
                    _check_pixel_budget(im)
                    im.convert("RGBA").save(logo_file_for(uid, media), format="PNG")
            except WatermarkError as exc:
                await msg.reply_text(f"⚠️ {esc(str(exc))}", parse_mode=ParseMode.HTML)
                return
            except Exception as exc:  # noqa: BLE001
                LOG.warning("Logo upload failed: %s", exc)
                await msg.reply_text("⚠️ That image could not be read. Send a PNG, JPG "
                                     "or WEBP logo.")
                return
            finally:
                if tmp:
                    with _suppress_os_error():
                        os.remove(tmp)
            s = DB.get_settings(uid, media)
            clear_state(uid)
            await msg.reply_text("✅ Logo saved!", reply_markup=logo_kb(media, s, uid))
            return

        if kind == "batch":
            if msg.photo:
                fid, ext = msg.photo[-1].file_id, ".jpg"
                original = "photo.jpg"
            elif msg.video:
                name = msg.video.file_name or "video.mp4"
                fid = msg.video.file_id
                ext = os.path.splitext(name)[1].lower() or ".mp4"
                original = name
            elif msg.document:
                name = msg.document.file_name or ""
                fid = msg.document.file_id
                ext = os.path.splitext(name)[1].lower()
                original = name or f"file{ext}"
            else:
                await msg.reply_text("⚠️ Send supported files, or tap ✅ Done.")
                return
            if media_kind_of(ext) is None:
                await msg.reply_text("⚠️ Unsupported file type skipped.")
                return
            if len(st["files"]) >= limit_max_batch():
                await msg.reply_text(f"⚠️ Batch limit reached ({limit_max_batch()}). "
                                     "Tap ✅ Done.")
                return
            st["files"].append((fid, ext, original))
            st["ts"] = time.time()
            await msg.reply_text(f"📥 Added {len(st['files'])}/{limit_max_batch()} — "
                                 "send more or tap ✅ Done.", reply_markup=batch_kb())
            return

        if kind in ("auto", "proc_image", "proc_pdf", "proc_video"):
            expected = {"proc_image": "image", "proc_pdf": "pdf",
                        "proc_video": "video"}.get(kind)
            try:
                path, ext, _size, _orig = await download_update_file(update)
            except WatermarkError as exc:
                await msg.reply_text(f"⚠️ {esc(str(exc))}", parse_mode=ParseMode.HTML)
                return
            except TelegramError:
                LOG.exception("Download failed")
                await msg.reply_text("⚠️ Telegram could not download this file. For files "
                                     "larger than 20 MB, configure a self-hosted Bot API "
                                     "server.")
                return
            got = media_kind_of(ext)
            if got is None:
                with _suppress_os_error():
                    os.remove(path)
                await msg.reply_text("⚠️ Unsupported file type. Send an image, PDF or "
                                     "video.")
                return
            if expected and got != expected:
                with _suppress_os_error():
                    os.remove(path)
                await msg.reply_text(f"⚠️ I expected a {expected} file, but this looks "
                                     f"like a {got}.")
                return
            if user_lock(uid).locked():
                with _suppress_os_error():
                    os.remove(path)
                await msg.reply_text("⏳ Please wait for your current file to finish.")
                return
            async with user_lock(uid):
                clear_state(uid)
                await process_and_send(update, context, path, got)
            return

    # ---------- no state: answer politely ----------
    if text:
        await msg.reply_text("🤔 I didn't understand that. Use /start for the menu or "
                             "/help for a guide.", reply_markup=back_kb())
        return
    await msg.reply_text("Send /start to open the menu, then send an image, PDF or "
                         "video to watermark it.", reply_markup=back_kb())


# ==========================================================================
# 21. Global error handler & maintenance jobs
# ==========================================================================
async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    exc = context.error
    uid = update.effective_user.id if isinstance(update, Update) and update.effective_user else None
    if isinstance(exc, InvalidToken):
        LOG.error("Invalid bot token — re-copy BOT_TOKEN from @BotFather.")
        return
    LOG.exception("Unhandled update error")
    try:
        DB.log_error(uid, "update", f"{type(exc).__name__}: {exc}")
    except Exception:  # noqa: BLE001
        pass
    if isinstance(update, Update) and update.message:
        try:
            await update.message.reply_text("⚠️ An unexpected error occurred. "
                                            "Please try again.")
        except TelegramError:
            pass


async def cleanup_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    loop = asyncio.get_running_loop()
    removed, expired = await asyncio.gather(
        loop.run_in_executor(None, clean_temp_dir, 3600),
        loop.run_in_executor(None, sweep_states))
    if removed or expired:
        LOG.info("Maintenance: removed %d temp file(s), expired %d session(s)",
                 removed, expired)


# ==========================================================================
# 22. Optional local Telegram Bot API server support
# ==========================================================================
LOCAL_BOT_API_PROCESS: Optional[subprocess.Popen] = None


def _port_open(host: str, port: int, timeout: float = 0.5) -> bool:
    import socket

    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _local_api_reachable(base_url: str) -> bool:
    """Cheap TCP probe of the configured local Bot API endpoint."""
    m = re.match(r"^https?://([^:/]+):?(\d*)", base_url or "")
    if not m:
        return False
    host = m.group(1)
    port = int(m.group(2) or (443 if base_url.startswith("https") else 80))
    return _port_open(host, port)


def _find_local_api_executable() -> Optional[str]:
    found = shutil.which("telegram-bot-api")
    if found:
        return found
    for candidate in ("/usr/local/bin/telegram-bot-api",
                      "/usr/bin/telegram-bot-api",
                      str(Path.home() / "telegram-bot-api/build/telegram-bot-api"),
                      str(Path.home() / "telegram-bot-api/build/bin/telegram-bot-api")):
        if _is_executable(candidate):
            return candidate
    return None


def start_local_bot_api_if_available() -> bool:
    """Start/verify the Local Bot API server. Never fatal, never logs secrets.

    Returns True when a local endpoint is in use.
    """
    global LOCAL_BOT_API_PROCESS

    if CFG.local_api_base_url and _local_api_reachable(CFG.local_api_base_url):
        LOG.info("Using Local Bot API server at %s", CFG.local_api_base_url)
        return True

    if not CFG.use_local_bot_api and not CFG.auto_start_local_bot_api:
        if CFG.local_api_base_url:
            LOG.warning("TELEGRAM_API_BASE_URL is set (%s) but unreachable — falling "
                        "back to the standard Bot API (20 MB download / 50 MB upload).",
                        CFG.local_api_base_url)
            CFG.local_api_base_url = ""
            CFG.local_api_file_url = ""
        else:
            LOG.info("Using the standard Telegram Bot API")
        return False

    if not CFG.auto_start_local_bot_api:
        LOG.warning("Local Bot API configured but AUTO_START_LOCAL_BOT_API is off and "
                    "no server answered on the configured endpoint.")
        return False

    executable = _find_local_api_executable()
    if not executable:
        LOG.warning("Local Bot API server binary 'telegram-bot-api' not found — "
                    "continuing on the standard Bot API (20 MB / 50 MB limits).")
        return False
    if not CFG.telegram_api_id or not CFG.telegram_api_hash:
        LOG.warning("TELEGRAM_API_ID / TELEGRAM_API_HASH are not set — cannot start the "
                    "Local Bot API server; continuing on the standard Bot API.")
        return False
    port = CFG.local_api_port
    if _port_open("127.0.0.1", port):
        LOG.info("Local Bot API server already listening on port %s", port)
        CFG.local_api_base_url = f"http://127.0.0.1:{port}/bot"
        CFG.local_api_file_url = f"http://127.0.0.1:{port}/file/bot"
        return True

    command = [executable,
               "--api-id", str(CFG.telegram_api_id),
               "--api-hash", CFG.telegram_api_hash,
               "--local", "--http-port", str(port)]
    try:
        LOCAL_BOT_API_PROCESS = subprocess.Popen(
            command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True)
        for _ in range(30):  # wait up to ~3 s for the port to open
            time.sleep(0.1)
            if LOCAL_BOT_API_PROCESS.poll() is not None:
                LOG.warning("Local Bot API server exited immediately (code=%s); "
                            "continuing on the standard Bot API.",
                            LOCAL_BOT_API_PROCESS.returncode)
                LOCAL_BOT_API_PROCESS = None
                return False
            if _port_open("127.0.0.1", port):
                CFG.local_api_base_url = f"http://127.0.0.1:{port}/bot"
                CFG.local_api_file_url = f"http://127.0.0.1:{port}/file/bot"
                LOG.info("Started Local Bot API server on port %s", port)
                return True
        LOG.warning("Local Bot API server did not open port %s in time; continuing on "
                    "the standard Bot API.", port)
        return False
    except (OSError, subprocess.SubprocessError) as exc:
        LOG.warning("Could not start the Local Bot API server (%s); continuing on the "
                    "standard Bot API.", exc)
        LOCAL_BOT_API_PROCESS = None
        return False


def stop_local_bot_api() -> None:
    global LOCAL_BOT_API_PROCESS
    proc, LOCAL_BOT_API_PROCESS = LOCAL_BOT_API_PROCESS, None
    if proc is None or proc.poll() is not None:
        return
    try:
        proc.terminate()
        proc.wait(timeout=8)
        LOG.info("Stopped Local Bot API server")
    except subprocess.TimeoutExpired:
        with _suppress_os_error():
            proc.kill()
        with _suppress_os_error():
            proc.wait(timeout=5)
    except Exception as exc:  # noqa: BLE001
        LOG.warning("Could not stop the Local Bot API server cleanly: %s", exc)


# ==========================================================================
# 23. Application bootstrap
# ==========================================================================
async def post_init(application: Application) -> None:
    try:
        await application.bot.set_my_commands([
            BotCommand("start", "Main menu"),
            BotCommand("settings", "Watermark settings hub"),
            BotCommand("mysettings", "View my configuration"),
            BotCommand("status", "Bot & system status"),
            BotCommand("id", "Show your Telegram user ID"),
            BotCommand("help", "Help & guide"),
            BotCommand("about", "About this bot"),
            BotCommand("cancel", "Cancel current action"),
            BotCommand("admin", "Admin panel"),
            BotCommand("allow", "Admin: grant admin rights"),
            BotCommand("block", "Admin: block a user"),
            BotCommand("unblock", "Admin: unblock a user"),
            BotCommand("broadcast", "Admin: broadcast a message"),
        ])
    except TelegramError as exc:
        LOG.warning("Could not register bot commands: %s", exc)


def build_application() -> Application:
    builder = (
        Application.builder()
        .token(CFG.bot_token)
        .concurrent_updates(True)
        .post_init(post_init)
        .read_timeout(60)
        .write_timeout(600)
        .connect_timeout(30)
        .pool_timeout(30)
    )
    if CFG.local_api_base_url:
        builder = builder.base_url(CFG.local_api_base_url)
        if CFG.local_api_file_url:
            builder = builder.base_file_url(CFG.local_api_file_url)
        LOG.info("Telegram Bot API endpoint: %s", CFG.local_api_base_url)
    else:
        LOG.warning("Running on the standard Telegram Bot API: downloads are capped at "
                    "~20 MB and uploads at ~50 MB. Install a Local Bot API server to "
                    "raise these limits.")
    application = builder.build()

    handlers = [
        CommandHandler("start", cmd_start),
        CommandHandler("menu", cmd_start),
        CommandHandler("help", cmd_help),
        CommandHandler("about", cmd_about),
        CommandHandler("settings", cmd_settings),
        CommandHandler("mysettings", cmd_mysettings),
        CommandHandler("status", cmd_status),
        CommandHandler("id", cmd_id),
        CommandHandler("cancel", cmd_cancel),
        CommandHandler("allow", cmd_allow),
        CommandHandler("block", cmd_block),
        CommandHandler("unblock", cmd_unblock),
        CommandHandler("admin", cmd_admin),
        CommandHandler("stats", cmd_stats),
        CommandHandler("broadcast", cmd_broadcast),
        CommandHandler("cleanup", cmd_cleanup),
        CallbackQueryHandler(on_callback),
        MessageHandler(filters.ALL & ~filters.COMMAND, on_message),
    ]
    for handler in handlers:
        application.add_handler(handler)
    application.add_error_handler(on_error)
    if application.job_queue is not None:
        application.job_queue.run_repeating(cleanup_job, interval=3600, first=60)
    else:
        LOG.warning("Job queue unavailable — install 'python-telegram-bot[job-queue]' "
                    "for automatic temp cleanup.")
    return application


# ==========================================================================
# 24. Scaffolding (python bot.py --scaffold)
# ==========================================================================
SCAFFOLD_FILES: Dict[str, str] = {
    '.gitignore': r'''# Secrets — never commit
.env
.env.*
!.env.example

# Runtime data
*.db
*.db-wal
*.db-shm
wm_temp/
logos/
*.log

# Python
__pycache__/
*.py[cod]
.venv/
venv/
build/
dist/
*.egg-info/
.pytest_cache/
''',
    'requirements.txt': r'''python-telegram-bot[job-queue]>=21.0
Pillow>=10.0
PyMuPDF>=1.24
psutil>=5.9
python-dotenv>=1.0
imageio-ffmpeg>=0.4.9
''',
    '.env.example': r'''# ---------------------------------------------------------------------------
# Viraj Watermark — configuration. Copy to .env and fill in (never commit .env).
# ---------------------------------------------------------------------------

# --- Required ---------------------------------------------------------------
# From @BotFather on Telegram (BotFather -> /newbot -> copy the token)
BOT_TOKEN=123456789:AAReplaceWithYourRealTokenFromBotFather

# Comma-separated Telegram user IDs allowed to use the admin panel.
# Get your numeric ID by sending /id to the bot, or from @userinfobot.
ADMIN_IDS=123456789

# --- Optional (sensible defaults when unset) ---------------------------------
DATABASE_PATH=./watermark_bot.db
TEMP_DIRECTORY=./wm_temp
LOG_FILE=

# Incoming file size cap in bytes (default 2 GiB).
# The standard Bot API additionally caps downloads at ~20 MB.
MAX_FILE_SIZE=2147483648
# Upload cap for results (only effective with a Local Bot API server).
MAX_UPLOAD_SIZE=2147483648
# Safety caps
MAX_PDF_PAGES=400
MAX_IMAGE_PIXELS=178956970
MAX_BATCH=10
MAX_CONCURRENT_JOBS=4
RATE_PER_MIN=60
STATE_TTL=3600

# Timeouts (seconds)
VIDEO_TIMEOUT=900
PROCESS_TIMEOUT=240

# Fonts / binaries (auto-detected when empty)
FONT_PATH=
FFMPEG_PATH=

# "Contact Admin" button target
ADMIN_CONTACT_URL=https://t.me/your_username

# --- Dependency auto-install -------------------------------------------------
# Set to 0 to require manual `pip install -r requirements.txt`
AUTO_INSTALL_DEPS=1

# --- Optional: self-hosted Local Telegram Bot API server ---------------------
# Raises the 20 MB download / 50 MB upload caps (up to ~2 GB per file).
# 0 = use the standard API (default). 1 = expect/enable a local server.
USE_LOCAL_BOT_API=0
# TELEGRAM_API_BASE_URL=http://127.0.0.1:8081/bot
# TELEGRAM_API_FILE_URL=http://127.0.0.1:8081/file/bot
# Start the server automatically if the binary is installed (0/1)
AUTO_START_LOCAL_BOT_API=0
TELEGRAM_LOCAL_API_PORT=8081
# Credentials from https://my.telegram.org (needed only to start the server)
TELEGRAM_API_ID=
TELEGRAM_API_HASH=
''',
    'Dockerfile': r'''FROM python:3.12-slim

# FFmpeg + fonts for watermark rendering
RUN apt-get update && apt-get install -y --no-install-recommends \
        ffmpeg fonts-dejavu-core \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY bot.py .

ENV PYTHONUNBUFFERED=1 \
    DATABASE_PATH=/data/watermark_bot.db \
    TEMP_DIRECTORY=/data/wm_temp

RUN mkdir -p /data
VOLUME ["/data"]

CMD ["python", "bot.py"]
''',
    'docker-compose.yml': r'''services:
  watermark-bot:
    build: .
    restart: unless-stopped
    env_file:
      - .env
    volumes:
      - bot-data:/data

volumes:
  bot-data:
''',
    'viraj-watermark.service': r'''[Unit]
Description=Viraj Watermark Telegram Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/viraj-watermark
EnvironmentFile=/opt/viraj-watermark/.env
ExecStart=/opt/viraj-watermark/.venv/bin/python /opt/viraj-watermark/bot.py
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
''',
    'README.md': r'''# Viraj Watermark — Telegram Watermark Bot

Production-ready, single-file Telegram bot (`bot.py`) that adds customizable
watermarks to **images (JPG/JPEG/PNG/WEBP)**, **PDFs** and **videos**, with
batch processing, per-user persistent settings, 26 video animations, an admin
panel and a compact reference-style inline-button UI.

**`bot.py` is the whole project.** Every other file in this repository can be
regenerated from it with `python bot.py --scaffold`. Drop `bot.py` anywhere, add
a `.env`, and it runs.

```
python bot.py            # start the bot
python bot.py --check    # verify environment, dependencies, FFmpeg, DB
python bot.py --selftest # offline engine/security/UI tests (no Telegram)
python bot.py --scaffold # regenerate every other file (docs, Docker, tests)
```

---

## 1. Features

* **Images** — text/logo/both, rotation, tiling, badge box, stroke, shadow,
  opacity, 9 anchors + custom coordinates, EXIF preserved for JPEG.
* **PDFs** — every page or a range (`all`, `1,3-5`), overlay stamp, encrypted
  PDFs rejected with a clear message.
* **Videos** — FFmpeg overlay, 26 animation presets with 0.1x–8x speed,
  audio copied untouched (AAC fallback), `+faststart`, live progress.
* **Batch** — queue up to N files, tap ✅ Done, receive a ZIP. One bad file
  never kills the batch.
* **Per-user settings** — independent Video / Image / PDF configs plus Global
  Defaults that new categories inherit.
* **Admin panel** — stats, CPU/RAM/disk, uptime, recent errors, broadcast,
  block/unblock, temp cleanup, batch & rate limits.
* **Security** — env-only secrets, path-traversal guard, filename
  sanitization, size/format validation, per-user temp isolation, rate
  limiting, per-user locks + a global job semaphore, shell-free subprocesses,
  hard timeouts, redacted logs.

## 2. Requirements

* Python 3.10+
* FFmpeg (for videos) — auto-detected from `FFMPEG_PATH`, `PATH`, or the
  `imageio-ffmpeg` wheel that installs itself on first run
* `pip install -r requirements.txt` (automatic on first run unless
  `AUTO_INSTALL_DEPS=0`)

## 3. Configuration (`.env`)

| Variable | Meaning | Default |
|---|---|---|
| `BOT_TOKEN` | **required**, from @BotFather | – |
| `ADMIN_IDS` | comma-separated admin user IDs | – |
| `DATABASE_PATH` | SQLite file | `./watermark_bot.db` |
| `TEMP_DIRECTORY` | isolated temp dir | `./wm_temp` |
| `MAX_FILE_SIZE` | incoming cap (bytes) | 2 GiB |
| `MAX_UPLOAD_SIZE` | result cap (bytes) | 2 GiB |
| `MAX_PDF_PAGES` / `MAX_IMAGE_PIXELS` | safety caps | 400 / 178 956 970 |
| `MAX_BATCH` / `MAX_CONCURRENT_JOBS` / `RATE_PER_MIN` | throughput | 10 / 4 / 60 |
| `VIDEO_TIMEOUT` / `PROCESS_TIMEOUT` | seconds | 900 / 240 |
| `FONT_PATH` / `FFMPEG_PATH` | optional explicit binaries | auto-detect |
| `ADMIN_CONTACT_URL` | Contact Admin button | – |
| `USE_LOCAL_BOT_API`, `TELEGRAM_API_BASE_URL`, `TELEGRAM_API_FILE_URL`, `AUTO_START_LOCAL_BOT_API`, `TELEGRAM_API_ID`, `TELEGRAM_API_HASH` | Local Bot API (large files) | off |

## 4. Install & run

```bash
sudo apt update && sudo apt install -y python3 python3-pip ffmpeg   # ffmpeg optional
cd viraj-watermark
python3 -m venv .venv && source .venv/bin/activate
cp .env.example .env && nano .env      # set BOT_TOKEN and ADMIN_IDS
python bot.py                          # dependencies install themselves on first run
```

Docker:

```bash
cp .env.example .env && nano .env
docker compose up -d --build
```

systemd: copy `viraj-watermark.service` to `/etc/systemd/system/`, adjust the
paths, then `systemctl enable --now viraj-watermark`.

## 5. Local Bot API server (large files)

The hosted Bot API caps downloads at ~20 MB and uploads at ~50 MB. A
self-hosted [telegram-bot-api](https://github.com/tdlib/telegram-bot-api)
server raises both to ~2 GB. Build it, then:

```env
USE_LOCAL_BOT_API=1
TELEGRAM_API_BASE_URL=http://127.0.0.1:8081/bot
TELEGRAM_API_FILE_URL=http://127.0.0.1:8081/file/bot
AUTO_START_LOCAL_BOT_API=1
TELEGRAM_API_ID=123456        # https://my.telegram.org
TELEGRAM_API_HASH=abcdef...
```

The bot probes the endpoint on startup: if it answers, it is used; if not, the
bot warns and continues on the standard API instead of crashing.

## 6. Testing

```bash
python bot.py --selftest            # 8 built-in groups (DB, security, UI, all 3 engines)
python bot.py --check               # environment report (token, DB, FFmpeg, fonts, disk)
python bot.py --scaffold            # (re)create tests/, Docker, docs, .env.example
python -m unittest discover -s tests -t .    # 84 unit + integration tests
```

Live Telegram behaviour (menus, callbacks, uploads) requires a real token and
cannot be exercised offline — send `/start` to the bot after deploying.

## 7. Known limitations

* Video watermarking re-encodes video (H.264 / veryfast / CRF 23) to burn the
  overlay in; audio is copied unless the codec is incompatible with MP4.
* PDF watermarks are raster overlay stamps (the original text layer is not
  edited), which keeps any PDF readable and intact.
* Fonts come from the OS (DejaVu/Roboto…); set `FONT_PATH` for a brand font.
  Italic is synthesised when no true italic face exists.
* In-memory session state (text prompts, batch queue) is lost on restart.
* The hosted Bot API's 20 MB / 50 MB caps still apply unless a Local Bot API
  server is configured.
''',
    'tests/__init__.py': r'''''',
    'tests/_bootstrap.py': r'''"""Shared bootstrap for the offline + integration test modules.

Both modules must run against one SQLite file inside a single interpreter run
(``python -m unittest discover``), so configuration happens exactly once here
and cleanup is deferred to process exit via ``atexit``.
"""
from __future__ import annotations

import atexit
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
os.environ.setdefault("AUTO_INSTALL_DEPS", "0")

TMP = os.environ.get("WM_TEST_TMP") or tempfile.mkdtemp(prefix="wm_tests_")
os.environ["DATABASE_PATH"] = os.path.join(TMP, "test.db")
os.environ["TEMP_DIRECTORY"] = os.path.join(TMP, "temp")
os.environ["ADMIN_IDS"] = "1,111"

import importlib  # noqa: E402

# Works whether the single-file bot is called bot.py or main.py.
MODULE_NAME = "bot" if os.path.exists(os.path.join(ROOT, "bot.py")) else "main"
MODULE_PATH = os.path.join(ROOT, MODULE_NAME + ".py")
main = importlib.import_module(MODULE_NAME)  # noqa: E402

main.CFG = main._selftest_config(TMP)
main.CFG.admin_ids = [1, 111]          # 1 = admin in the unit tests, 111 = UI tests
main.CFG.max_file_size = 64 * 1024 * 1024
main.CFG.upload_limit = 64 * 1024 * 1024
main.DB = main.Database(main.CFG.database_path)
main.JOB_SEMAPHORE = None

ADMIN = 111
USER = 222
for _uid, _name in ((1, "tester"), (2, "other"), (ADMIN, "admin"), (USER, "user")):
    main.DB.touch_user(_uid, _name, _name.title())

S = lambda **kw: {**main.DEFAULT_SETTINGS, **kw}  # noqa: E731


def _cleanup() -> None:
    try:
        main.DB.close()
    except Exception:  # noqa: BLE001
        pass
    if not os.environ.get("WM_TEST_TMP"):   # keep the dir when debugging is requested
        shutil.rmtree(TMP, ignore_errors=True)


atexit.register(_cleanup)
''',
    'tests/test_offline.py': r'''#!/usr/bin/env python3
"""Offline unit tests for the single-file bot — engines, security helpers, DB, UI builders.

No Telegram connection and no bot token are required.

    python -m unittest tests.test_offline -v
    # or:  pytest tests/test_offline.py
"""
from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import sys
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from . import _bootstrap as B  # noqa: E402

main = B.main
S = B.S
_TMP = B.TMP

from PIL import Image  # noqa: E402

def _img(path, mode="RGB", fmt=None, size=(800, 600)):
    im = Image.new("RGB" if mode == "P" else mode, size, 128)
    if mode == "P":
        im = Image.new("RGB", size, (10, 200, 30)).convert("P")
    im.save(path, format=fmt)
    return path


class TestUtilities(unittest.TestCase):
    def test_serif_bold(self):
        self.assertTrue(main.serif_bold("Global").startswith("𝐆"))

    def test_box_table(self):
        out = main.box_table(["Media", "Status"], [["🎥 Video", "🟢 ON"]])
        self.assertIn("┌", out)
        self.assertIn("└", out)
        self.assertIn("Video", out)

    def test_box_table_ragged_rows(self):
        out = main.box_table(["a", "b", "c"], [["1"], ["1", "2", "3", "4"]])
        self.assertIn("└", out)

    def test_human_size_and_duration(self):
        self.assertEqual(main.human_size(2048), "2.0 KB")
        self.assertEqual(main.human_size(0), "0 B")
        self.assertIn("m", main.human_duration(3700))

    def test_hex(self):
        self.assertEqual(main.hex_to_rgb("#FFF"), (255, 255, 255))
        self.assertEqual(main.hex_to_rgb("00ff00"), (0, 255, 0))
        self.assertEqual(main.normalize_hex("zz"), "#FFFFFF")
        with self.assertRaises(main.WatermarkError):
            main.hex_to_rgb("nope")

    def test_page_spec(self):
        self.assertEqual(main.parse_page_spec("all", 5), [0, 1, 2, 3, 4])
        self.assertEqual(main.parse_page_spec("1,3-4", 5), [0, 2, 3])
        self.assertEqual(main.parse_page_spec("5-1", 5), [0, 1, 2, 3, 4])
        for bad in ("x", "abc", "0", "1-"):
            with self.assertRaises(main.WatermarkError):
                main.parse_page_spec(bad, 5)

    def test_media_kind(self):
        self.assertEqual(main.media_kind_of(".JPG"), "image")
        self.assertEqual(main.media_kind_of(".pdf"), "pdf")
        self.assertEqual(main.media_kind_of(".mkv"), "video")
        self.assertIsNone(main.media_kind_of(".exe"))
        self.assertIsNone(main.media_kind_of(""))


class TestSecurity(unittest.TestCase):
    def test_filename_sanitization(self):
        for nasty in ("../../etc/passwd", "a/b\\c.png", "..", "", "\x00evil.png", "x" * 300):
            name = main.sanitize_filename(nasty)
            self.assertNotIn("/", name)
            self.assertNotIn("\\", name)
            self.assertNotIn("..", name)
            self.assertNotIn("\x00", name)
            self.assertLessEqual(len(name), 90)

    def test_watermark_text_sanitization(self):
        self.assertEqual(main.sanitize_watermark_text("a\x00b\x1bc"), "abc")
        self.assertEqual(len(main.sanitize_watermark_text("x" * 500)), main.MAX_TEXT_LEN)
        self.assertEqual(main.sanitize_watermark_text("​hidden"), "hidden")

    def test_path_traversal_blocked(self):
        base = os.path.realpath(_TMP)
        self.assertTrue(main.safe_join(base, "x.png").startswith(base))
        with self.assertRaises(main.WatermarkError):
            main.safe_join(base, "../../etc/passwd")
        with self.assertRaises(main.WatermarkError):
            main.safe_join(base, "/etc/passwd")

    def test_settings_hardening(self):
        hostile = {
            "font_size": 10 ** 9, "opacity": -50, "position": "../../etc/passwd",
            "mode": "rm -rf /", "font": "Evil", "badge": "'; DROP TABLE users;--",
            "color": "javascript:alert(1)", "animation": "__import__('os').system('id')",
            "custom_x": "99999999999999999999", "pdf_pages": "x" * 500,
            "animation_speed": float("nan"),
        }
        s = main.sanitize_settings(hostile)
        self.assertLessEqual(s["font_size"], 400)
        self.assertGreaterEqual(s["opacity"], 0)
        self.assertIn(s["position"], main.POSITIONS)
        self.assertIn(s["mode"], main.MODES)
        self.assertIn(s["font"], main.FONT_FAMILIES)
        self.assertIn(s["badge"], main.BADGES)
        self.assertIn(s["animation"], main.VIDEO_ANIMATIONS)
        self.assertEqual(s["color"], "#FFFFFF")
        self.assertLessEqual(abs(s["animation_speed"]), 8.0)
        self.assertLessEqual(len(s["pdf_pages"]), 100)

    def test_settings_from_non_dict(self):
        for bad in ("string", None, 42, ["a"]):
            self.assertEqual(main.sanitize_settings(bad)["font_size"], 36)

    def test_rate_limiter(self):
        main.DB.kv_set("rate_per_min", "5")
        main.RATE.pop(999, None)
        for _ in range(5):
            self.assertFalse(main.rate_limited(999))
        self.assertTrue(main.rate_limited(999))
        main.RATE.pop(999, None)
        main.DB.kv_set("rate_per_min", "60")

    def test_admin_authorization(self):
        self.assertTrue(main.is_admin(1))          # CFG.admin_ids from the test config
        self.assertFalse(main.is_admin(999999))
        main.DB.kv_set("extra_admins", "456")
        self.assertTrue(main.is_admin(456))
        main.DB.kv_set("extra_admins", "")
        self.assertFalse(main.is_admin(456))

    def test_log_redaction(self):
        import logging

        record = logging.LogRecord("t", logging.INFO, "f", 1,
                                   "token 123456:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA leaked",
                                   None, None)
        main.REDACTOR.filter(record)
        message = record.getMessage()
        self.assertNotIn("AAAAA", message)
        # either the exact-secret substitution or the token regex must have fired
        self.assertTrue("***TOKEN***" in message or "***REDACTED***" in message, message)

    def test_no_shell_in_subprocess_calls(self):
        """AST-based, so embedded string content cannot create false positives."""
        import ast

        with open(B.MODULE_PATH, encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        offenders = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            for kw in node.keywords:
                if kw.arg == "shell":
                    offenders.append(f"shell= keyword at line {node.lineno}")
            func = node.func
            name = getattr(func, "attr", getattr(func, "id", ""))
            if name in ("system", "popen"):       # os.system / os.popen
                offenders.append(f"{name}() at line {node.lineno}")
        self.assertEqual(offenders, [], "shell execution is prohibited")

    def test_subprocess_calls_use_argument_lists(self):
        import ast

        with open(B.MODULE_PATH, encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        checked = 0
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            name = getattr(func, "attr", getattr(func, "id", ""))
            if name not in ("run", "Popen", "create_subprocess_exec", "check_output",
                            "check_call", "call"):
                continue
            if not node.args:
                continue
            first = node.args[0]
            checked += 1
            # first argument must be a list/tuple literal or a variable, never a
            # single concatenated string command
            if isinstance(first, ast.Constant) and isinstance(first.value, str):
                self.fail(f"line {node.lineno}: subprocess called with a string command")
        self.assertGreaterEqual(checked, 3, "expected several subprocess call sites")

class TestDependencyBootstrap(unittest.TestCase):
    """The first-run installer must never build a shell string."""

    def test_pip_is_invoked_with_an_argument_list(self):
        import types as _types
        from unittest import mock

        captured = {}

        def fake_run(cmd, **kwargs):
            captured["cmd"] = cmd
            captured["kwargs"] = kwargs
            return _types.SimpleNamespace(returncode=0, stdout="", stderr="")

        with mock.patch.object(main.subprocess, "run", fake_run):
            main._pip_install(["Pillow>=10.0", "psutil>=5.9"])
        cmd = captured["cmd"]
        self.assertIsInstance(cmd, list)
        self.assertEqual(cmd[:3], [sys.executable, "-m", "pip"])
        self.assertIn("install", cmd)
        self.assertIn("Pillow>=10.0", cmd)
        self.assertNotIn("shell", captured["kwargs"])
        for arg in cmd:
            self.assertNotIn(";", str(arg))
            self.assertNotIn("&&", str(arg))

    def test_disabled_auto_install_exits_with_instructions(self):
        from unittest import mock

        with mock.patch.object(main, "_missing_requirements",
                               return_value=[("nope", "nope-pkg>=1", "desc")]):
            with self.assertRaises(SystemExit):
                main.ensure_dependencies(auto_install=False)

    def test_present_dependencies_are_a_noop(self):
        main.ensure_dependencies(auto_install=False)   # everything is installed here

    def test_environment_check_reports_successfully(self):
        import contextlib
        import io as _io

        buf = _io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = main.run_check()
        out = buf.getvalue()
        self.assertEqual(code, 0, out[-800:])
        for label in ("Python", "Dependencies", "FFmpeg", "BOT_TOKEN", "Database"):
            self.assertIn(label, out)


class TestNoHardcodedSecrets(unittest.TestCase):
    """The old file shipped a real bot token / api hash as defaults."""

    # SHA-256 of the credentials that the original file shipped as defaults.
    # Only the digests are stored, so the secrets themselves never re-enter
    # version control through the test suite.
    # SHA-256 digests of the credentials the original file shipped as defaults.
    # Only digests are stored, so the secrets never re-enter version control
    # through the test suite.
    LEAKED_CREDENTIAL_SHA256 = {
        "ac91a271d02841e04a3ca9c43009a97eb0d4d5392a0ab9406f4c8dafa58a99cc",  # bot token
        "6fbfaa5fe0d5f70ca14092c556b47fea3103128bdc32db0c19473b7e112ffa89",  # api_hash
    }

    def test_leaked_credentials_are_gone(self):
        """The original file shipped these as defaults; they must not return."""
        import hashlib

        known = self.LEAKED_CREDENTIAL_SHA256
        for path in (B.MODULE_PATH,
                     os.path.join(ROOT, "README.md"),
                     os.path.join(ROOT, "requirements.txt"),
                     os.path.join(HERE, "test_offline.py"),
                     os.path.join(HERE, "test_integration.py"),
                     os.path.join(HERE, "_bootstrap.py")):
            with open(path, encoding="utf-8") as fh:
                content = fh.read()
            found = main._TOKEN_RE.findall(content) + main._HASH_RE.findall(content)
            for literal in found:
                digest = hashlib.sha256(literal.encode()).hexdigest()
                self.assertNotIn(digest, known, f"{path}: leaked credential present")

    def test_no_secret_defaults_in_config(self):
        with open(B.MODULE_PATH, encoding="utf-8") as fh:
            source = fh.read()
        # BOT_TOKEN / api-hash defaults must be empty strings, never literals
        self.assertIn('os.getenv("BOT_TOKEN", "").strip()', source)
        self.assertIn('os.getenv("TELEGRAM_API_HASH", "").strip()', source)
        self.assertNotIn("os.getenv(\"ADMIN_IDS\", \"5", source)

    def test_config_requires_env(self):
        saved = os.environ.pop("BOT_TOKEN", None)
        try:
            with self.assertRaises(SystemExit):
                main.Config.from_env()
        finally:
            if saved:
                os.environ["BOT_TOKEN"] = saved

    def test_config_rejects_bad_token_shape(self):
        saved = os.environ.get("BOT_TOKEN")
        os.environ["BOT_TOKEN"] = "not-a-token"
        try:
            with self.assertRaises(SystemExit):
                main.Config.from_env()
        finally:
            if saved:
                os.environ["BOT_TOKEN"] = saved
            else:
                os.environ.pop("BOT_TOKEN", None)


class TestDatabase(unittest.TestCase):
    def test_settings_roundtrip_and_inheritance(self):
        s = main.DB.get_settings(1, "image")
        s["font_size"] = 50
        main.DB.save_settings(1, "image", s)
        self.assertEqual(main.DB.get_settings(1, "image")["font_size"], 50)
        main.DB.reset_settings(1, "image")
        self.assertEqual(main.DB.get_settings(1, "image")["font_size"], 36)
        # a fresh category inherits the user's global defaults
        main.DB.save_settings(2, "global", S(text="GLOBAL", font_size=44))
        self.assertEqual(main.DB.get_settings(2, "pdf")["text"], "GLOBAL")

    def test_corrupt_json_is_repaired(self):
        main.DB.execute("UPDATE settings SET data='{not json' WHERE user_id=1 "
                        "AND media='video'")
        self.assertEqual(main.DB.get_settings(1, "video")["font_size"], 36)

    def test_stats_errors_blocking(self):
        before = main.DB.totals()["images"]
        main.DB.bump_stat(1, "image")
        self.assertEqual(main.DB.totals()["images"], before + 1)
        main.DB.log_error(1, "unit", "boom")
        self.assertEqual(main.DB.recent_errors(1)[0]["message"], "boom")
        main.DB.set_blocked(4242, True)
        self.assertTrue(main.DB.is_blocked(4242))
        self.assertNotIn(4242, main.DB.all_user_ids())
        main.DB.set_blocked(4242, False)
        self.assertFalse(main.DB.is_blocked(4242))

    def test_unknown_media_rejected(self):
        with self.assertRaises(ValueError):
            main.DB.save_settings(1, "../../evil", {})


class TestImageEngine(unittest.TestCase):
    def test_jpeg_rgb(self):
        src = _img(os.path.join(_TMP, "a.jpg"), "RGB", "JPEG")
        dst = os.path.join(_TMP, "a_out.jpg")
        main.process_image_file(src, dst, S(), 1)
        with Image.open(dst) as im:
            self.assertEqual(im.format, "JPEG")
            self.assertEqual(im.size, (800, 600))

    def test_watermark_is_visible(self):
        src = _img(os.path.join(_TMP, "v.png"), "RGB")
        dst = os.path.join(_TMP, "v_out.png")
        main.process_image_file(src, dst, S(), 1)
        diff = main._diff_pixels(Image.open(src).convert("RGB"),
                                 Image.open(dst).convert("RGB"))
        self.assertGreater(diff, 500, f"watermark invisible ({diff} px)")

    def test_all_modes_formats(self):
        for mode, ext, kw in (("RGBA", ".png", {"tiled": True}),
                              ("L", ".png", {"rotation": 45, "badge": "box"}),
                              ("P", ".png", {"italic": True}),
                              ("RGB", ".webp", {"position": "custom",
                                                "custom_x": 5, "custom_y": 5}),
                              ("RGB", ".png", {"mode": "both", "logo_tiled": True})):
            with self.subTest(mode=mode, ext=ext):
                src = _img(os.path.join(_TMP, f"m{mode}{ext}"), mode, None, (400, 300))
                dst = os.path.join(_TMP, f"m{mode}_out{ext}")
                main.process_image_file(src, dst, S(**kw), 1)
                self.assertGreater(os.path.getsize(dst), 0)

    def test_logo_watermark(self):
        Image.new("RGBA", (100, 60), (255, 0, 0, 200)).save(
            main.logo_file_for(1, "image"), "PNG")
        src = _img(os.path.join(_TMP, "l.png"), "RGB")
        dst = os.path.join(_TMP, "l_out.png")
        main.process_image_file(src, dst, S(mode="logo"), 1)
        self.assertGreater(os.path.getsize(dst), 0)

    def test_corrupt_image_rejected(self):
        bad = os.path.join(_TMP, "bad.png")
        with open(bad, "wb") as fh:
            fh.write(b"this is definitely not an image")
        with self.assertRaises(main.WatermarkError):
            main.process_image_file(bad, os.path.join(_TMP, "bad_out.png"), S(), 1)

    def test_oversized_image_rejected(self):
        src = _img(os.path.join(_TMP, "huge.png"), "RGB", None, (200, 200))
        main.CFG.max_image_pixels = 1000  # anything bigger must be refused
        try:
            with self.assertRaises(main.WatermarkError):
                main.process_image_file(src, os.path.join(_TMP, "huge_out.png"), S(), 1)
        finally:
            main.CFG.max_image_pixels = 178_956_970

    def test_layer_builder(self):
        layer = main.build_watermark_layer((640, 480), S(stroke=True, shadow=True),
                                           None, 1.0)
        self.assertEqual(layer.mode, "RGBA")
        self.assertIsNotNone(layer.getbbox())


class TestPdfEngine(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fitz = main.fitz
        if cls.fitz is None:
            raise unittest.SkipTest("PyMuPDF not installed")

    def _make(self, path, pages=2, password=None):
        doc = self.fitz.open()
        for i in range(pages):
            page = doc.new_page()
            page.insert_text((72, 72), f"page {i + 1}")
        if password:
            doc.save(path, encryption=self.fitz.PDF_ENCRYPT_AES_256,
                     user_pw=password, owner_pw=password)
        else:
            doc.save(path)
        doc.close()
        return path

    def test_all_pages(self):
        src = self._make(os.path.join(_TMP, "d.pdf"))
        dst = os.path.join(_TMP, "d_out.pdf")
        self.assertEqual(main.process_pdf_file(src, dst, S(), 1), 2)
        doc = self.fitz.open(dst)
        self.assertEqual(doc.page_count, 2)
        self.assertTrue(all(len(p.get_images()) >= 1 for p in doc))
        doc.close()

    def test_page_range(self):
        src = self._make(os.path.join(_TMP, "e.pdf"), pages=3)
        dst = os.path.join(_TMP, "e_out.pdf")
        main.process_pdf_file(src, dst, S(pdf_pages="2"), 1)
        self.assertGreater(os.path.getsize(dst), 0)

    def test_encrypted_rejected(self):
        src = self._make(os.path.join(_TMP, "enc.pdf"), password="secret")
        with self.assertRaises(main.WatermarkError):
            main.process_pdf_file(src, os.path.join(_TMP, "enc_out.pdf"), S(), 1)

    def test_corrupt_rejected(self):
        bad = os.path.join(_TMP, "bad.pdf")
        with open(bad, "wb") as fh:
            fh.write(b"%PDF-garbage")
        with self.assertRaises(main.WatermarkError):
            main.process_pdf_file(bad, os.path.join(_TMP, "bad_out.pdf"), S(), 1)

    def test_page_cap_enforced(self):
        src = self._make(os.path.join(_TMP, "big.pdf"), pages=3)
        main.CFG.max_pdf_pages = 2
        try:
            with self.assertRaises(main.WatermarkError):
                main.process_pdf_file(src, os.path.join(_TMP, "big_out.pdf"), S(), 1)
        finally:
            main.CFG.max_pdf_pages = 400

    def test_progress_callback_runs(self):
        src = self._make(os.path.join(_TMP, "p.pdf"), pages=2)
        seen = []
        main.process_pdf_file(src, os.path.join(_TMP, "p_out.pdf"), S(), 1,
                              lambda done, total: seen.append((done, total)))
        self.assertTrue(seen)


class TestVideoEngine(unittest.TestCase):
    ffmpeg = None

    @classmethod
    def setUpClass(cls):
        cls.ffmpeg = main.find_ffmpeg()
        if not cls.ffmpeg:
            raise unittest.SkipTest("FFmpeg not installed")
        cls.src = os.path.join(_TMP, "v.mp4")
        subprocess.run([cls.ffmpeg, "-y", "-nostdin", "-f", "lavfi", "-i",
                        "testsrc=duration=2:size=320x240:rate=15",
                        "-c:v", "libx264", "-pix_fmt", "yuv420p", cls.src],
                       check=True, capture_output=True)

    def _run(self, name, settings, dst):
        seen = []

        async def prog(pct):
            seen.append(pct)

        asyncio.run(main.process_video_file(self.src, dst, settings, 1,
                                            self.ffmpeg, prog))
        return seen

    def test_basic_overlay_and_progress(self):
        dst = os.path.join(_TMP, "v_out.mp4")
        seen = self._run("none", S(), dst)
        self.assertGreater(os.path.getsize(dst), 0)
        self.assertTrue(seen, "no progress callbacks fired")

    def test_frame_differs(self):
        dst = os.path.join(_TMP, "v_diff.mp4")
        self._run("none", S(), dst)

        def frame(video, out):
            subprocess.run([self.ffmpeg, "-y", "-nostdin", "-i", video, "-frames:v",
                            "1", "-vf", "select=eq(n\\,8)", out],
                           check=True, capture_output=True)

        fa = os.path.join(_TMP, "fa.png")
        fb = os.path.join(_TMP, "fb.png")
        frame(self.src, fa)
        frame(dst, fb)
        diff = main._diff_pixels(Image.open(fa).convert("RGB"),
                                 Image.open(fb).convert("RGB"))
        self.assertGreater(diff, 200, f"video watermark invisible ({diff} px)")

    def test_every_animation_preset_encodes(self):
        broken = []
        for name in main.VIDEO_ANIMATIONS:
            dst = os.path.join(_TMP, f"anim_{name}.mp4")
            try:
                asyncio.run(main.process_video_file(self.src, dst,
                                                    S(animation=name,
                                                      animation_speed=2.0),
                                                    1, self.ffmpeg))
                if os.path.getsize(dst) == 0:
                    broken.append(f"{name}: empty output")
            except Exception as exc:  # noqa: BLE001
                broken.append(f"{name}: {type(exc).__name__}: {str(exc)[:90]}")
            finally:
                if os.path.exists(dst):
                    os.remove(dst)
        self.assertEqual(broken, [], "broken presets: " + " | ".join(broken))

    def test_logo_and_tiling(self):
        Image.new("RGBA", (60, 40), (0, 255, 0, 180)).save(
            main.logo_file_for(1, "video"), "PNG")
        dst = os.path.join(_TMP, "v_logo.mp4")
        self._run("none", S(mode="both", tiled=True), dst)
        self.assertGreater(os.path.getsize(dst), 0)

    def test_corrupt_video_rejected(self):
        bad = os.path.join(_TMP, "bad.mp4")
        with open(bad, "wb") as fh:
            fh.write(b"not a video")
        with self.assertRaises(main.WatermarkError):
            asyncio.run(main.process_video_file(bad, os.path.join(_TMP, "bo.mp4"),
                                                S(), 1, self.ffmpeg))

    def test_filter_chains_are_wellformed(self):
        for name in main.VIDEO_ANIMATIONS:
            with self.subTest(animation=name):
                chain = main.animation_filter(name, 1.4)
                self.assertIn("[vout]", chain)
                self.assertIn("[base]", chain)
                self.assertEqual(chain.count("["), chain.count("]"))


class TestUi(unittest.TestCase):
    def test_main_menu_labels(self):
        labels = [b.text for row in main.main_menu_kb().inline_keyboard for b in row]
        for want in ("➕ Add Watermark", "⚙️ Settings", "🖼️ Process Image",
                     "📄 Process PDF", "🎥 Process Video", "⚡ Batch",
                     "📊 My Settings", "📡 Status", "❓ Help", "ℹ️ About",
                     "👨‍💻 Contact Admin for VIP Plan", "🏠 Back to Start"):
            self.assertIn(want, labels)

    def test_hub_and_category_labels(self):
        hub = [b.text for row in main.settings_hub_kb().inline_keyboard for b in row]
        for want in ("🎥 Video", "🖼️ Image", "📄 PDF", "🌐 Global Defaults",
                     "🏠 Back to Start"):
            self.assertIn(want, hub)
        cat = [b.text for row in main.category_kb("global", S()).inline_keyboard
               for b in row]
        for want in ("🔴 Turn OFF", "✏️ Text", "🔤 Font", "✨ Style", "📏 Size",
                     "🎨 Color", "💧 Opacity", "📍 Position", "🧊 Badge & Effects",
                     "⚙️ Stroke & Shadow", "✍️ Mode: Text", "🖼️ Logo",
                     "🔄 Reset to Default", "⬅️ Back", "🏠 Back to Start"):
            self.assertIn(want, cat)

    def test_video_and_pdf_specific_buttons(self):
        vcat = [b.text for row in main.category_kb("video", S()).inline_keyboard
                for b in row]
        self.assertTrue(any("🎬 Animation" in t for t in vcat))
        pcat = [b.text for row in main.category_kb("pdf", S()).inline_keyboard
                for b in row]
        self.assertTrue(any("📄 Pages" in t for t in pcat))

    def test_screen_texts(self):
        self.assertIn(main.serif_bold("Global Default Settings"),
                      main.category_text("global", S()))
        self.assertIn(main.serif_bold("My Watermark Configuration"),
                      main.my_settings_text(1))
        self.assertIn("Uptime", main.status_text(1))
        self.assertIn(main.serif_bold("Admin Panel"), main._admin_stats_text())
        self.assertIn(main.serif_bold("Help & Guide"), main.help_text())
        self.assertIn(main.serif_bold("About Viraj Watermark"),
                      main.about_text())

    def test_reply_keyboard_present(self):
        mk = main.menu_reply_markup()
        self.assertIsNotNone(mk)
        self.assertEqual(mk.keyboard[0][0].text, "☰ Menu")


class TestTempAndState(unittest.TestCase):
    def test_cleanup_removes_old_files_only(self):
        d = os.path.join(main.CFG.temp_directory, "7")
        os.makedirs(d, exist_ok=True)
        old, new = os.path.join(d, "old.txt"), os.path.join(d, "new.txt")
        for p in (old, new):
            with open(p, "w") as fh:
                fh.write("x")
        os.utime(old, (time.time() - 7200,) * 2)
        self.assertGreaterEqual(main.clean_temp_dir(3600), 1)
        self.assertFalse(os.path.exists(old))
        self.assertTrue(os.path.exists(new))
        main.clean_temp_dir(0)
        self.assertFalse(os.path.exists(new))

    def test_state_ttl(self):
        main.set_state(555, "auto")
        self.assertIsNotNone(main.get_state(555))
        main.clear_state(555)
        self.assertIsNone(main.get_state(555))
        main.set_state(556, "auto")
        main.USER_STATE[556]["ts"] = time.time() - main.CFG.state_ttl - 5
        self.assertIsNone(main.get_state(556))
        self.assertGreaterEqual(main.sweep_states(), 0)

    def test_effective_limits(self):
        main.CFG.local_api_base_url = ""
        self.assertEqual(main.effective_download_limit(),
                         min(main.CFG.max_file_size, main.STANDARD_API_DOWNLOAD_LIMIT))
        self.assertEqual(main.effective_upload_limit(),
                         min(main.CFG.upload_limit, main.STANDARD_API_UPLOAD_LIMIT))
        main.CFG.local_api_base_url = "http://127.0.0.1:8081/bot"
        self.assertEqual(main.effective_download_limit(), main.CFG.max_file_size)
        main.CFG.local_api_base_url = ""




if __name__ == "__main__":
    unittest.main(verbosity=2)
''',
    'tests/test_integration.py': r'''#!/usr/bin/env python3
"""Integration tests: the Telegram-facing layer, driven with mocked transports.

Covers application bootstrap, the full callback router, the message/state
router, the single-file pipeline (`process_and_send`) and the batch pipeline
(`run_batch`) end to end, including temp-file cleanup.

    python -m unittest tests.test_integration -v
    # or:  pytest tests/test_integration.py
"""
from __future__ import annotations

import asyncio
import os
import shutil
import sys
import unittest
from unittest.mock import AsyncMock, MagicMock

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from . import _bootstrap as B  # noqa: E402

main = B.main
S = B.S
_TMP = B.TMP
USER = B.USER
ADMIN = B.ADMIN

from PIL import Image  # noqa: E402



# --------------------------------------------------------------------------
# Telegram fakes
# --------------------------------------------------------------------------
class FakeUser:
    def __init__(self, uid, username="user"):
        self.id = uid
        self.username = username
        self.first_name = "First"


class FakeChat:
    def __init__(self, cid=1):
        self.id = cid


class FakeQuery:
    """Records every screen update and answer the bot produces."""

    def __init__(self, data):
        self.data = data
        self.message = None           # forces edit_message_text()
        self.answers = []
        self.texts = []
        self.markups = []

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))

    async def edit_message_text(self, text=None, **kwargs):
        self.texts.append(text or "")
        self.markups.append(kwargs.get("reply_markup"))

    async def edit_message_caption(self, caption=None, **kwargs):
        self.texts.append(caption or "")
        self.markups.append(kwargs.get("reply_markup"))

    @property
    def last_text(self):
        return self.texts[-1] if self.texts else ""


class FakeMessage:
    def __init__(self, text=None, **kwargs):
        self.text = text
        self.caption = None
        self.photo = kwargs.get("photo")
        self.video = kwargs.get("video")
        self.document = kwargs.get("document")
        self.chat = FakeChat()
        self.message_id = 1
        self.replies = []
        self.reply_text = AsyncMock(side_effect=self._reply)
        self.reply_photo = AsyncMock()
        self.reply_document = AsyncMock()
        self.reply_video = AsyncMock()

    async def _reply(self, text=None, **kwargs):
        self.replies.append((text, kwargs))
        status = FakeStatus()
        return status

    @property
    def last_reply(self):
        return self.replies[-1][0] if self.replies else ""


class FakeStatus:
    def __init__(self):
        self.texts = []
        self.deleted = False
        self.edit_text = AsyncMock(side_effect=self._edit)
        self.delete = AsyncMock(side_effect=self._delete)

    async def _edit(self, text=None, **kwargs):
        self.texts.append(text or "")

    async def _delete(self):
        self.deleted = True


class FakeFile:
    """Telegram File stub that materialises a real local file on download."""

    def __init__(self, src, size=None):
        self._src = src
        self.file_size = size if size is not None else os.path.getsize(src)

    async def download_to_drive(self, path):
        shutil.copyfile(self._src, path)


class FakeUpdate:
    def __init__(self, uid=USER, query_data=None, text=None, **kwargs):
        self.effective_user = FakeUser(uid)
        self.effective_chat = FakeChat()
        self.callback_query = FakeQuery(query_data) if query_data else None
        self.message = FakeMessage(text, **kwargs) if (text or kwargs) else None


class FakeBot:
    def __init__(self, file_srcs=None):
        self.sent = []
        self.actions = []
        self._file_srcs = file_srcs or {}
        self.get_file = AsyncMock(side_effect=self._get_file)
        self.send_photo = AsyncMock(side_effect=self._send("photo"))
        self.send_document = AsyncMock(side_effect=self._send("document"))
        self.send_video = AsyncMock(side_effect=self._send("video"))
        self.send_chat_action = AsyncMock(side_effect=self._action)
        self.send_message = AsyncMock(side_effect=self._send_message)

    async def _get_file(self, file_id):
        return FakeFile(self._file_srcs.get(file_id, self._file_srcs.get("_default")))

    def _send(self, kind):
        async def _inner(*args, **kwargs):
            self.sent.append((kind, args, kwargs))
        return _inner

    async def _action(self, *args, **kwargs):
        self.actions.append(args)

    async def _send_message(self, *args, **kwargs):
        self.sent.append(("message", args, kwargs))
        return FakeStatus()

    @property
    def uploads(self):
        return [s for s in self.sent if s[0] in ("photo", "document", "video")]


class FakeContext:
    def __init__(self, bot):
        self.bot = bot
        self.args = []


def run(coro):
    return asyncio.run(coro)


async def press(uid, data, bot=None):
    """Simulate an inline-button press and return (query, context)."""
    update = FakeUpdate(uid=uid, query_data=data)
    context = FakeContext(bot or FakeBot())
    await main.on_callback(update, context)
    return update.callback_query, context


async def say(uid, text, bot=None, **kwargs):
    """Simulate an incoming message and return (update, context)."""
    update = FakeUpdate(uid=uid, text=text, **kwargs)
    context = FakeContext(bot or FakeBot())
    await main.on_message(update, context)
    return update, context


# --------------------------------------------------------------------------
class TestApplicationBootstrap(unittest.TestCase):
    def test_application_builds_with_all_commands(self):
        app = main.build_application()
        commands = set()
        handler_types = set()
        for handlers in app.handlers.values():
            for handler in handlers:
                handler_types.add(type(handler).__name__)
                if isinstance(handler, main.CommandHandler):
                    commands.update(handler.commands)
        for expected in ("start", "menu", "help", "about", "settings", "mysettings",
                         "status", "id", "cancel", "allow", "block", "unblock",
                         "admin", "stats", "broadcast", "cleanup"):
            self.assertIn(expected, commands)
        self.assertIn("CallbackQueryHandler", handler_types)
        self.assertIn("MessageHandler", handler_types)
        self.assertIsNotNone(app.job_queue, "job queue missing — cleanup job inactive")

    def test_post_init_registers_botfather_commands(self):
        bot = FakeBot()
        bot.set_my_commands = AsyncMock()
        app = MagicMock()
        app.bot = bot
        run(main.post_init(app))
        bot.set_my_commands.assert_awaited_once()


class TestCallbackRouter(unittest.TestCase):
    def setUp(self):
        main.USER_STATE.clear()
        main.RATE.clear()
        main.DB.reset_settings(USER, "video")
        main.DB.reset_settings(USER, "image")
        main.DB.reset_settings(USER, "pdf")

    def test_main_menu_navigation(self):
        q, _ = run(press(USER, "nav:main"))
        self.assertIn(main.serif_bold("Viraj Watermark"), q.last_text)

    def test_settings_hub_and_category(self):
        q, _ = run(press(USER, "nav:hub"))
        self.assertIn(main.serif_bold("Watermark Settings Hub"), q.last_text)
        q, _ = run(press(USER, "cat:video"))
        self.assertIn(main.serif_bold("Video Watermark Settings"), q.last_text)

    def test_status_and_help_and_about(self):
        q, _ = run(press(USER, "nav:status"))
        self.assertIn("Uptime", q.last_text)
        q, _ = run(press(USER, "nav:help"))
        self.assertIn(main.serif_bold("Help & Guide"), q.last_text)
        q, _ = run(press(USER, "nav:about"))
        self.assertIn(main.serif_bold("About Viraj Watermark"), q.last_text)

    def test_add_watermark_sets_state(self):
        q, _ = run(press(USER, "nav:add"))
        self.assertIn("Add Watermark", q.last_text)
        self.assertEqual(main.get_state(USER)["kind"], "auto")
        q, _ = run(press(USER, "nav:cancel"))
        self.assertIsNone(main.get_state(USER))

    def test_toggle_reset_and_mode_cycle(self):
        run(press(USER, "cat:video"))
        run(press(USER, "act:video:toggle"))
        self.assertFalse(main.DB.get_settings(USER, "video")["enabled"])
        run(press(USER, "act:video:toggle"))
        self.assertTrue(main.DB.get_settings(USER, "video")["enabled"])

        run(press(USER, "sz:video:96"))
        self.assertEqual(main.DB.get_settings(USER, "video")["font_size"], 96)
        run(press(USER, "act:video:reset"))
        self.assertEqual(main.DB.get_settings(USER, "video")["font_size"], 36)

        modes = []
        for _ in range(3):
            run(press(USER, "act:video:mode"))
            modes.append(main.DB.get_settings(USER, "video")["mode"])
        self.assertEqual(modes, ["logo", "both", "text"])

    def test_numeric_setters_are_clamped_and_validated(self):
        run(press(USER, "sz:video:+"))
        self.assertEqual(main.DB.get_settings(USER, "video")["font_size"], 40)
        q, _ = run(press(USER, "sz:video:999999"))
        self.assertEqual(main.DB.get_settings(USER, "video")["font_size"], 400)
        q, _ = run(press(USER, "sz:video:not_a_number"))
        self.assertTrue(any("Invalid size" in str(a[0]) for a in q.answers))

        run(press(USER, "o:video:opacity:+"))
        self.assertEqual(main.DB.get_settings(USER, "video")["opacity"], 80)
        run(press(USER, "o:video:opacity:25"))
        self.assertEqual(main.DB.get_settings(USER, "video")["opacity"], 25)
        run(press(USER, "o:video:bogus:50"))
        self.assertEqual(main.DB.get_settings(USER, "video")["opacity"], 25)

    def test_style_color_position_badge_stroke_logo(self):
        run(press(USER, "f:video:Mono"))
        self.assertEqual(main.DB.get_settings(USER, "video")["font"], "Mono")
        run(press(USER, "f:video:__hack__"))
        self.assertEqual(main.DB.get_settings(USER, "video")["font"], "Mono")

        run(press(USER, "st:video:bold"))
        self.assertFalse(main.DB.get_settings(USER, "video")["bold"])
        run(press(USER, "st:video:italic"))
        self.assertTrue(main.DB.get_settings(USER, "video")["italic"])
        run(press(USER, "st:video:rot90"))
        self.assertEqual(main.DB.get_settings(USER, "video")["rotation"], 90)

        run(press(USER, "c:video:FF0000"))
        self.assertEqual(main.DB.get_settings(USER, "video")["color"], "#FF0000")
        q, _ = run(press(USER, "c:video:ZZZZZZ"))
        self.assertTrue(any("Bad color" in str(a[0]) for a in q.answers))

        run(press(USER, "p:video:top_left"))
        self.assertEqual(main.DB.get_settings(USER, "video")["position"], "top_left")
        run(press(USER, "p:video:m+"))
        self.assertEqual(main.DB.get_settings(USER, "video")["margin"], 25)

        run(press(USER, "b:video:box"))
        self.assertEqual(main.DB.get_settings(USER, "video")["badge"], "box")
        run(press(USER, "b:video:tile"))
        self.assertTrue(main.DB.get_settings(USER, "video")["tiled"])
        run(press(USER, "b:video:sp+"))
        self.assertEqual(main.DB.get_settings(USER, "video")["tile_spacing"], 70)

        run(press(USER, "k:video:w+"))
        self.assertEqual(main.DB.get_settings(USER, "video")["stroke_width"], 3)
        run(press(USER, "k:video:shadow"))
        self.assertFalse(main.DB.get_settings(USER, "video")["shadow"])

        run(press(USER, "lg:video:s+"))
        self.assertEqual(main.DB.get_settings(USER, "video")["logo_scale"], 35)
        run(press(USER, "lg:video:o-"))
        self.assertEqual(main.DB.get_settings(USER, "video")["logo_opacity"], 70)

    def test_animation_controls_are_video_only(self):
        run(press(USER, "an:video:pulse"))
        self.assertEqual(main.DB.get_settings(USER, "video")["animation"], "pulse")
        run(press(USER, "an:video:__nope__"))
        self.assertEqual(main.DB.get_settings(USER, "video")["animation"], "pulse")
        run(press(USER, "as:video:+"))
        self.assertAlmostEqual(main.DB.get_settings(USER, "video")["animation_speed"], 1.1)
        q, _ = run(press(USER, "an:image:pulse"))
        self.assertTrue(any("videos only" in str(a[0]) for a in q.answers))

    def test_pdf_pages_button(self):
        q, _ = run(press(USER, "act:pdf:pdfpages"))
        self.assertEqual(main.get_state(USER)["kind"], "set_pdfpages")
        self.assertIn("Pages", q.last_text)

    def test_unknown_or_malformed_callback_is_safe(self):
        for data in ("???", "nav", "cat", "act:video", "o:video", "sz",
                     "unknown:action", "cat:../../etc", "act:../../evil:text",
                     "lim:batch:+", "a:b:c:d:e"):
            q, _ = run(press(USER, data))   # must never raise
            self.assertIsNotNone(q)
            self.assertEqual(len(q.answers), 1, f"{data}: query not answered")
        # a missing/empty callback query must be a no-op, not a crash
        update = FakeUpdate(uid=USER)
        update.callback_query = None
        run(main.on_callback(update, FakeContext(FakeBot())))

    def test_admin_panel_is_access_controlled(self):
        q, _ = run(press(USER, "adm:stats"))
        self.assertTrue(any("Admin only" in str(a[0]) for a in q.answers))
        q, _ = run(press(ADMIN, "adm:stats"))
        self.assertIn(main.serif_bold("Admin Panel"), q.last_text)

        q, _ = run(press(USER, "lim:batch:+"))
        self.assertTrue(any("Admin only" in str(a[0]) for a in q.answers))
        before = main.limit_max_batch()
        run(press(ADMIN, "lim:batch:+"))
        self.assertEqual(main.limit_max_batch(), before + 1)
        run(press(ADMIN, "lim:batch:-"))
        self.assertEqual(main.limit_max_batch(), before)

        q, _ = run(press(ADMIN, "adm:errors"))
        self.assertIn("Recent Errors", q.last_text)

    def test_callback_is_answered_exactly_once(self):
        q, _ = run(press(USER, "cat:image"))
        self.assertEqual(len(q.answers), 1)


class TestMessageRouter(unittest.TestCase):
    def setUp(self):
        main.USER_STATE.clear()
        main.RATE.clear()
        main.DB.reset_settings(USER, "image")

    def test_menu_button_and_unknown_text(self):
        update, _ = run(say(USER, "☰ Menu"))
        self.assertIn(main.serif_bold("Viraj Watermark"), update.message.last_reply)
        update, _ = run(say(USER, "random chatter"))
        self.assertIn("didn't understand", update.message.last_reply)

    def test_text_prompt_flow(self):
        main.set_state(USER, "set_text", media="image")
        update, _ = run(say(USER, "  My Brand  "))
        self.assertEqual(main.DB.get_settings(USER, "image")["text"], "My Brand")
        self.assertIsNone(main.get_state(USER))

        main.set_state(USER, "set_text", media="image")
        update, _ = run(say(USER, "   "))
        self.assertIn("Invalid input", update.message.last_reply)
        self.assertIsNotNone(main.get_state(USER))

    def test_colour_prompt_flow(self):
        main.set_state(USER, "set_color", media="image")
        run(say(USER, "#00ff00"))
        self.assertEqual(main.DB.get_settings(USER, "image")["color"], "#00FF00")
        main.set_state(USER, "set_color", media="image")
        update, _ = run(say(USER, "not-a-colour"))
        self.assertIn("Invalid input", update.message.last_reply)

    def test_custom_coords_prompt_flow(self):
        main.set_state(USER, "set_posc", media="image")
        run(say(USER, "30,40"))
        s = main.DB.get_settings(USER, "image")
        self.assertEqual((s["position"], s["custom_x"], s["custom_y"]),
                         ("custom", 30, 40))
        main.set_state(USER, "set_posc", media="image")
        update, _ = run(say(USER, "30; drop table"))
        self.assertIn("Invalid input", update.message.last_reply)

    def test_rotation_and_pages_prompt_flow(self):
        main.set_state(USER, "set_rotc", media="image")
        run(say(USER, "45"))
        self.assertEqual(main.DB.get_settings(USER, "image")["rotation"], 45)
        main.set_state(USER, "set_rotc", media="image")
        update, _ = run(say(USER, "9999"))
        self.assertIn("Invalid input", update.message.last_reply)

        main.set_state(USER, "set_pdfpages", media="pdf")
        run(say(USER, "1,3-5"))
        self.assertEqual(main.DB.get_settings(USER, "pdf")["pdf_pages"], "1,3-5")
        main.set_state(USER, "set_pdfpages", media="pdf")
        update, _ = run(say(USER, "rm -rf /"))
        self.assertIn("Invalid input", update.message.last_reply)

    def test_blocked_user_is_denied(self):
        main.DB.set_blocked(USER, True)
        try:
            update, _ = run(say(USER, "hello"))
            self.assertIn("blocked", update.message.last_reply)
        finally:
            main.DB.set_blocked(USER, False)

    def test_logo_upload_requires_an_image(self):
        main.set_state(USER, "logo", media="image")
        update, _ = run(say(USER, "here is my logo"))
        self.assertIn("image", update.message.last_reply)


class TestSingleFilePipeline(unittest.TestCase):
    def setUp(self):
        main.USER_STATE.clear()
        main.RATE.clear()
        main.DB.save_settings(USER, "image", S(text="PIPELINE"))
        self.src = os.path.join(_TMP, "pipe_src.png")
        Image.new("RGB", (600, 400), (20, 40, 90)).save(self.src)
        main.JOB_SEMAPHORE = None

    def _pending(self, ext=".png", size=None):
        path = os.path.join(main.user_temp(USER), main.sanitize_filename("p" + ext))
        shutil.copyfile(self.src, path)
        return path

    def test_image_is_processed_sent_and_cleaned_up(self):
        path = self._pending()
        out = os.path.join(main.user_temp(USER), "out_" + os.path.basename(path))
        bot = FakeBot()
        update = FakeUpdate(uid=USER, text=None)
        update.message = FakeMessage()
        awaitable = main.process_and_send(update, FakeContext(bot), path, "image")
        run(awaitable)
        self.assertEqual(len(bot.uploads), 1)
        kind, args, kwargs = bot.uploads[0]
        self.assertEqual(kind, "photo")
        self.assertIn("ready", (kwargs.get("caption") or "").lower())
        self.assertFalse(os.path.exists(path), "input temp file leaked")
        self.assertFalse(os.path.exists(out), "output temp file leaked")

    def test_disabled_category_explains_itself(self):
        s = main.DB.get_settings(USER, "image")
        s["enabled"] = False
        main.DB.save_settings(USER, "image", s)
        path = self._pending()
        bot = FakeBot()
        update = FakeUpdate(uid=USER)
        update.message = FakeMessage()
        run(main.process_and_send(update, FakeContext(bot), path, "image"))
        self.assertEqual(bot.uploads, [])
        self.assertIn("turned OFF", update.message.last_reply)
        main.DB.save_settings(USER, "image", S(text="PIPELINE"))

    def test_corrupt_file_reports_a_safe_error(self):
        path = os.path.join(main.user_temp(USER), main.sanitize_filename("bad.png"))
        with open(path, "wb") as fh:
            fh.write(b"garbage bytes")
        bot = FakeBot()
        update = FakeUpdate(uid=USER)
        update.message = FakeMessage()
        run(main.process_and_send(update, FakeContext(bot), path, "image"))
        self.assertEqual(bot.uploads, [])
        # the status message must never leak a Python traceback
        self.assertNotIn("Traceback", "\n".join(update.message.replies[0][0] if
                                                update.message.replies else ""))

    def test_pdf_pipeline(self):
        pdf = os.path.join(_TMP, "pipe.pdf")
        doc = main.fitz.open()
        doc.new_page()
        doc.save(pdf)
        doc.close()
        path = os.path.join(main.user_temp(USER), main.sanitize_filename("p.pdf"))
        shutil.copyfile(pdf, path)
        bot = FakeBot()
        update = FakeUpdate(uid=USER)
        update.message = FakeMessage()
        run(main.process_and_send(update, FakeContext(bot), path, "pdf"))
        self.assertEqual(len(bot.uploads), 1)
        self.assertEqual(bot.uploads[0][0], "document")
        self.assertFalse(os.path.exists(path))

    def test_video_pipeline_with_ffmpeg(self):
        ffmpeg = main.find_ffmpeg()
        if not ffmpeg:
            self.skipTest("FFmpeg not installed")
        import subprocess

        vid = os.path.join(_TMP, "pipe.mp4")
        subprocess.run([ffmpeg, "-y", "-nostdin", "-f", "lavfi", "-i",
                        "testsrc=duration=1:size=240x160:rate=12", "-c:v", "libx264",
                        "-pix_fmt", "yuv420p", vid], check=True, capture_output=True)
        path = os.path.join(main.user_temp(USER), main.sanitize_filename("v.mp4"))
        shutil.copyfile(vid, path)
        bot = FakeBot()
        update = FakeUpdate(uid=USER)
        update.message = FakeMessage()
        run(main.process_and_send(update, FakeContext(bot), path, "video"))
        self.assertEqual(len(bot.uploads), 1)
        self.assertEqual(bot.uploads[0][0], "video")
        self.assertFalse(os.path.exists(path))


class TestBatchPipeline(unittest.TestCase):
    def setUp(self):
        main.USER_STATE.clear()
        main.RATE.clear()
        self.img = os.path.join(_TMP, "batch_src.png")
        Image.new("RGB", (400, 300), (90, 20, 40)).save(self.img)
        self.bad = os.path.join(_TMP, "batch_bad.png")
        with open(self.bad, "wb") as fh:
            fh.write(b"definitely not a png")

    def test_batch_zips_results_and_cleans_up(self):
        bot = FakeBot({"_default": self.img})
        update = FakeUpdate(uid=USER)
        files = [("f1", ".png", "one.png"), ("f2", ".png", "two.png")]
        run(main.run_batch(update, FakeContext(bot), files))
        self.assertEqual(len(bot.uploads), 1)
        kind, args, kwargs = bot.uploads[0]
        self.assertEqual(kind, "document")
        self.assertEqual(kwargs.get("filename"), "watermarked_batch.zip")
        self.assertIn("2 OK, 0 failed", kwargs.get("caption", ""))
        leftovers = os.listdir(main.user_temp(USER))
        self.assertEqual(leftovers, [], f"temp files leaked: {leftovers}")

    def test_batch_isolates_failures(self):
        bot = FakeBot({"good": self.img, "bad": self.bad})
        # FakeBot._get_file falls back to "_default"; use distinct sources instead
        async def get_file(file_id):
            return FakeFile(self.img if file_id == "good" else self.bad)

        bot.get_file = AsyncMock(side_effect=get_file)
        update = FakeUpdate(uid=USER)
        files = [("good", ".png", "ok.png"), ("bad", ".png", "broken.png")]
        run(main.run_batch(update, FakeContext(bot), files))
        self.assertEqual(len(bot.uploads), 1)
        _, _, kwargs = bot.uploads[0]
        self.assertIn("1 OK, 1 failed", kwargs.get("caption", ""))
        self.assertEqual(os.listdir(main.user_temp(USER)), [])

    def test_batch_with_all_failures_reports_it(self):
        async def get_file(_file_id):
            return FakeFile(self.bad)

        bot = FakeBot()
        bot.get_file = AsyncMock(side_effect=get_file)
        update = FakeUpdate(uid=USER)
        run(main.run_batch(update, FakeContext(bot), [("x", ".png", "x.png")]))
        self.assertEqual(bot.uploads, [])
        self.assertEqual(os.listdir(main.user_temp(USER)), [])




if __name__ == "__main__":
    unittest.main(verbosity=2)
''',
}
def cmd_scaffold() -> None:
    """Write every auxiliary project file next to bot.py.

    bot.py is the single source of truth: requirements.txt, .env.example,
    Dockerfile, docker-compose.yml, viraj-watermark.service, README.md and
    the complete test suite are all embedded here and regenerated on demand.
    """
    base = Path(__file__).resolve().parent
    for name, content in SCAFFOLD_FILES.items():
        target = base / name
        if target.parent != base:
            target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        print(f"wrote {target}")
    print("\nNext:  python -m unittest discover -s tests -t .")


# ==========================================================================
# 25. Environment check & offline self-test
# ==========================================================================
def _selftest_config(base: str) -> Config:
    return Config(
        bot_token="123456:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
        admin_ids=[1],
        database_path=os.path.join(base, "t.db"),
        max_file_size=64 * 1024 * 1024,
        temp_directory=os.path.join(base, "tmp"),
        font_path="",
        ffmpeg_path="",
        admin_contact_url="https://t.me/",
        video_timeout=180,
        process_timeout=120,
        local_api_base_url="",
        local_api_file_url="",
        telegram_api_id=0,
        telegram_api_hash="",
        upload_limit=64 * 1024 * 1024,
        max_pdf_pages=400,
        max_image_pixels=178_956_970,
        rate_per_min=60,
        max_batch=10,
        max_concurrent_jobs=2,
        state_ttl=3600,
        use_local_bot_api=False,
        auto_start_local_bot_api=False,
        local_api_port=8081,
        log_file="",
    )


def run_selftest() -> int:
    """Offline verification of DB, security helpers, UI and all three engines."""
    import tempfile

    global CFG, DB, JOB_SEMAPHORE
    base = tempfile.mkdtemp(prefix="wmself_")
    CFG = _selftest_config(base)
    JOB_SEMAPHORE = None
    os.makedirs(CFG.temp_directory, exist_ok=True)
    DB = Database(CFG.database_path)
    DB.touch_user(1, "self", "Self")
    passed = failed = 0

    def check(name: str, fn: Callable[[], None]) -> None:
        nonlocal passed, failed
        try:
            fn()
            passed += 1
            print(f"  ✅ {name}")
        except Exception as exc:  # noqa: BLE001
            failed += 1
            print(f"  ❌ {name}: {type(exc).__name__}: {exc}")

    def S(**kw: Any) -> Dict[str, Any]:
        return {**DEFAULT_SETTINGS, **kw}

    # ---------------------------------------------------------------- UI
    def ui() -> None:
        labels = [b.text for row in main_menu_kb().inline_keyboard for b in row]
        for want in ("➕ Add Watermark", "⚙️ Settings", "🖼️ Process Image", "📄 Process PDF",
                     "🎥 Process Video", "⚡ Batch", "📊 My Settings", "📡 Status", "❓ Help",
                     "ℹ️ About", "👨‍💻 Contact Admin for VIP Plan",
                     "🏠 Back to Start"):
            assert want in labels, f"missing {want}"
        hub = [b.text for row in settings_hub_kb().inline_keyboard for b in row]
        for want in ("🎥 Video", "🖼️ Image", "📄 PDF", "🌐 Global Defaults",
                     "🏠 Back to Start"):
            assert want in hub, f"missing {want}"
        cat = [b.text for row in category_kb("global", S()).inline_keyboard for b in row]
        for want in ("🔴 Turn OFF", "✏️ Text", "🔤 Font", "✨ Style", "📏 Size", "🎨 Color",
                     "💧 Opacity", "📍 Position", "🧊 Badge & Effects", "⚙️ Stroke & Shadow",
                     "✍️ Mode: Text", "🖼️ Logo", "🔄 Reset to Default", "⬅️ Back",
                     "🏠 Back to Start"):
            assert want in cat, f"missing {want}"
        vcat = [b.text for row in category_kb("video", S()).inline_keyboard for b in row]
        assert any("🎬 Animation" in t for t in vcat), "video animation button missing"
        pcat = [b.text for row in category_kb("pdf", S()).inline_keyboard for b in row]
        assert any("📄 Pages" in t for t in pcat), "pdf pages button missing"
        assert serif_bold("Global Default Settings") in category_text("global", S())
        assert serif_bold("My Watermark Configuration") in my_settings_text(1)
        assert "Uptime" in status_text(1)
        assert serif_bold("Admin Panel") in _admin_stats_text()
        assert len(animation_kb("video", S()).inline_keyboard) >= len(VIDEO_ANIMATIONS) // 2

    # ----------------------------------------------------------- security
    def sec() -> None:
        assert "/" not in sanitize_filename("../../etc/passwd")
        assert sanitize_filename("a/b\\c.png").count("/") == 0
        assert sanitize_filename("").startswith("file") or "_file" in sanitize_filename("")
        base_dir = os.path.realpath(base)
        assert safe_join(base_dir, "x.png").startswith(base_dir)
        try:
            safe_join(base_dir, "../../etc/passwd")
            raise AssertionError("traversal allowed")
        except WatermarkError:
            pass
        assert parse_page_spec("all", 5) == [0, 1, 2, 3, 4]
        assert parse_page_spec("1,3-5", 5) == [0, 2, 3, 4]
        for bad in ("x", "9-1", "0"):
            try:
                parse_page_spec(bad, 5)
                if bad != "9-1":
                    raise AssertionError(f"bad spec {bad!r} accepted")
            except WatermarkError:
                pass
        assert hex_to_rgb("#FFF") == (255, 255, 255)
        assert normalize_hex("zzzz") == "#FFFFFF"
        try:
            hex_to_rgb("zz")
            raise AssertionError("bad hex accepted")
        except WatermarkError:
            pass
        assert sanitize_settings({"font_size": 99999})["font_size"] == 400
        assert sanitize_settings({"position": "../../etc"})["position"] == "bottom_right"
        assert sanitize_settings({"mode": "rm -rf /"})["mode"] == "text"
        assert sanitize_settings("not a dict")["font_size"] == 36
        assert sanitize_watermark_text("a\x00b") == "ab"
        assert len(sanitize_watermark_text("x" * 500)) == MAX_TEXT_LEN
        assert is_admin(1) and not is_admin(2)
        DB.kv_set("extra_admins", "456")
        assert is_admin(456)
        DB.kv_set("extra_admins", "")
        # rate limiter really limits
        DB.kv_set("rate_per_min", "5")
        RATE.pop(999, None)
        for _ in range(5):  # 5/min allowed …
            assert not rate_limited(999), "rate limiter tripped too early"
        assert rate_limited(999), "rate limiter did not trip"
        DB.kv_set("rate_per_min", "60")
        # redaction
        record = logging.LogRecord("t", logging.INFO, "f", 1,
                                   "token 123456:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA leaked",
                                   None, None)
        REDACTOR.filter(record)
        assert "AAAAA" not in record.getMessage(), "token not redacted"

    # --------------------------------------------------------------- DB
    def db() -> None:
        s = DB.get_settings(1, "image")
        assert s["text"] == "@VirajWatermark" and s["opacity"] == 75
        s["font_size"] = 50
        DB.save_settings(1, "image", s)
        assert DB.get_settings(1, "image")["font_size"] == 50
        DB.reset_settings(1, "image")
        assert DB.get_settings(1, "image")["font_size"] == 36
        DB.execute("UPDATE settings SET data='{corrupt' WHERE user_id=1 AND media='image'")
        assert DB.get_settings(1, "image")["font_size"] == 36, "corrupt JSON not handled"
        DB.bump_stat(1, "image")
        assert DB.totals()["images"] >= 1
        DB.log_error(1, "test", "boom")
        assert DB.recent_errors()[0]["message"] == "boom"
        DB.set_blocked(77, True)
        assert DB.is_blocked(77)
        DB.set_blocked(77, False)
        assert not DB.is_blocked(77)
        assert DB.user_counts()[0] >= 1

    # ------------------------------------------------------------ image
    def img() -> None:
        src, dst = os.path.join(base, "a.jpg"), os.path.join(base, "a_out.jpg")
        Image.new("RGB", (800, 600), (30, 30, 30)).save(src, "JPEG")
        process_image_file(src, dst, S(), 1)
        with Image.open(dst) as im:
            assert im.format == "JPEG", im.format
        diff = _diff_pixels(Image.open(src).convert("RGB"),
                            Image.open(dst).convert("RGB"))
        assert diff > 500, f"watermark invisible ({diff} px)"
        # RGBA / tiled / palette / grayscale / webp / custom coords / italic / badge
        for mode, ext, kw in (("RGBA", ".png", {"tiled": True}),
                              ("L", ".png", {"rotation": 45, "badge": "box"}),
                              ("P", ".png", {"italic": True}),
                              ("RGB", ".webp", {"position": "custom",
                                                "custom_x": 5, "custom_y": 5})):
            s_path = os.path.join(base, f"m{mode}{ext}")
            d_path = os.path.join(base, f"m{mode}_out{ext}")
            im = Image.new("RGB" if mode == "P" else mode, (400, 300), 128)
            if mode == "P":
                im = im.convert("P")
            im.save(s_path)
            process_image_file(s_path, d_path, S(**kw), 1)
            assert os.path.getsize(d_path) > 0
        # logo + both + tiled logo
        Image.new("RGBA", (100, 60), (255, 0, 0, 200)).save(logo_file_for(1, "image"), "PNG")
        lp, ld = os.path.join(base, "l.png"), os.path.join(base, "l_out.png")
        Image.new("RGB", (600, 400), (20, 20, 20)).save(lp)
        process_image_file(lp, ld, S(mode="both", logo_tiled=True), 1)
        assert os.path.getsize(ld) > 0
        # corrupt + bomb
        bad = os.path.join(base, "bad.png")
        with open(bad, "wb") as fh:
            fh.write(b"not an image at all")
        try:
            process_image_file(bad, os.path.join(base, "bad_out.png"), S(), 1)
            raise AssertionError("corrupt image accepted")
        except WatermarkError:
            pass
        layer = build_watermark_layer((640, 480), S(stroke=True, shadow=True), None, 1.0)
        assert layer.mode == "RGBA" and layer.getbbox() is not None

    # -------------------------------------------------------------- pdf
    def pdf() -> None:
        src, dst = os.path.join(base, "d.pdf"), os.path.join(base, "d_out.pdf")
        doc = fitz.open()
        for _ in range(2):
            doc.new_page()
        doc.save(src)
        doc.close()
        n = process_pdf_file(src, dst, S(), 1)
        assert n == 2
        doc = fitz.open(dst)
        assert doc.page_count == 2
        assert all(len(p.get_images()) >= 1 for p in doc), "no watermark image on page"
        doc.close()
        # page range
        process_pdf_file(src, os.path.join(base, "d_out2.pdf"), S(pdf_pages="2"), 1)
        # encrypted
        enc = os.path.join(base, "enc.pdf")
        d2 = fitz.open()
        d2.new_page()
        d2.save(enc, encryption=fitz.PDF_ENCRYPT_AES_256, user_pw="x", owner_pw="x")
        d2.close()
        try:
            process_pdf_file(enc, os.path.join(base, "enc_out.pdf"), S(), 1)
            raise AssertionError("encrypted pdf accepted")
        except WatermarkError:
            pass
        # corrupt
        bad = os.path.join(base, "bad.pdf")
        with open(bad, "wb") as fh:
            fh.write(b"%PDF-garbage")
        try:
            process_pdf_file(bad, os.path.join(base, "bad_out.pdf"), S(), 1)
            raise AssertionError("corrupt pdf accepted")
        except WatermarkError:
            pass

    # ------------------------------------------------------------ video
    def video() -> None:
        ffmpeg = find_ffmpeg()
        if not ffmpeg:
            print("  ⚠️  FFmpeg not found — video engine checks skipped")
            return
        assert _is_executable(ffmpeg)
        src, dst = os.path.join(base, "v.mp4"), os.path.join(base, "v_out.mp4")
        subprocess.run([ffmpeg, "-y", "-nostdin", "-f", "lavfi", "-i",
                        "testsrc=duration=2:size=320x240:rate=15",
                        "-c:v", "libx264", "-pix_fmt", "yuv420p", src],
                       check=True, capture_output=True)
        seen: List[float] = []

        async def prog(pct: float) -> None:
            seen.append(pct)

        asyncio.run(process_video_file(src, dst, S(), 1, ffmpeg, prog))
        assert os.path.getsize(dst) > 0, "empty video output"
        assert seen, "no progress callbacks"
        # animated + logo + tiled
        Image.new("RGBA", (60, 40), (0, 255, 0, 180)).save(logo_file_for(1, "video"), "PNG")
        d2 = os.path.join(base, "v2_out.mp4")
        asyncio.run(process_video_file(src, d2, S(mode="both", tiled=True,
                                                  animation="dvd_bounce",
                                                  animation_speed=1.5), 1, ffmpeg))
        assert os.path.getsize(d2) > 0
        # frame-level proof the overlay is visible
        fa, fb = os.path.join(base, "fa.png"), os.path.join(base, "fb.png")
        for out, vid in ((fa, src), (fb, dst)):
            subprocess.run([ffmpeg, "-y", "-nostdin", "-i", vid, "-frames:v", "1",
                            "-vf", "select=eq(n\\,8)", out], check=True,
                           capture_output=True)
        ia, ib = Image.open(fa).convert("RGB"), Image.open(fb).convert("RGB")
        vdiff = _diff_pixels(ia, ib)
        assert vdiff > 200, f"video watermark invisible ({vdiff} px)"

    # ------------------------------------------------- all animations
    def animations() -> None:
        ffmpeg = find_ffmpeg()
        if not ffmpeg:
            print("  ⚠️  FFmpeg not found — animation sweep skipped")
            return
        src = os.path.join(base, "anim_src.mp4")
        subprocess.run([ffmpeg, "-y", "-nostdin", "-f", "lavfi", "-i",
                        "testsrc=duration=1:size=160x120:rate=10",
                        "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt",
                        "yuv420p", src], check=True, capture_output=True)
        broken: List[str] = []
        for name in VIDEO_ANIMATIONS:
            dst = os.path.join(base, f"anim_{name}.mp4")
            try:
                asyncio.run(process_video_file(src, dst,
                                               S(animation=name, animation_speed=2.0),
                                               1, ffmpeg))
                if os.path.getsize(dst) == 0:
                    broken.append(f"{name}: empty output")
            except Exception as exc:  # noqa: BLE001
                broken.append(f"{name}: {type(exc).__name__}: {str(exc)[:90]}")
            finally:
                with _suppress_os_error():
                    os.remove(dst)
        assert not broken, "broken presets -> " + " | ".join(broken)

    # ----------------------------------------------------------- temp/ops
    def ops() -> None:
        d = os.path.join(CFG.temp_directory, "1")
        os.makedirs(d, exist_ok=True)
        old = os.path.join(d, "old.txt")
        with open(old, "w") as fh:
            fh.write("x")
        os.utime(old, (time.time() - 7200, time.time() - 7200))
        assert clean_temp_dir(3600) >= 1 and not os.path.exists(old)
        with open(old, "w") as fh:
            fh.write("x")
        assert clean_temp_dir(0) >= 1 and not os.path.exists(old)
        set_state(42, "auto")
        assert get_state(42) is not None
        clear_state(42)
        assert get_state(42) is None
        set_state(43, "auto")
        USER_STATE[43]["ts"] = time.time() - CFG.state_ttl - 10
        assert get_state(43) is None, "expired state not dropped"
        assert limit_max_batch() >= 2 and limit_rate_per_min() >= 5
        assert media_kind_of(".JPG") == "image" and media_kind_of(".mkv") == "video"
        assert media_kind_of(".exe") is None
        assert human_size(2048) == "2.0 KB"
        for chain in ("none", "pulse", "zoom", "spin", "strobe", "corner", "dvd_bounce"):
            assert "[vout]" in animation_filter(chain, 1.0)

    print("== Viraj Watermark — offline self-test ==")
    check("UI keyboards, panels & status screen", ui)
    check("Security: sanitization, traversal, validation, redaction", sec)
    check("Database: settings, corrupt JSON, stats, block", db)
    check("Image engine: formats, modes, logo, corrupt input", img)
    check("PDF engine: pages, ranges, encrypted, corrupt", pdf)
    check("Video engine: overlay, animation, logo, progress", video)
    check(f"All {len(VIDEO_ANIMATIONS)} video animation presets encode", animations)
    check("Ops: temp cleanup, state TTL, limits, filters", ops)
    print(f"\n{passed} passed, {failed} failed")
    try:
        DB.close()
    except Exception:  # noqa: BLE001
        pass
    shutil.rmtree(base, ignore_errors=True)
    return 1 if failed else 0


def run_check() -> int:
    """Environment report: config, deps, FFmpeg, DB, fonts, disk."""
    print("=" * 68)
    print(f"  Viraj Watermark {APP_VERSION} — environment check")
    print("=" * 68)
    ok = True

    def line(label: str, good: bool, detail: str = "") -> None:
        nonlocal ok
        ok = ok and good
        print(f"  {'✅' if good else '❌'} {label:<28} {detail}")

    line("Python", sys.version_info >= MIN_PYTHON, sys.version.split()[0])
    missing = _missing_requirements()
    line("Dependencies", not missing,
         "all present" if not missing else ", ".join(s for _m, s, _d in missing))
    ffmpeg = find_ffmpeg()
    line("FFmpeg", bool(ffmpeg), ffmpeg or "not found (video disabled)")
    line("PDF engine", fitz is not None, "PyMuPDF" if fitz else "missing")
    try:
        cfg = Config.from_env()
        line("BOT_TOKEN", True, f"loaded (…{cfg.bot_token[-4:]})")
        line("ADMIN_IDS", bool(cfg.admin_ids),
             ", ".join(map(str, cfg.admin_ids)) or "none set — admin panel unreachable")
        line("Database", True, cfg.database_path)
        line("Temp directory", True, cfg.temp_directory)
        if cfg.use_local_bot_api or cfg.local_api_base_url:
            reachable = _local_api_reachable(cfg.local_api_base_url)
            line("Local Bot API", reachable,
                 cfg.local_api_base_url + (" (reachable)" if reachable
                                           else " (unreachable — will fall back)"))
        else:
            line("Local Bot API", True, "standard api.telegram.org (20 MB / 50 MB caps)")
        try:
            db = Database(cfg.database_path)
            db.touch_user(0, "check", "check")
            db.close()
            line("SQLite writable", True, "ok")
        except Exception as exc:  # noqa: BLE001
            line("SQLite writable", False, str(exc))
        usage = psutil.disk_usage(cfg.temp_directory if os.path.isdir(cfg.temp_directory)
                                  else ".")
        line("Disk free", usage.free > 512 * 1024 * 1024, human_size(usage.free))
        mem = psutil.virtual_memory()
        line("Memory", mem.available > 256 * 1024 * 1024, human_size(mem.available))
        _scan_fonts()
        line("Fonts discovered", bool(_FONT_CACHE), f"{len(_FONT_CACHE)} face(s)")
    except SystemExit as exc:
        line("Configuration", False, str(exc).replace("\n", " ")[:120])

    print("=" * 68)
    print("  RESULT:", "OK — ready to run `python bot.py`" if ok else "FIX THE ITEMS ABOVE")
    print("=" * 68)
    return 0 if ok else 1


# ==========================================================================
# 26. Entry point
# ==========================================================================
def main() -> None:
    global CFG, DB
    parser = argparse.ArgumentParser(description="Viraj Watermark Telegram bot")
    parser.add_argument("--scaffold", action="store_true",
                        help="write requirements.txt, .env.example, Dockerfile, README…")
    parser.add_argument("--selftest", action="store_true",
                        help="run the offline engine/security/UI test suite and exit")
    parser.add_argument("--check", action="store_true",
                        help="verify the environment and exit")
    args = parser.parse_args()

    if args.scaffold:
        cmd_scaffold()
        return
    _setup_logging()
    if args.selftest:
        sys.exit(run_selftest())
    if args.check:
        sys.exit(run_check())

    try:
        CFG = Config.from_env()
    except SystemExit as exc:
        print(str(exc))
        sys.exit(1)

    try:
        os.makedirs(CFG.temp_directory, exist_ok=True)
    except OSError as exc:
        LOG.error("Cannot create TEMP_DIRECTORY %s: %s", CFG.temp_directory, exc)
        sys.exit(1)

    DB = Database(CFG.database_path)
    clean_temp_dir(max_age=0)

    ffmpeg = find_ffmpeg()
    if ffmpeg:
        LOG.info("FFmpeg: %s", ffmpeg)
    else:
        LOG.warning("FFmpeg NOT found — video watermarking is disabled. Install it "
                    "(apt install ffmpeg / brew install ffmpeg) or run "
                    "'pip install imageio-ffmpeg'.")

    start_local_bot_api_if_available()

    LOG.info("Starting Viraj Watermark %s (Python %s, PTB %s)…", APP_VERSION,
             sys.version.split()[0], getattr(__import__("telegram"), "__version__", "?"))
    application = build_application()
    try:
        application.run_polling(allowed_updates=Update.ALL_TYPES,
                                drop_pending_updates=True)
    except InvalidToken:
        LOG.error("Invalid BOT_TOKEN — re-copy it from @BotFather and restart.")
    finally:
        stop_local_bot_api()
        try:
            DB.close()
        except Exception:  # noqa: BLE001
            pass


if __name__ == "__main__":
    main()
